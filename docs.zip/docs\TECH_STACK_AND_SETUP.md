# EduSync — Technology Stack & Project Setup Guide

> **Project:** EduSync — Real-time Academic Collaboration Platform  
> **Institution:** Assam down town University (AdtU)  
> **Live App:** https://major-three-tau.vercel.app  
> **API Server:** https://major-gin9.onrender.com

---

## 🧱 What We Built

EduSync is a **full-stack, real-time academic platform** — a single workspace that replaces fragmented tools (WhatsApp groups, Google Classroom, email threads) with organized subject channels, live chat, assignment tracking, and collaborative project boards.

It works as a **web app** (Flutter Web on Vercel) and can also be compiled natively for **Android, iOS, Windows, Linux, and macOS** from the same codebase.

---

## 🏗 System Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    CLIENT LAYER                          │
│   Flutter Web (Vercel CDN)  ·  Flutter Android/iOS       │
└──────────────────────┬───────────────────────────────────┘
                       │  HTTPS + WSS (WebSockets)
┌──────────────────────▼───────────────────────────────────┐
│                  BACKEND (Render)                        │
│                                                          │
│   Express REST API       Socket.IO Server                │
│   (12 route groups)   (chat, typing, notifications)      │
│                                                          │
│   Middleware Chain:                                      │
│   compression → cors → helmet → rate-limit → JWT auth    │
└──────────────────────┬───────────────────────────────────┘
                       │
          ┌────────────┴────────────┐
          │                         │
┌─────────▼──────────┐   ┌──────────▼──────────┐
│  Neon PostgreSQL    │   │  Supabase Storage   │
│  (13 tables, ACID) │   │  (CDN file bucket)  │
└────────────────────┘   └─────────────────────┘
```

---

## ⚙️ Full Technology Stack

### 🖥 Frontend — Flutter (Dart)

Flutter is a Google-made cross-platform UI framework that compiles to native code for Web, Android, iOS, and Desktop from **one single codebase in Dart.**

| Package | Version | What It Does |
|---|---|---|
| **Flutter SDK** | ≥3.0.0 | The core framework — compiles Dart to Web (JS/WASM), Android (ARM), iOS, Desktop |
| **flutter_riverpod** | ^3.3.1 | State management — reactive providers that rebuild the UI when data changes |
| **Dio** | ^5.4.0 | HTTP client — makes API calls to the backend with automatic JWT injection |
| **socket_io_client** | ^2.0.3+1 | WebSocket client — connects to Socket.IO server for real-time chat and notifications |
| **flutter_secure_storage** | ^9.0.0 | Encrypted storage — saves the JWT token securely (uses Keychain on iOS, Keystore on Android) |
| **shared_preferences** | ^2.2.3 | Lightweight persistent storage — offline message cache and session data |
| **file_picker** | ^8.1.7 | Native file selection — allows users to pick files for assignment submission and uploads |
| **table_calendar** | ^3.1.2 | Interactive calendar widget — displays academic events, exams, and holidays |
| **go_router** | ^14.3.0 | URL-based routing (installed for web deep-links; current nav uses AuthGate pattern) |
| **google_fonts** | ^8.0.2 | Loads "Outfit" typeface from Google Fonts CDN for consistent modern typography |
| **animations** | ^2.1.2 | Pre-built Material motion transitions (fade, shared axis, container transform) |
| **glassmorphism** | ^3.0.0 | Frosted glass UI effects for premium-feeling cards and sidebars |
| **flutter_feather_icons** | ^2.0.0+1 | Clean minimal SVG icon set (used throughout the UI) |
| **intl** | ^0.20.2 | Internationalization — date/time formatting (`DateFormat('MMM d, yyyy')`) |
| **url_launcher** | ^6.3.1 | Opens external URLs (file downloads, links) in the default browser |

**Why Flutter?**
- One codebase → Web + Android + iOS + Desktop
- Fast rendering (Skia/Impeller canvas, not HTML DOM)
- Strong type safety with Dart
- Riverpod makes complex async state (API calls, WebSocket streams) easy to manage

---

### 🖧 Backend — Node.js + Express.js

Node.js is a JavaScript runtime built on Chrome's V8 engine. Express.js is a minimal web framework on top of it. Together they form the REST API server.

| Package | Version | What It Does |
|---|---|---|
| **express** | ^4.18.3 | The web framework — defines routes, middleware, request/response handling |
| **socket.io** | ^4.7.5 | WebSocket engine — bi-directional real-time communication (chat, notifications, typing) |
| **pg** | ^8.11.3 | PostgreSQL client — `pool.query()` with connection pooling for concurrent requests |
| **@supabase/supabase-js** | ^2.105.4 | Supabase Storage SDK — streams file uploads to the CDN bucket |
| **jsonwebtoken** | ^9.0.2 | Signs and verifies JWTs for authentication (HMAC SHA-256 algorithm) |
| **bcryptjs** | ^2.4.3 | Password hashing — stores hashed passwords with salt (cost factor 10) |
| **multer** | ^1.4.5 | Multipart form-data parser — handles file uploads from Flutter's `FormData` |
| **helmet** | ^8.1.0 | HTTP security headers — CSP, XSS protection, anti-clickjacking |
| **express-rate-limit** | ^8.3.2 | Rate limiter — 200 requests per IP per 15 min (prevents DDoS and brute-force) |
| **compression** | ^1.8.1 | Gzip compression — shrinks all JSON responses by ~80% |
| **express-async-errors** | ^3.1.1 | Patches Express to catch async errors and route them to the global error handler |
| **express-validator** | ^7.3.2 | Input validation middleware — validates request bodies |
| **file-type** | ^16.5.4 | Reads actual file bytes to detect MIME type — blocks disguised malware uploads |
| **dotenv** | ^16.4.5 | Loads `.env` file variables into `process.env` |
| **nodemon** | ^3.1.0 | Dev tool — auto-restarts the server when source files change |

**Why Node.js + Express?**
- JavaScript — same language as the frontend world (shared mental model)
- Non-blocking I/O — excellent for real-time WebSocket workloads
- Socket.IO is a first-class Node.js library
- Huge npm ecosystem

---

### 🗄 Database — PostgreSQL (via Neon)

PostgreSQL is an advanced open-source relational database. **Neon** is a serverless cloud-hosted PostgreSQL service that scales to zero when idle.

#### Database Schema (13 Tables)

```
faculties (id, name, color_code)
    └── programmes (id, faculty_id, name, code, duration_semesters)
            └── batches (id, programme_id, year)
                    └── channels (id, batch_id, semester_number, subject_name, teacher_id)
                            ├── messages (id, channel_id, sender_id, content, file_url, is_pinned)
                            ├── notes (id, channel_id, created_by, title)
                            ├── assignments (id, channel_id, title, due_date, max_marks)
                            │       └── assignment_submissions (assignment_id, student_id, file_url, status, marks)
                            └── announcements (id, channel_id, title, content, is_important)

users (id, name, email, roll_number, password[hashed], role, programme_id, current_semester)
    ├── enrollments (user_id, channel_id)
    └── notifications (id, user_id, type, title, is_read)

projects (id, title, created_by, progress, deadline)
    ├── project_members (project_id, user_id)
    └── project_tasks (id, project_id, title, status, assigned_to_name, priority)

academic_events (id, title, type, start_date, end_date)
```

**Key SQL Features Used:**
- `json_agg(json_build_object(...))` — aggregates related rows into a JSON array in a single query
- `COUNT(*) FILTER (WHERE status = 'done')` — conditional counting in one query
- `COALESCE(..., '[]')` — safe default when aggregation returns NULL
- `ON CONFLICT DO NOTHING` — safe upsert pattern
- `RETURNING *` — returns the inserted/updated row in one round-trip
- B-Tree indexes on all foreign key columns for sub-millisecond lookups

**Why PostgreSQL?**
- ACID transactions — data is never partially committed
- Advanced SQL — JSON aggregation, conditional counts, CTEs
- Foreign key constraints — referential integrity enforced at DB level
- Works with Neon's serverless scaling model

---

### 📦 Infrastructure (Cloud Services)

| Service | Provider | Role |
|---|---|---|
| **Frontend Hosting** | Vercel | Serves the Flutter Web build as static files from a global CDN |
| **Backend Hosting** | Render | Runs the Node.js server (free tier, auto-deploys from GitHub) |
| **Database** | Neon | Serverless PostgreSQL — always-on storage, scales compute to zero when idle |
| **File Storage** | Supabase Storage | CDN-backed bucket for assignment submissions, notes, and chat file attachments |
| **CI/CD** | GitHub Actions | Automatically runs `flutter analyze` + `flutter build web` on every push to `main` |

---

## 🔐 Security Architecture

| Threat | How We Handle It |
|---|---|
| SQL Injection | All queries use `$1, $2` parameterized placeholders — never string concatenation |
| XSS | Helmet CSP headers; Flutter renders to a canvas (no HTML innerHTML) |
| Brute Force | `express-rate-limit` — 200 req/IP/15 min globally; login failures tracked separately |
| Password Storage | `bcryptjs` with salt rounds = 10 (computationally expensive to crack) |
| Privilege Escalation | `role` is hardcoded to `'student'` on register regardless of request body |
| Malware Uploads | `file-type` reads magic bytes; `multer` fileFilter blocks `.exe`, `.bat`, `.msi` |
| Token Theft | 7-day JWT; `401` auto-logs out user and purges stored token |
| Clickjacking | Helmet sets `X-Frame-Options: DENY` |
| CORS | Strict origin allowlist — only Vercel, localhost dev ports |

---

## 🔄 Real-Time System (Socket.IO)

Socket.IO provides bi-directional WebSocket communication between clients and server.

| Event | Direction | What Triggers It |
|---|---|---|
| `channel:join` | Client → Server | User opens a subject channel |
| `message:new` | Server → Client | Someone sends a chat message |
| `typing:start/stop` | Client ↔ Server | User starts/stops typing in chat |
| `notification:new` | Server → Client | New assignment, announcement, or grade |
| `announcement:new` | Server → Client | Faculty posts an announcement |
| `message:pinned` | Server → Client | Faculty pins a message |

The REST API controllers can also **broadcast via Socket.IO** — e.g. when a faculty creates an assignment via `POST /api/assignments`, the `announcementController` calls `io.to(room).emit('notification:new', ...)` to push a notification to all enrolled students instantly.

---

## 📁 Project Folder Structure

```
major-project/
├── backend/
│   ├── config/
│   │   ├── db.js           # pg.Pool → Neon PostgreSQL connection
│   │   ├── supabase.js     # Supabase Storage client + ensureBucket()
│   │   ├── schema.sql      # Full database schema (run once to set up DB)
│   │   └── migration.sql   # Incremental schema migrations
│   ├── controllers/        # Business logic (one file per resource)
│   ├── middleware/
│   │   ├── auth.js         # JWT verification (protect) + RBAC (authorize)
│   │   ├── upload.js       # Multer + Supabase stream storage engine
│   │   └── errorHandler.js # Global async error handler
│   ├── routes/             # Express Router files (one per resource)
│   ├── socket/
│   │   └── socketHandler.js# All Socket.IO event handlers
│   └── server.js           # Entry point: app setup, middleware, route mounting
│
├── frontend/
│   └── lib/
│       ├── main.dart        # App entry, ProviderScope, _AuthGate routing
│       ├── core/
│       │   ├── config/      # app_config.dart (API URL switch prod/dev)
│       │   ├── services/    # api_service.dart, socket_service.dart, storage_service.dart
│       │   └── theme/       # AppColors, typography
│       └── features/
│           ├── auth/        # Login screens, auth provider
│           └── dashboard/
│               ├── data/
│               │   ├── models/      # Dart data classes
│               │   └── repositories/# API call wrappers
│               └── presentation/
│                   ├── screens/     # Full pages (Dashboard, ProjectDetail, etc.)
│                   ├── providers/   # Riverpod providers
│                   └── widgets/     # Reusable UI components
│
├── docs/                   # Documentation (this folder — local only, git-ignored)
└── .github/
    └── workflows/
        └── frontend-ci.yml # GitHub Actions CI pipeline
```

---

## 🚀 Local Development Setup

### Prerequisites

- **Node.js** v18 or higher
- **Flutter SDK** v3.0 or higher (with Chrome for web dev)
- A **Neon** (or local) PostgreSQL database
- A **Supabase** project with Storage enabled

---

### Step 1: Clone and set up the backend

```bash
# 1. Go into the backend folder
cd "major project/backend"

# 2. Install all Node.js dependencies
npm install

# 3. Create your environment file (copy from example or create fresh)
# Create a file called .env with the following:

PORT=5000
NODE_ENV=development
DATABASE_URL=postgresql://your_neon_connection_string
JWT_SECRET=any_long_random_string
CLIENT_URL=http://localhost:9090
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_KEY=your_service_key
SUPABASE_ANON_KEY=your_anon_key

# 4. Set up the database (run schema.sql in your Neon SQL editor)
# Open Neon dashboard → SQL Editor → paste contents of backend/config/schema.sql → Run

# 5. Start the backend dev server
npm run dev
# → Server running at http://localhost:5000
# → Test: GET http://localhost:5000/api/health  ← should return { success: true }
```

---

### Step 2: Set up the frontend

```bash
# 1. Go into the frontend folder
cd "major project/frontend"

# 2. Install all Flutter packages
flutter pub get

# 3. Make sure the API URL points to localhost
# Edit: lib/core/config/app_config.dart
# Set the baseUrl to: 'http://localhost:5000/api'

# 4. Run the app in Chrome
flutter run -d chrome
# → App opens at http://localhost:9090
```

---

### Step 3: Test Accounts

| Role | Login Screen | Identifier | Password |
|---|---|---|---|
| Admin | `/faculty-login` | `admin@adtu.in` | `2004-05-15` |
| Faculty | `/faculty-login` | `manoj.sarma.FoCT1@adtu.in` | `2004-05-15` |
| Student | `/login` | `ADTU/2024/BTECH-CSE/001` | `2004-05-15` |

> The password for all accounts is the date of birth in `YYYY-MM-DD` format.

---

## 🌐 Production Deployment

| Layer | Platform | How It Deploys |
|---|---|---|
| Frontend | Vercel | Auto-deploys on push to `main` — serves `build/web/` as static CDN files |
| Backend | Render | Auto-deploys on push to `main` — runs `node server.js` |
| Database | Neon | Always-on; no deployment needed. Schema set up once via Neon SQL editor |
| Files | Supabase Storage | `ensureBucket()` runs on server startup to verify the `files` bucket exists |

### CI/CD Pipeline (GitHub Actions)

On every push to `main` that touches the `frontend/` folder, GitHub Actions automatically:
1. Sets up Flutter 3.41.9 (pinned version for compatibility)
2. Runs `flutter pub get`
3. Runs `flutter analyze` — **blocks merge if there are any errors**
4. Checks dart formatting (warning only)
5. Builds `flutter build web --release`
6. Uploads the `build/web/` folder as a build artifact

The pre-built `build/web/` output is committed to the repo. Vercel then serves it directly without needing to run Flutter in the cloud (Flutter's build takes ~5 minutes, which exceeds Vercel's free tier build time).

---

## ⚡ Performance Optimizations

| Optimization | Where | Effect |
|---|---|---|
| Gzip compression | `server.js` — `compression()` middleware | ~80% smaller JSON responses |
| PostgreSQL connection pooling | `config/db.js` — `pg.Pool` | Reuses DB connections across requests |
| B-Tree indexes | `schema.sql` | Sub-millisecond lookups on channel_id, user_id |
| Riverpod `keepAlive` | Flutter providers | State survives tab switches — no redundant refetching |
| `json_agg` in SQL | `projectController`, `channelController` | Gets nested data in 1 query instead of N+1 queries |
| Cursor-based pagination | `messageController` | Loads thousands of chat messages without OFFSET slowdowns |
| `Future.wait([...])` | Flutter repositories | Fetches multiple channels in parallel, not one-by-one |
