# 📄 `middleware/errorHandler.js` + `socket/socketHandler.js` — Complete Explanation

> This document covers the two final pieces of the backend infrastructure: the global error handler middleware and the Socket.IO real-time event handler.

---

## Part 1 — `backend/middleware/errorHandler.js`

**File Path:** `backend/middleware/errorHandler.js`  
**Lines:** 12  
**Role:** Express "catch-all" error handler — intercepts any unhandled error thrown in any route or middleware and returns a consistent JSON error response.

---

### The Full File

```js
const errorHandler = (err, req, res, next) => {
  console.error('❌ Error:', err.message);
  const status = err.status || 500;
  res.status(status).json({
    success: false,
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

module.exports = errorHandler;
```

---

### Line-by-Line Breakdown

**`const errorHandler = (err, req, res, next) => {`**

This is an **Express error-handling middleware**. The critical detail: it has **4 parameters** — `(err, req, res, next)`. This is what tells Express "this is an error handler, not a normal middleware." Normal middlewares have 3 parameters `(req, res, next)`. Express only calls 4-parameter middlewares when an error is thrown or passed to `next(err)`.

**`console.error('❌ Error:', err.message);`**

Logs the error message to the server console with a ❌ prefix. `console.error` writes to stderr (vs `console.log` which writes to stdout) — useful for filtering logs.

**`const status = err.status || 500;`**

Reads the HTTP status code from the error object. If the error was created with a custom status (e.g., `const err = new Error('Not found'); err.status = 404;`), that status is used. Otherwise falls back to `500` (Internal Server Error).

**`res.status(status).json({ success: false, message: ... })`**

Sends a consistent JSON error response. Every error response in the app has the same shape: `{ success: false, message: "..." }`. This consistency is important — the Flutter client always knows what error responses look like.

**`...(process.env.NODE_ENV === 'development' && { stack: err.stack })`**

The spread operator `...` conditionally adds the `stack` property:
- In **development** mode: includes the full stack trace (useful for debugging)
- In **production** mode: omits the stack trace (prevents leaking internal paths to attackers)

The `&&` short-circuit trick: `false && { stack: ... }` evaluates to `false`, and `...false` adds nothing. `true && { stack: ... }` evaluates to the object, and spreading it adds `stack` to the response.

---

### How Errors Flow Into This Handler

```
Route handler throws error
        │
        ▼
Express catches it automatically (async wrapper or try/catch with next(err))
        │
        ▼
errorHandler(err, req, res, next) — runs
        │
        ▼
res.status(500).json({ success: false, message: '...' })
```

In `server.js`:
```js
app.use(errorHandler); // Must be LAST — registered after all routes
```

Express requires the error handler to be the **last registered middleware** so it doesn't intercept normal requests.

---

### Summary Table

| Line | Code | What it does |
|---|---|---|
| 1 | `(err, req, res, next)` | 4-param signature = error-handling middleware |
| 2 | `console.error(...)` | Log error to stderr |
| 3 | `err.status \|\| 500` | Use custom status or default to 500 |
| 4–8 | `res.status().json(...)` | Return consistent JSON error shape |
| 7 | `NODE_ENV === 'development'` | Only show stack trace in dev mode |

---

---

## Part 2 — `backend/socket/socketHandler.js`

**File Path:** `backend/socket/socketHandler.js`  
**Lines:** 86  
**Role:** Manages all WebSocket (Socket.IO) event handlers for real-time messaging, typing indicators, notifications, and online user presence.

---

### 1. File Purpose

This file contains the entire **real-time communication logic** for EduSync. It handles:
- Authenticating WebSocket connections via JWT
- Managing subject channel "rooms" (join/leave)
- Persisting and broadcasting text messages
- Typing indicator broadcasts
- Direct user-to-user notifications via real-time socket
- Online user presence tracking

> **Beginner Analogy:** Socket.IO is like a walkie-talkie system. `socketHandler` is the base station operator — it connects to each walkie-talkie (client), assigns them to the correct group channel, and relays messages between them instantly.

---

### 2. Imports

```js
const pool = require('../config/db');
const jwt  = require('jsonwebtoken');
```

- **`pool`** — PostgreSQL connection pool. Used to persist messages and verify users.
- **`jwt`** — Verifies the JWT token sent during the WebSocket handshake.

---

### 3. Main Structure

```js
const socketHandler = (io) => {
  const onlineUsers = new Map(); // userId -> socketId

  io.on('connection', async (socket) => {
    // ... all event handlers
  });
};

module.exports = socketHandler;
```

- **`io`** — The Socket.IO server instance (injected from `server.js`).
- **`onlineUsers`** — An in-memory `Map` tracking which users are currently online. Key: `userId` (string), Value: `socket.id` (string). Resets on server restart.
- **`io.on('connection', ...)`** — Fires for every new WebSocket connection from any client.

> **Note:** `onlineUsers` is in JavaScript memory — it resets if the server restarts. In a multi-server setup, this would need Redis Pub/Sub.

---

### 4. Authentication at Connection

```js
try {
  const token = socket.handshake.auth?.token;
  if (token) {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const result  = await pool.query(
      'SELECT id, name, role FROM users WHERE id = $1',
      [decoded.id]
    );
    if (result.rows.length) {
      socket.user = result.rows[0];
      onlineUsers.set(String(socket.user.id), socket.id);
      console.log(`✅ Auth: ${socket.user.name} (${socket.user.role})`);
    }
  }
} catch (_) {
  console.log('⚠️  Socket: unauthenticated connection');
}
```

- **`socket.handshake.auth?.token`** — The Flutter client sends its JWT during the initial Socket.IO handshake.
- **`jwt.verify(...)`** — Cryptographically verifies the token (same check as HTTP middleware).
- **DB query** — Fetches the user's current name/role from PostgreSQL (not trusted from token alone).
- **`socket.user = result.rows[0]`** — Attaches user data to the socket object; accessible in all event handlers.
- **`onlineUsers.set(...)`** — Registers the user as online (enables direct notifications).
- **Unauthenticated connections** are allowed (no disconnect) — just without `socket.user`. This lets read-only operations proceed.

---

### 5. Channel Room Management

```js
socket.on('channel:join',  (channelId) => socket.join(`channel_${channelId}`));
socket.on('channel:leave', (channelId) => socket.leave(`channel_${channelId}`));
```

- When Flutter opens the Messages view for channel 42, it emits `channel:join` with `42`.
- `socket.join('channel_42')` adds this connection to the "channel_42" room.
- Broadcasting to `channel_42` reaches **all** sockets in that room simultaneously.
- `channel:leave` removes the socket from the room when navigating away.

---

### 6. Text Message Handler

```js
socket.on('message:send', async (data) => {
  const senderId = socket.user?.id;  // From verified JWT — NOT from client data
  if (!senderId) return socket.emit('error', { message: 'Not authenticated' });

  const { channelId, content, parent_id } = data;
  if (!content?.trim()) return;

  const result = await pool.query(
    `INSERT INTO messages (channel_id, sender_id, content, parent_id)
     VALUES ($1, $2, $3, $4)
     RETURNING *, (SELECT name FROM users WHERE id = $2) AS sender_name, ...`,
    [channelId, senderId, content.trim(), parent_id || null]
  );

  io.to(`channel_${channelId}`).emit('message:new', result.rows[0]);
});
```

**Key security detail:**
```js
const senderId = socket.user?.id;  // ← Always from verified JWT
```
The sender ID comes from the **authenticated socket user**, never from the client payload `data`. This prevents message spoofing.

**The RETURNING clause** uses subqueries to fetch `sender_name`, `sender_role`, `sender_avatar`, `parent_content`, and `parent_sender_name` in a single DB round-trip — the emitted `message:new` event has everything the UI needs to render immediately.

---

### 7. Typing Indicators

```js
socket.on('typing:start', ({ channelId, userName }) =>
  socket.to(`channel_${channelId}`).emit('typing:start', { userName })
);
socket.on('typing:stop', ({ channelId }) =>
  socket.to(`channel_${channelId}`).emit('typing:stop')
);
```

- `socket.to(room)` — Broadcasts to all sockets in the room **except** the sender.
- The client emits `typing:start` when the user begins typing; all other channel members receive it and display "X is typing...".
- `typing:stop` clears the indicator.

---

### 8. Direct Notifications

```js
socket.on('notification:send', ({ targetUserId, notification }) => {
  const targetSocket = onlineUsers.get(String(targetUserId));
  if (targetSocket) io.to(targetSocket).emit('notification:new', notification);
});
```

- Looks up the target user's current socket ID from `onlineUsers`.
- If the user is online, sends the notification **directly** to their socket.
- If offline, no action — they'll see it on next login via the REST `/api/notifications` endpoint.

---

### 9. Disconnect Handler

```js
socket.on('disconnect', () => {
  if (socket.user) {
    onlineUsers.delete(String(socket.user.id));
  }
});
```

Cleans up `onlineUsers` when a connection closes (tab closed, app backgrounded, network lost). Prevents stale entries pointing to dead sockets.

---

### 10. Socket Event Reference

| Event (Client → Server) | Handler | What it does |
|---|---|---|
| `connection` (automatic) | Auth block | Verify JWT, populate `socket.user` |
| `channel:join` | `socket.join(...)` | Add to room for broadcast |
| `channel:leave` | `socket.leave(...)` | Remove from room |
| `message:send` | DB insert + broadcast | Persist message, emit `message:new` to room |
| `typing:start` | Relay to room | Show typing indicator to others |
| `typing:stop` | Relay to room | Hide typing indicator |
| `notification:send` | Direct emit | Send notification to specific user socket |
| `disconnect` | Cleanup | Remove from `onlineUsers` Map |

| Event (Server → Client) | Triggered by | Payload |
|---|---|---|
| `message:new` | `message:send` | Full message object with sender info |
| `typing:start` | `typing:start` relay | `{ userName }` |
| `typing:stop` | `typing:stop` relay | (none) |
| `notification:new` | `notification:send` | Notification object |
| `error` | Auth failure | `{ message }` |

---

### 11. Final Summary

`socketHandler.js` implements EduSync's entire real-time layer. The security model is sound: all write operations use `socket.user.id` (server-verified JWT identity), never client-supplied data. The `onlineUsers` Map enables direct messaging but is reset on server restart — acceptable for single-server deployment but would need Redis Pub/Sub for horizontal scaling.
