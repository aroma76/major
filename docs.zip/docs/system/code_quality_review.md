# 🔍 Code Quality Review — Complete Analysis

**Scope:** Entire ADTU StudyHub codebase (Backend + Frontend)

---

## 1. ✅ Strengths (Best Practices Used Well)

### Backend
| Area | Practice | Quality |
|---|---|---|
| Authentication | JWT with role in payload (no DB per request) | ⭐⭐⭐⭐⭐ |
| Password security | bcrypt cost-10, strong regex, no storage of plaintext | ⭐⭐⭐⭐⭐ |
| Rate limiting | Global + login-specific rate limiters | ⭐⭐⭐⭐⭐ |
| Error handling | Consistent JSON format, no stack traces in production | ⭐⭐⭐⭐⭐ |
| SQL security | 100% parameterized queries — no SQL injection risk | ⭐⭐⭐⭐⭐ |
| HTTP security | Helmet.js CSP, HSTS, XSS protection | ⭐⭐⭐⭐ |
| File uploads | MIME filtering, size limits, Supabase Storage | ⭐⭐⭐⭐ |
| Real-time | Socket.IO room-based broadcasting | ⭐⭐⭐⭐ |
| Connection pooling | pg Pool with appropriate limits | ⭐⭐⭐⭐ |

### Frontend
| Area | Practice | Quality |
|---|---|---|
| Offline-first | Cache-before-API in MessagesNotifier | ⭐⭐⭐⭐⭐ |
| Lazy loading | _LazyIndexedStack — zero wasted renders | ⭐⭐⭐⭐⭐ |
| Dispose safety | `_disposed` guard in MessagesNotifier | ⭐⭐⭐⭐⭐ |
| State management | Riverpod with keepAlive strategy | ⭐⭐⭐⭐ |
| Cross-platform storage | Platform-aware token storage | ⭐⭐⭐⭐⭐ |
| Token auto-injection | Dio interceptor | ⭐⭐⭐⭐⭐ |
| Socket listener deduplication | off() before on() pattern | ⭐⭐⭐⭐ |
| Performance | RepaintBoundary, MediaQuery.sizeOf | ⭐⭐⭐⭐ |

---

## 2. 🐛 Bugs & Issues

### HIGH Priority

#### Bug 1: Assignment Submission Upload Order
**File:** `backend/routes/assignmentRoutes.js`
```js
// WRONG — upload runs AFTER controller
router.post('/:assignId/submit', protect, authorize('student'), submitAssignment, upload.single('file'));
```
**Problem:** `req.file` is `undefined` inside `submitAssignment` because `upload.single('file')` hasn't run yet.

**Fix:**
```js
router.post('/:assignId/submit', protect, authorize('student'), upload.single('file'), submitAssignment);
```

---

#### Bug 2: Role Change Not Propagated to Active Sessions
**Files:** `middleware/auth.js`, `authController.js`

**Problem:** If an admin promotes a student to faculty, their existing JWT still has `role: 'student'` for up to 7 days. They can't access faculty endpoints until their token expires.

**Fix options:**
- Short token expiry (1hr) + refresh token pattern
- Token blacklist with Redis
- DB-based session table

---

#### Bug 3: Optimistic Delete Without Rollback
**File:** `frontend/providers/messages_notifier.dart`
```dart
void remove(int msgId) {
  state = state.copyWith(messages: state.messages.where((m) => m.id != msgId).toList());
}
```
**Problem:** If the DELETE API call fails, the message stays deleted in UI but exists in the database. The discrepancy persists until the user reloads.

**Fix:**
```dart
void remove(int msgId, ApiService api, int channelId) async {
  // Optimistic: remove from UI
  state = state.copyWith(messages: state.messages.where((m) => m.id != msgId).toList());
  try {
    await api.deleteMessage(channelId, msgId);
  } catch (_) {
    // Rollback: re-fetch or re-insert the message
  }
}
```

---

#### Bug 4: AcademicEvents Missing Authorization
**File:** `backend/routes/academicEventRoutes.js`
```js
router.post('/', protect, createAcademicEvent); // Missing authorize()
```
**Problem:** Any authenticated student can create academic events.
**Fix:** Add `authorize('admin', 'faculty')`.

---

### MEDIUM Priority

#### Bug 5: No 401 Interceptor in Dio
**File:** `frontend/core/services/api_service.dart`

**Problem:** When a token expires mid-session, all API calls return 401. The app shows error states but doesn't auto-logout or redirect to login.

**Fix:**
```dart
_dio.interceptors.add(InterceptorsWrapper(
  onError: (error, handler) async {
    if (error.response?.statusCode == 401) {
      await AuthService().logout();
      // Signal auth notifier to go unauthenticated
    }
    handler.next(error);
  },
));
```

---

#### Bug 6: No Socket Auto-Reconnect
**File:** `frontend/core/services/socket_service.dart`

**Problem:** If network connection drops, the socket disconnects and never reconnects. Users stop receiving real-time messages.

**Fix:**
```dart
io.OptionBuilder()
  .enableReconnection()
  .setReconnectionAttempts(5)
  .setReconnectionDelay(2000)
  .build()
```
Plus: re-join channels after reconnect (`joinChannel(channelId)`).

---

#### Bug 7: `isRead` Field Not `final` in `AppNotification`
**File:** `frontend/lib/core/theme/app_colors.dart`
```dart
bool isRead;  // Should be: final bool isRead;
```
**Problem:** Technically mutable. `markAsRead()` creates a new object anyway, so the field is effectively immutable — but the non-final declaration is misleading.

---

### LOW Priority

#### Bug 8: MIME Type Spoofing Not Prevented
**File:** `backend/middleware/upload.js`

**Problem:** MIME type check uses `file.mimetype` which is client-provided. A user can rename `malware.exe` to `notes.pdf` and upload it.

**Better Fix:** Use `file-type` library to inspect file header bytes:
```js
import { fileTypeFromBuffer } from 'file-type';
const type = await fileTypeFromBuffer(buffer.slice(0, 4100));
if (type?.mime === 'application/x-msdownload') reject();
```

---

## 3. ⚠️ Security Risks

| Risk | Severity | Location |
|---|---|---|
| Token in URL query param | Medium | `downloadRoutes.js` (necessary tradeoff) |
| `rejectUnauthorized: false` SSL | Low | `db.js` (Neon compatibility) |
| Web localStorage for JWT | Medium | `StorageService` — XSS can steal it |
| No CSP nonce for inline scripts | Low | Helmet config |
| Missing role check on events create | High | `academicEventRoutes.js` |
| No virus scanning on uploads | Medium | `upload.js` |
| No upload rate limiting per user | Medium | Anyone can spam file uploads |

---

## 4. 📈 Performance Bottlenecks

### Backend
| Bottleneck | Impact | Fix |
|---|---|---|
| No query caching | Every request hits PostgreSQL | Add Redis for `getChannels()`, `getAssignments()` |
| `getAllAssignments` N parallel requests | 8 HTTP calls per student per load | Consolidate into one DB query with JOIN |
| Full buffer in memory for uploads | 50MB RAM per concurrent upload | Stream multipart directly to Supabase |
| N+1 queries in some controllers | Multiple DB round-trips | Consolidate with JOINs |
| No DB connection retry | Server crash on Neon cold start | Add retry with exponential backoff |

### Frontend
| Bottleneck | Impact | Fix |
|---|---|---|
| No image caching | Profile avatars re-downloaded each time | Use `cached_network_image` package |
| Notification badge full rebuild | Re-renders entire TopBar on every message | Use `Consumer` only around the badge |
| `isSaved()` O(n) check | Slow for large saved file collections | Use a `Set<String>` for O(1) lookup |

---

## 5. 🔧 Refactoring Suggestions

### High Value

1. **Split `app_colors.dart`** into separate files:
   - `app_colors.dart` — color constants only
   - `theme_provider.dart` — `ThemeModeNotifier`
   - `notification_state_provider.dart` — `NotificationNotifier`
   - `settings_provider.dart` — `NotificationsEnabledNotifier`, `EmailSummaryEnabledNotifier`

2. **Add typed models for untyped responses:**
   - `AnnouncementModel` instead of `Map<String, dynamic>`
   - `NotificationModel` instead of `Map<String, dynamic>`
   - `ProjectModel` (API version) instead of `Map<String, dynamic>`

3. **Create custom `AppException` class:**
   ```js
   class AppError extends Error {
     constructor(message, status) {
       super(message);
       this.status = status;
     }
   }
   throw new AppError('Not found', 404);
   ```

4. **Merge notification systems:**
   - `notificationProvider` (local) and `notificationsApiProvider` (API) should sync.

5. **Add input validation middleware:**
   ```js
   const { body, validationResult } = require('express-validator');
   router.post('/register', [
     body('email').isEmail(),
     body('password').isLength({ min: 8 }),
   ], register);
   ```

---

## 6. 📊 Scalability Concerns

| Concern | Current State | At Scale |
|---|---|---|
| `onlineUsers` Map | In-memory per server | Doesn't work with multiple server instances |
| No horizontal scaling | Single Node.js instance | Need Redis for socket state |
| Neon.tech free tier | 5 connections | Paid tier or PgBouncer for hundreds of users |
| `Future.wait` for assignments | N API calls per load | Single aggregated backend query |
| No CDN for Supabase files | Direct Supabase origin | Enable Supabase CDN in settings |

---

## 7. ✅ Overall Assessment

| Category | Score | Notes |
|---|---|---|
| Security | 8.5/10 | Strong JWT, bcrypt, RLS. Minor gaps in MIME validation and role checks |
| Code Quality | 8/10 | Clean, well-structured. Some mixed responsibilities |
| Performance | 7/10 | Good frontend lazy-loading. Backend needs caching layer |
| Scalability | 6/10 | Single-server design. Would need Redis + multiple instances for scale |
| Error Handling | 8/10 | Consistent backend format. Frontend missing 401 auto-logout |
| Testing | 2/10 | No test files found. Major gap for production readiness |
| Documentation | 9/10 (after this!) | You're reading it |

**Overall: 7.5/10 — A solid, well-architected university-scale application with clear pathways to production hardening.**
