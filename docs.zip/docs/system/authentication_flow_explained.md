# 🔐 Authentication Flow — Complete System Documentation

**Covers:** `authController.js`, `auth.js` middleware, `AuthService.dart`, `AuthNotifier`, `StorageService.dart`, `LoginScreen.dart`

---

## 1. Complete Authentication Journey

### Phase 1: New User Registration

```
User fills signup form in Flutter
  │
  ├── Validation: name, email, rollNumber, dob, programmeId, batchYear
  │
  ▼
AuthService.signup(...)
  │
  ▼
ApiService → POST /api/auth/register
  │ Body: { name, email, roll_number, dob, programme_id, batch_year, role: 'student' }
  │
  ▼
authController.register()
  │
  ├── Check password strength (regex: 8+ chars, letter + digit)
  ├── Check email uniqueness: SELECT id FROM users WHERE email = $1
  ├── Check roll_number uniqueness: SELECT id FROM users WHERE roll_number = $1
  ├── Hash password: bcrypt.hash(password, 10)  [~100ms]
  ├── Generate avatar initials: "Rahul Kumar" → "RK"
  └── INSERT INTO users (...) RETURNING id, name, email, role
        │
        ▼
  Generate JWT: jwt.sign({ id, role, name, email }, JWT_SECRET, { expiresIn: '7d' })
        │
        ▼
  Response: { success: true, token: "eyJ...", user: { id, name, email, role } }
        │
        ▼
AuthService saves token: StorageService.write('adtu_token', token)
AuthService caches user: _currentUser = data['user']
        │
        ▼
AuthNotifier sets state: AsyncData(AuthState(authenticated, user))
        │
        ▼
_AuthGate detects authenticated → Navigate to MainDashboardScreen
SocketService.connect() — WebSocket connects with JWT in handshake
```

---

### Phase 2: Login (Returning User)

```
User enters identifier (roll number or email) + password
  │
  ▼
LoginScreen._login(isStudent)
  │
  ├── formKey.currentState!.validate() — client-side validation
  │     ├── identifier not empty
  │     └── password: min 6 chars (UI) ← different from backend's 8 chars!
  │
  ▼
AuthNotifier.login(identifier, password)
  │ Sets isLoggingIn = true → state = AsyncData(unauthenticated)
  │ → LoginScreen rebuilds with spinner in button
  │
  ▼
AuthService.login(identifier, password)
  │
  ▼
ApiService → POST /api/auth/login { identifier, password }
  │ Rate limited: 10 attempts / 15 minutes per IP
  │
  ▼
authController.login()
  │
  ├── Detect type: identifier.includes('@') ? email : roll_number
  ├── SELECT * FROM users WHERE [email|roll_number] = $1
  ├── if not found → 401 "Invalid credentials" (same message for security)
  ├── bcrypt.compare(password, user.password) → match?
  ├── if no match → 401 "Invalid credentials"
  └── Generate JWT { id, role, name, email }
        │
        ▼
  Response: { success: true, token, user: { ...without password } }
        │
        ▼
AuthService.login() processes response:
  ├── _currentUser = data['user']
  └── StorageService.write('adtu_token', token)
        │
        ▼
AuthNotifier:
  ├── isLoggingIn = false
  └── state = AsyncData(AuthState(authenticated, user))
        │
        ▼
_AuthGate detects authenticated → routes to MainDashboardScreen
SocketService.connect() → connects WebSocket with new JWT
```

---

### Phase 3: Session Restoration (App Re-launch)

```
App launches → main.dart
  │
  ▼
_AuthGate watches authProvider
  │
  ▼
authProvider.build() runs: await _auth.restoreSession()
  │
  ├── StorageService.read('adtu_token')
  │     ├── null → return false → AuthState(unauthenticated)
  │     └── token found →
  │
  ▼
ApiService → GET /api/auth/me
  │ Dio interceptor auto-attaches: Authorization: Bearer {stored_token}
  │
  ▼
protect middleware:
  ├── Extract token from header
  ├── jwt.verify(token, JWT_SECRET)
  │     ├── Expired → 401 → catch(_) { logout(); return false; }
  │     ├── Invalid → 401 → same
  │     └── Valid → decoded = { id, role, name, email }
  └── 'role' in decoded?
        ├── Yes → req.user = decoded (no DB query)
        └── No → SELECT * FROM users WHERE id = $1
  │
  ▼
getMe() → res.json({ success: true, user: req.user })
  │
  ▼
AuthService:
  ├── _currentUser = response.data['user']
  └── return true
        │
        ▼
AuthNotifier:
  └── AuthState(authenticated, user: _auth.currentUser)
        │
        ▼
_AuthGate → MainDashboardScreen (user sees dashboard immediately)
```

---

### Phase 4: Logout

```
User taps "Logout" in SettingsViewWidget
  │
  ▼
ref.read(authProvider.notifier).logout()
  │
  ├── _auth.logout()
  │     ├── _currentUser = null
  │     ├── SocketService().disconnect()  [close WebSocket]
  │     └── StorageService.delete('adtu_token')  [clear JWT]
  │
  ├── ref.invalidate(channelsProvider)
  ├── ref.invalidate(allAssignmentsProvider)
  ├── ref.invalidate(notificationsApiProvider)
  ├── ref.invalidate(projectsProvider)
  ├── ref.invalidate(teacherStatsProvider)
  ├── ref.invalidate(dashboardRecentActivityProvider(true))
  └── ref.invalidate(dashboardRecentActivityProvider(false))
        │
        ▼
state = AsyncData(AuthState(unauthenticated))
        │
        ▼
_AuthGate detects unauthenticated → LoginScreen()
```

---

## 2. JWT Token Structure

```
Header.Payload.Signature
```

**Header (Base64):**
```json
{ "alg": "HS256", "typ": "JWT" }
```

**Payload (Base64, NOT encrypted):**
```json
{
  "id": 42,
  "role": "student",
  "name": "Rahul Kumar",
  "email": "rahul@adtu.in",
  "iat": 1716000000,  // issued at
  "exp": 1716604800   // expires at (7 days later)
}
```

**Signature:**
`HMACSHA256(base64(header) + "." + base64(payload), JWT_SECRET)`

**Key points:**
- The payload is BASE64 encoded, not encrypted — anyone can decode it.
- The SIGNATURE is what makes it tamper-proof — changing any byte invalidates it.
- The role is embedded → no DB query needed per request.
- Token is stateless → any server replica can verify it.

---

## 3. WebSocket Authentication

```
Flutter SocketService.connect()
  │
  └── io.OptionBuilder()
        .setAuth({ 'token': storedJwt })
        .build()
  │
  ▼
Socket.IO handshake: { auth: { token: "eyJ..." } }
  │
  ▼
socketHandler.js: socket.handshake.auth?.token
  │
  ├── jwt.verify(token, JWT_SECRET) → decoded
  ├── SELECT id, name, role FROM users WHERE id = $1
  │     (Note: always does DB query — unlike HTTP middleware)
  └── socket.user = { id, name, role }
  │
  ▼
All subsequent socket events use socket.user.id (server-verified)
```

---

## 4. Security Threat Model

| Threat | Defense |
|---|---|
| Password guessing | bcrypt (slow hash) + 10/15min rate limit |
| Token theft | Secure storage (Keychain/Keystore), short expiry |
| Token forgery | HMAC signature with server-side secret |
| Role escalation | Role never accepted from client, only from DB/JWT |
| Account enumeration | Same error message for wrong user vs wrong password |
| CSRF | Bearer tokens immune to CSRF (not cookies) |
| XSS token theft | Mobile: OS keychain. Web: localStorage (risk accepted) |
| Token reuse after logout | Token deleted from storage; socket disconnected |
| Replay attacks | JWT `exp` field; token naturally expires |

---

## 5. Token Lifecycle State Machine

```
                    ┌──────────┐
         ──────────▶│  ABSENT  │◀────────────
        │           └────┬─────┘            │
        │                │ register/login    │ logout
        │                ▼                  │
        │          ┌──────────┐            │
        │          │  STORED  │────────────┘
        │          └────┬─────┘
        │               │ app launch
        │               ▼
        │         jwt.verify()
        │         │         │
        │      valid      expired/invalid
        │         │         │
        │    ┌────▼──┐    ┌─▼──────┐
        └────│ VALID │    │INVALID │──── logout → ABSENT
             └───────┘    └────────┘
```
