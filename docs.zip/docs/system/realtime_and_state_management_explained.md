# ⚡ Real-Time Architecture & State Management Lifecycle

---

## Part 1: Socket.IO Real-Time Architecture

### Complete Message Flow (Text Message)

```
Student types in MessagesViewWidget text field
  │
  ▼
User taps Send
  │
  ▼
SocketService.sendMessage(channelId: 42, content: "Hello")
  │ emits: { event: 'message:send', data: { channelId: 42, content: 'Hello' } }
  │
  ▼ [WebSocket]
  │
  ▼
socketHandler.js: socket.on('message:send', async (data) => {
  │
  ├── senderId = socket.user.id   ← from JWT, NOT from client data
  ├── INSERT INTO messages (channel_id, sender_id, content) VALUES ($1, $2, $3)
  │   RETURNING *, (SELECT name FROM users WHERE id = $2) AS sender_name, ...
  └── io.to('channel_42').emit('message:new', savedMessage)
  │
  ▼ [broadcast to all sockets in channel_42 room]
  │
  ▼
ALL clients in 'channel_42':
  │
  ▼
SocketService.onNewMessage(callback)  ← listener registered in widget
  │ callback(Map<String, dynamic>.from(data))
  │
  ▼
messagesNotifierProvider.notifier.append(
  ApiMessageModel.fromJson(data)
)
  │
  ▼
MessagesNotifier.state = state.copyWith(messages: [...state.messages, msg])
  │
  ▼
Riverpod detects state change → rebuilds MessagesListView
  │
  ▼
New message appears at bottom of chat
```

---

### Complete Message Flow (File Upload)

```
User taps attachment icon → selects file
  │
  ▼
MessagesViewWidget creates FormData with file bytes
  │
  ▼
ApiService.sendFileMessage(channelId, formData)  ← REST, not Socket
  │ POST /api/channels/42/messages (multipart/form-data)
  │
  ▼
Multer intercepts → SupabaseStorage._handleFile()
  │ 1. Buffer all file bytes
  │ 2. supabase.storage.from('files').upload(path, buffer)
  │ 3. supabase.storage.from('files').getPublicUrl(path)
  │ 4. cb(null, { path: 'https://...supabase.co/.../file.pdf' })
  │
  ▼
req.file = { path: 'https://...supabase.co/.../file.pdf', ... }
  │
  ▼
messageController.sendMessage()
  │ INSERT INTO messages (channel_id, sender_id, file_url, file_name)
  │ RETURNING *, (SELECT name ...) AS sender_name, ...
  │
  └── if (_io) _io.to('channel_42').emit('message:new', savedMessage)
  │   [broadcasts the new file message via socket]
  │
  ▼ [same as text message from here]
```

---

### Announcement Real-Time Flow

```
Faculty creates announcement in SubjectsViewWidget
  │
  ▼
AnnouncementRepository.createAnnouncement(channelId, data)
  │
  ▼
POST /api/channels/42/announcements
  │
  ▼
announcementController.createAnnouncement()
  │ INSERT INTO announcements (channel_id, author_id, title, content)
  │
  └── Get socket IO instance: const { getIO } = require('./messageController');
      const io = getIO();
      io?.to('channel_42').emit('announcement:new', announcementData);
  │
  ▼
SocketService.onNewAnnouncement(callback)
  │ (registered in TopBarWidget and TodayOverviewWidget)
  │
  ▼
AnnouncementsPanel state updates → new announcement appears instantly
TopBarWidget notification badge increments
```

---

## Part 2: Riverpod State Management Lifecycle

### Provider Lifecycle

```
App starts
  │
  ▼
ProviderScope created (in main.dart)
  │ All providers are in "uninitialized" state
  │
  ▼
_AuthGate widget builds → watches authProvider
  │
  ▼
authProvider initializes → AsyncNotifier.build() runs
  │ state = AsyncLoading while build() is pending
  │ → _AuthGate shows loading screen
  │
  ▼
build() completes → state = AsyncData(AuthState(...))
  │
  ├── Unauthenticated → _AuthGate shows LoginScreen
  │   No other providers initialize (lazy)
  │
  └── Authenticated → _AuthGate shows MainDashboardScreen
        │
        ▼
   MainDashboardScreen builds
   _LazyIndexedStack: only index 0 (Home) builds initially
        │
        ▼
   TodayOverviewWidget builds
   → watches dashboardRecentActivityProvider(false)
   → FutureProvider.build() runs: GET /teacher/student-activity
   → state = AsyncLoading → shows loading skeleton
   → state = AsyncData → shows content
   → ref.keepAlive() (on success)
        │
        ▼
   User navigates to index 1 (Subjects)
   _LazyIndexedStack adds 1 to _loaded
   SubjectsViewWidget builds
   → watches channelsProvider
   → if channelsProvider already loaded (keepAlive), instant display
   → else: GET /channels → AsyncLoading → AsyncData
```

---

### `keepAlive()` vs `autoDispose` Behavior

| Provider | keepAlive | Effect |
|---|---|---|
| `channelsProvider` | Yes | Never garbage-collected; persists all session |
| `allAssignmentsProvider` | Yes | Persists; depends on channels |
| `notificationsApiProvider` | Yes | Persists; bell panel opens instantly |
| `teacherStatsProvider` | Yes | Expensive query; cached |
| `dashboardRecentActivityProvider` | Conditional (on success) | Error state is disposable; success is cached |
| `channelAssignmentsProvider.family` | No | Disposed when widget disposes |
| `channelAnnouncementsProvider.family` | No | Disposed when widget disposes |
| `messagesNotifierProvider.autoDispose.family` | No | Disposed when leaving Messages view |

---

### Navigation State Flow

```
User on Home (index 0) → taps Subjects in sidebar

ref.read(navigationProvider.notifier).navigateTo(1)
  │
  ▼
NavigationNotifier.state = 1
  │
  ▼
MainDashboardScreen rebuilds (watches navigationProvider)
  │
  ▼
_LazyIndexedStack.didUpdateWidget called
  │ _loaded = {0}; widget.index = 1
  │ !_loaded.contains(1) → setState(() => _loaded.add(1))
  │
  ▼
IndexedStack rebuilds:
  i=0: SidebarWidget (loaded, hidden)
  i=1: SubjectsViewWidget (newly built)
  i=2..7: SizedBox.shrink() (never visited)
  │
  ▼
SubjectsViewWidget.build() runs
  │ ref.watch(channelsProvider) → already loaded? show instantly : fetch
```

---

## Part 3: Complete Data Flow Diagram

```
                          Flutter Frontend
┌──────────────────────────────────────────────────────┐
│                                                      │
│  Widget                                              │
│    │ ref.watch(channelsProvider)                     │
│    ▼                                                 │
│  FutureProvider                                      │
│    │ if !loaded → calls                              │
│    ▼                                                 │
│  ChannelRepository.getMyChannels()                   │
│    │                                                 │
│    ▼                                                 │
│  ApiService.getChannels()  [Dio]                    │
│    │ GET /api/channels                               │
│    │ Authorization: Bearer eyJ...                   │
└────┼─────────────────────────────────────────────────┘
     │ HTTPS
     ▼
┌────────────────────────────────────────────────────┐
│                   Backend                          │
│                                                    │
│  server.js: app.use('/api/channels', channelRoutes)│
│    │                                               │
│    ▼                                               │
│  protect middleware → jwt.verify() → req.user     │
│    │                                               │
│    ▼                                               │
│  channelController.getChannels()                   │
│    │                                               │
│    │  SELECT c.*, u.name AS teacher_name           │
│    │  FROM channels c                              │
│    │  INNER JOIN enrollments e ON c.id=e.channel_id│
│    │  LEFT JOIN users u ON c.created_by=u.id       │
│    │  WHERE e.user_id = $1                         │
│    ▼                                               │
│  pool.query() → PostgreSQL (Neon)                  │
│    │                                               │
│    ▼                                               │
│  res.json({ success: true, channels: [...] })      │
└────┼───────────────────────────────────────────────┘
     │ JSON Response
     ▼
┌────────────────────────────────────────────────────┐
│  Flutter Frontend                                  │
│                                                    │
│  Dio receives Response                             │
│    │                                               │
│    ▼                                               │
│  ChannelRepository parses:                         │
│  list.map((e) => ChannelModel.fromJson(e))         │
│    │                                               │
│    ▼                                               │
│  FutureProvider state = AsyncData([...models])     │
│    │                                               │
│    ▼                                               │
│  Widget rebuilds with channel list                 │
└────────────────────────────────────────────────────┘
```

---

## Part 4: State Management Pattern Summary

The app uses **Riverpod v2/v3** with three provider types:

| Type | Use Case | Example |
|---|---|---|
| `AsyncNotifierProvider` | Complex async state with methods | `authProvider` |
| `FutureProvider` | Simple async data fetch, read-only | `channelsProvider` |
| `FutureProvider.family` | Async data parameterized by ID | `channelAssignmentsProvider(42)` |
| `NotifierProvider` | Synchronous state with methods | `navigationProvider`, `taskProvider` |
| `NotifierProvider.family` | Parameterized sync state | (not used here) |
| `NotifierProvider.autoDispose.family` | Per-channel message state | `messagesNotifierProvider(42)` |
| `Provider` | Derived/computed state | `filteredTasksProvider` |
