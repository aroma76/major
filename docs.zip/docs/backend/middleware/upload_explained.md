# 📄 `middleware/upload.js` — Complete Explanation

**File Path:** `backend/middleware/upload.js`
**Lines:** 79
**Role:** Custom Multer storage engine that streams file uploads directly to Supabase Storage.

---

## 1. 📌 File Purpose

This middleware intercepts multipart file uploads, streams the file bytes to Supabase Cloud Storage, and returns the file's public URL as `req.file.path` — so controllers can use it exactly as they would with disk-based storage.

> **Beginner Analogy:** Imagine a post office (the server) that receives a parcel (file upload). Instead of keeping the parcel in its own storeroom (local disk), it immediately forwards it to a secure warehouse (Supabase Storage) and gives you a tracking number (public URL).

---

## 2. 🔗 Imports

```js
const multer = require('multer');
const { supabase, BUCKET } = require('../config/supabase');
```

| Import | Purpose |
|---|---|
| `multer` | Node.js middleware for handling `multipart/form-data` (file uploads) |
| `supabase` | The Supabase client for storage operations |
| `BUCKET` | The constant `'files'` — the name of the storage bucket |

---

## 3. 📁 Folder Path

```js
const FOLDER = 'adtu-collab';
```

All files are uploaded under this virtual folder inside the `files` bucket. The full path in Supabase Storage looks like:
`files/adtu-collab/1716000000000-assignment1.pdf`

---

## 4. 🏗️ `SupabaseStorage` Class — Complete Line-by-Line

This is a **custom Multer storage engine**. Multer defines an interface: any storage engine must implement `_handleFile()` and `_removeFile()`.

### `_handleFile()` — Upload to Supabase

```js
async _handleFile(req, file, cb) {
  const chunks = [];
  file.stream.on('data', (chunk) => chunks.push(chunk));
  file.stream.on('error', cb);
  file.stream.on('end', async () => {
    try {
      const buffer = Buffer.concat(chunks);
      const safeName = file.originalname.replace(/\s+/g, '_');
      const storagePath = `${FOLDER}/${Date.now()}-${safeName}`;

      const { error } = await supabase.storage
        .from(BUCKET)
        .upload(storagePath, buffer, {
          contentType: file.mimetype,
          upsert: false,
        });

      if (error) return cb(error);

      const { data } = supabase.storage
        .from(BUCKET)
        .getPublicUrl(storagePath);

      cb(null, {
        path        : data.publicUrl,
        filename    : file.originalname,
        size        : buffer.length,
        storagePath,
      });
    } catch (err) {
      cb(err);
    }
  });
}
```

#### Stream Buffering
```js
const chunks = [];
file.stream.on('data', (chunk) => chunks.push(chunk));
file.stream.on('error', cb);
file.stream.on('end', async () => { ... });
```
- `file.stream` — Multer provides the incoming file as a Node.js readable stream.
- `.on('data', chunk => chunks.push(chunk))` — Collects every chunk of bytes as they arrive.
- `.on('error', cb)` — If the stream errors (network drop, etc.), call Multer's callback with the error.
- `.on('end', ...)` — After all bytes are received, proceed with the upload.

> **Why buffer first?** Supabase Storage's Node.js SDK requires a complete Buffer or Blob — it doesn't accept a stream directly in this version.

#### Building the Buffer
```js
const buffer = Buffer.concat(chunks);
```
- Merges all chunks into a single contiguous `Buffer` (raw bytes in memory).
- This is the complete file in memory. For a 10MB file, this uses 10MB of RAM per concurrent upload.

#### Sanitizing the Filename
```js
const safeName = file.originalname.replace(/\s+/g, '_');
const storagePath = `${FOLDER}/${Date.now()}-${safeName}`;
```
- Replaces spaces with underscores. Spaces in URLs cause issues.
- Prepends `Date.now()` (Unix timestamp in ms) to make filenames unique.
- Example: `adtu-collab/1716123456789-Lecture_Notes.pdf`
- Without the timestamp, two files with the same name would overwrite each other.

#### Uploading to Supabase
```js
const { error } = await supabase.storage
  .from(BUCKET)
  .upload(storagePath, buffer, {
    contentType: file.mimetype,
    upsert: false,
  });
```
- `supabase.storage.from(BUCKET)` — Targets the `'files'` bucket.
- `.upload(path, data, options)` — Uploads the buffer to Supabase.
- `contentType: file.mimetype` — Sets the MIME type (e.g., `application/pdf`, `image/jpeg`) for proper browser handling.
- `upsert: false` — Don't overwrite existing files. If a file exists at this path, return an error. (The timestamp prefix makes collisions virtually impossible.)

#### Getting the Public URL
```js
const { data } = supabase.storage
  .from(BUCKET)
  .getPublicUrl(storagePath);
```
- This is a **synchronous** call (no `await`) — it just builds the URL string locally without making a network request.
- Returns: `{ data: { publicUrl: 'https://xyz.supabase.co/storage/v1/object/public/files/adtu-collab/...' } }`

#### Calling the Multer Callback
```js
cb(null, {
  path        : data.publicUrl,   // ← controllers read this as the file URL
  filename    : file.originalname,
  size        : buffer.length,
  storagePath,
});
```
- `cb(null, fileInfo)` — Tells Multer the upload succeeded.
- Multer merges this object into `req.file`.
- Controllers access `req.file?.path` to get the Supabase public URL.
- `storagePath` is stored for potential future deletion.

### `_removeFile()` — Delete from Supabase

```js
_removeFile(req, file, cb) {
  if (file.storagePath) {
    supabase.storage.from(BUCKET).remove([file.storagePath]).catch(() => {});
  }
  cb(null);
}
```

- Called by Multer if something fails after upload (e.g., validation error in a later middleware).
- `.remove([storagePath])` — Deletes the file from Supabase.
- `.catch(() => {})` — Silently ignores deletion failures.
- `cb(null)` — Always signals success to avoid blocking the error response.

---

## 5. 🚫 File Filter

```js
const fileFilter = (req, file, cb) => {
  const blockedMimes = [
    'application/x-msdownload',   // .exe files
    'application/x-bat',          // .bat scripts
    'application/x-msdos-program', // .com files
  ];
  if (blockedMimes.includes(file.mimetype)) {
    return cb(new Error('Executable files are not allowed for security reasons'), false);
  }
  cb(null, true);
};
```

**Line-by-Line:**
- Blocks executable file types before they are even buffered.
- `cb(error, false)` — Rejects the file and passes an error to the error handler.
- `cb(null, true)` — Accepts all other file types.

> **Security Note:** MIME type checking is client-provided and can be spoofed. A malicious user could rename `malware.exe` to `malware.pdf` and set the MIME type to `application/pdf`. A deeper check using the `file-type` library (which is a dependency in `package.json`) would inspect the actual file header bytes. This is a minor gap in the current implementation.

---

## 6. 📤 Multer Instance

```js
const upload = multer({
  storage  : new SupabaseStorage(),
  fileFilter,
  limits   : { fileSize: 50 * 1024 * 1024 }, // 50 MB
});

module.exports = upload;
```

- `storage: new SupabaseStorage()` — Uses the custom storage engine.
- `fileFilter` — Applied before buffering begins.
- `limits.fileSize: 52,428,800` — Multer rejects files larger than 50MB before they're fully buffered.

**Usage in routes:**
```js
// Single file upload (field name 'file')
router.post('/', protect, upload.single('file'), sendMessage);

// Profile avatar upload
router.put('/profile', protect, upload.single('avatar'), updateProfile);
```

---

## 7. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Executable uploads | MIME type blocklist (weak — can be spoofed) |
| Large file DoS | 50MB limit in both Multer and Supabase |
| Filename injection | Spaces replaced with underscores |
| Path traversal | Timestamps and sanitized names prevent directory traversal |
| Unauthenticated uploads | `upload` middleware is always used AFTER `protect` in routes |

---

## 8. ⚡ Performance Considerations

| Issue | Impact |
|---|---|
| Full buffer in memory | A 50MB file uses 50MB of RAM per upload. Heavy concurrent uploads could exhaust memory. |
| No streaming | Could be improved with streaming multipart upload to Supabase |
| No CDN | Public Supabase URLs are served from a single region. No CDN optimization. |

---

## 9. 🐛 Possible Issues

1. **Memory usage** — Large files are buffered entirely in memory before upload. Under high concurrency, this could be a problem.
2. **MIME spoofing** — File type check relies on `file.mimetype` which is client-provided.
3. **No virus scanning** — Files are uploaded without antivirus scanning.
4. **`upsert: false`** — If timestamp collision occurs (same millisecond, same filename), Supabase returns an error and upload fails.

---

## 10. 🔄 Data Flow

```
Flutter Client
  │ multipart/form-data POST with file
  ▼
Multer middleware intercepts request
  │
  ▼
fileFilter checks MIME type → reject executables
  │
  ▼
SupabaseStorage._handleFile() called
  │
  ├── Collect stream chunks into buffer
  │
  ├── Sanitize filename
  │
  ├── Upload buffer to Supabase Storage
  │     └── Returns error OR success
  │
  ├── Get public URL (synchronous)
  │
  └── Call cb(null, { path: publicUrl, ... })
        │
        ▼
req.file = { path: 'https://...supabase.co/.../file.pdf', ... }
        │
        ▼
Controller reads req.file.path → saves URL to DB
```

---

## 11. ✅ Final Summary

`upload.js` is the **file pipeline** of the backend. It elegantly abstracts away the complexity of cloud storage behind Multer's simple `upload.single('file')` API. Controllers don't need to know anything about Supabase — they just read `req.file.path` and get a production-ready public URL. The custom storage engine pattern makes the code highly testable and replaceable (e.g., switching from Supabase to AWS S3 requires changing only this file).
