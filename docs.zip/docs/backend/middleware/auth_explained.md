# 📄 `middleware/auth.js` — Complete Explanation

**File Path:** `backend/middleware/auth.js`
**Lines:** 38
**Role:** JWT authentication guard and role-based authorization for all protected routes.

---

## 1. 📌 File Purpose

This file exports two Express middleware functions:
1. **`protect`** — Verifies that a request has a valid JWT token. Denies access if not.
2. **`authorize(...roles)`** — After `protect`, checks the user's role against allowed roles.

Every single protected API route uses these two functions as gatekeepers.

> **Beginner Analogy:**
> - `protect` = The security guard at the building entrance who checks your ID card.
> - `authorize` = The floor-specific access control that only allows managers to enter the executive floor.

---

## 2. 🔗 Imports

```js
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
```

| Import | Purpose |
|---|---|
| `jwt` | The `jsonwebtoken` library — verifies and decodes JWT tokens |
| `pool` | PostgreSQL connection pool — used only for legacy token fallback |

---

## 3. 🛡️ `protect` Middleware — Complete Line-by-Line

```js
const protect = async (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) return res.status(401).json({ success: false, message: 'Not authorized, no token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if ('role' in decoded) {
      req.user = decoded;
    } else {
      const result = await pool.query(
        'SELECT id, name, email, role, programme_id, batch_year, current_semester, roll_number, avatar_initials, avatar_url FROM users WHERE id = $1',
        [decoded.id]
      );
      if (result.rows.length === 0) return res.status(401).json({ success: false, message: 'User not found' });
      req.user = result.rows[0];
    }
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Token invalid or expired' });
  }
};
```

### Extracting the Token
```js
let token;
if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
  token = req.headers.authorization.split(' ')[1];
}
```
- `req.headers.authorization` — The HTTP `Authorization` header sent by the Flutter client.
- Expected format: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSw...`
- `.startsWith('Bearer ')` — Validates the token scheme (Bearer is the standard for JWT).
- `.split(' ')[1]` — Extracts just the token part after `'Bearer '`. Index `[1]` because split gives `['Bearer', 'token']`.

### Token Absence Check
```js
if (!token) return res.status(401).json({ success: false, message: 'Not authorized, no token' });
```
- If no Authorization header was sent (or it didn't start with `Bearer `), reject immediately with HTTP 401 Unauthorized.
- `return` terminates middleware execution — `next()` is never called so the controller never runs.

### JWT Verification
```js
const decoded = jwt.verify(token, process.env.JWT_SECRET);
```
- `jwt.verify()` performs **two operations simultaneously**:
  1. Verifies the signature — proves the token was issued by this server (using `JWT_SECRET`)
  2. Checks expiration — throws an error if the token has expired
- Returns the **payload** object embedded in the token: `{ id, role, name, email, iat, exp }`
- Throws `JsonWebTokenError` or `TokenExpiredError` if invalid — caught by the `catch` block.

### Modern Token Path (with `role` in payload)
```js
if ('role' in decoded) {
  req.user = decoded;
}
```
- Modern tokens (issued after a code update) embed `id`, `role`, `name`, `email` directly in the JWT payload.
- `'role' in decoded` — Checks if the `role` key exists in the decoded payload.
- If yes, assign the decoded token directly to `req.user` — **no database query needed!**
- This is a significant performance optimization: every authenticated request avoids a DB round-trip.

### Legacy Token Path (DB fallback)
```js
} else {
  const result = await pool.query(
    'SELECT id, name, email, role, ... FROM users WHERE id = $1',
    [decoded.id]
  );
  if (result.rows.length === 0) return res.status(401).json(...);
  req.user = result.rows[0];
}
```
- **Why does this exist?** Old tokens (before the role-embedding update) only had `id` in the payload.
- For backward compatibility, a DB lookup fetches the user's current data.
- `result.rows.length === 0` — The user was deleted after the token was issued.
- `req.user = result.rows[0]` — Populates `req.user` with the full database row.

### Calling `next()`
```js
next();
```
- Passes control to the next middleware or the route controller.
- Only called if token is valid and `req.user` is set.

### Error Catching
```js
} catch (err) {
  return res.status(401).json({ success: false, message: 'Token invalid or expired' });
}
```
- Catches any exception from `jwt.verify()`.
- Returns 401 for expired tokens, tampered signatures, or malformed tokens.
- Generic message — doesn't reveal whether it's expired vs. invalid (security best practice).

---

## 4. 🔓 `authorize(...roles)` Middleware — Line-by-Line

```js
const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role))
    return res.status(403).json({ success: false, message: `Role '${req.user.role}' is not authorized` });
  next();
};
```

### `...roles` — Rest Parameters
- `authorize('admin', 'faculty')` → `roles = ['admin', 'faculty']`
- The function accepts any number of allowed roles.

### Returns a Middleware Function
- `authorize(...)` is a **higher-order function** — it takes roles and returns a new middleware function.
- This pattern allows usage like: `router.post('/', protect, authorize('admin'), createChannel)`

### Role Check
```js
if (!roles.includes(req.user.role))
  return res.status(403).json(...)
```
- `req.user.role` — Set by `protect` (from the JWT payload or DB).
- If the user's role is NOT in the allowed list → HTTP 403 Forbidden.
- 403 ≠ 401: 401 = "Who are you?" (unauthenticated), 403 = "I know who you are, but you can't do this" (unauthorized).

### How It's Used
```js
// Only admin can create channels
router.post('/', protect, authorize('admin'), createChannel);

// Admin or faculty can create assignments
router.post('/', protect, authorize('admin', 'faculty'), createAssignment);

// Only students can submit
router.post('/:assignId/submit', protect, authorize('student'), submitAssignment);
```

---

## 5. 🔄 Execution Flow

```
HTTP Request arrives at protected route
  │
  ▼
protect middleware runs
  │
  ├── Extract token from Authorization header
  │
  ├── No token → 401 Unauthorized ← stop
  │
  ├── jwt.verify(token, JWT_SECRET)
  │     ├── Invalid/expired → 401 Unauthorized ← stop
  │     └── Valid → decoded = { id, role, name, email }
  │
  ├── 'role' in decoded?
  │     ├── Yes → req.user = decoded (no DB query)
  │     └── No (legacy) → DB query → req.user = db row
  │
  └── next() → continue to authorize() or controller
        │
        ▼
    authorize('admin', 'faculty') (if used)
        │
        ├── req.user.role in ['admin', 'faculty']?
        │     ├── No → 403 Forbidden ← stop
        │     └── Yes → next() → controller runs
        │
        ▼
    Controller executes with req.user populated
```

---

## 6. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Forged tokens | `jwt.verify()` checks HMAC signature — impossible to forge without `JWT_SECRET` |
| Token theft | Short expiry (`7d` default) limits exposure window |
| Role escalation | Role is read from JWT (server-signed) — client can't modify it |
| Timing attacks | `jwt.verify()` uses constant-time comparison internally |
| Deleted user access | Legacy path checks DB; modern path accepts until token expires |

---

## 7. ⚡ Performance Considerations

- **Modern tokens skip DB query** — Every request saves ~5-20ms of DB latency.
- **JWT is stateless** — The server doesn't store sessions; any server instance can validate any token.
- **Legacy fallback** — Only executes for old tokens. New logins always get modern tokens.

---

## 8. 🐛 Possible Issues

1. **`req.user = decoded` includes `iat` and `exp`** — Token metadata is mixed into `req.user`. Shouldn't cause bugs but is slightly untidy.
2. **Role change propagation** — If an admin changes a user's role, their existing JWT still has the old role until it expires (up to 7 days). No token revocation mechanism exists.
3. **No `Bearer` scheme flexibility** — Hardcoded `startsWith('Bearer ')` means `bearer` (lowercase) is rejected. HTTP specs are case-insensitive for schemes.

---

## 9. 📤 Export

```js
module.exports = { protect, authorize };
```

Both functions are named exports, used by every route file:
```js
const { protect, authorize } = require('../middleware/auth');
```

---

## 10. ✅ Final Summary

`auth.js` is the **security backbone** of the backend. In just 38 lines, it implements:
- Stateless JWT authentication
- Role-based access control
- Backward compatibility for old tokens
- Zero-DB-query performance for new tokens

Every controller in the system relies on `protect` to know **who** is making a request (`req.user`), and `authorize` to know **if** they're allowed to perform the action.
