# 📄 `middleware/errorHandler.js` — Complete Explanation

**File Path:** `backend/middleware/errorHandler.js`
**Lines:** 12
**Role:** Global Express error handler — formats all unhandled errors into consistent JSON responses.

---

## 1. File Purpose

This is the **last line of defense** for all errors in the backend. Any error that:
- Is thrown in a controller (via `throw new Error(...)`)
- Calls `next(err)` in middleware
- Is caught by `express-async-errors` from an async function

…will ultimately land here and be formatted into a clean JSON response.

> **Beginner Analogy:** If the backend were a factory, `errorHandler` is the safety net at the end of the assembly line. If anything breaks anywhere on the line, it falls into this net and gets packaged nicely before being sent to the customer.

---

## 2. Complete Line-by-Line Analysis

```js
const errorHandler = (err, req, res, next) => {
  console.error('❌ Error:', err.message);
  const status = err.status || 500;
  res.status(status).json({
    success: false,
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

module.exports = errorHandler;
```

### Signature: `(err, req, res, next)`
- Express identifies error-handling middleware by having **4 parameters** (regular middleware has 3).
- `err` — The error object (either thrown directly or passed to `next(err)`).
- `req`, `res`, `next` — Standard Express request/response/next. `next` is included in signature even though not used — required by Express's detection mechanism.

### `console.error('❌ Error:', err.message)`
- Logs the error message to the server's stdout.
- In production, this would typically be sent to a logging service (Sentry, Datadog).

### `const status = err.status || 500`
- Uses the error's `status` property if set, otherwise defaults to `500 Internal Server Error`.
- Controllers can set custom status codes: `const err = new Error('Not found'); err.status = 404; throw err;`
- The `||` fallback ensures an unknown error always returns 500.

### Stack Trace in Development
```js
...(process.env.NODE_ENV === 'development' && { stack: err.stack })
```
- `err.stack` — The full stack trace (which file/function/line the error originated from).
- In production, stack traces are never sent to clients (they reveal internal code structure — a security risk).
- `process.env.NODE_ENV === 'development' && { stack: err.stack }` — Short-circuit: if not development, evaluates to `false`, spreading `false` adds nothing.

---

## 3. How Errors Reach This Handler

### Path 1: `express-async-errors` (most common)
```js
// Any async controller that throws reaches errorHandler automatically:
const getAssignments = async (req, res) => {
  const result = await pool.query(...); // if this throws → errorHandler
};
```

### Path 2: Manual `next(err)`
```js
const someMiddleware = (req, res, next) => {
  try { ... } catch (err) { next(err); }
};
```

### Path 3: Custom error objects
```js
const err = new Error('Assignment not found');
err.status = 404;
throw err; // caught by express-async-errors → errorHandler
```

---

## 4. Security Considerations

| Risk | Mitigation |
|---|---|
| Stack trace exposure | Only included in `development` NODE_ENV |
| Sensitive data in error messages | Controllers use generic messages for auth failures |
| Error type leaking | All errors return same `success: false` structure |

---

## 5. Possible Issues

1. **No error categorization** — All errors look the same in logs. No distinction between 404s, 500s, or validation errors.
2. **No centralized error types** — Controllers throw plain `Error` objects; there's no custom `AppError` class with built-in status codes.
3. **No alerting** — Errors are only logged to console. In production, you'd want Sentry/Slack notifications for 500 errors.

---

## 6. Final Summary

Despite being only 12 lines, `errorHandler.js` is architecturally critical. It ensures that no matter what goes wrong — database connection failure, invalid JWT, missing data — the client always receives a well-structured JSON response with `success: false` and a meaningful message. The conditional stack trace is a smart developer experience feature that doesn't compromise production security.
