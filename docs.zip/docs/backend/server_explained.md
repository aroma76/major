# 📄 `server.js` — Complete Explanation

**File Path:** `backend/server.js`
**File Size:** 126 lines
**Role:** The single entry point for the entire Node.js backend server.

---

## 1. 📌 File Purpose

`server.js` is the **root of the entire backend**. When you run `node server.js`, this file:
- Loads all environment variables
- Creates the Express web application
- Attaches all security layers (CORS, Helmet, rate limiting)
- Mounts all route modules
- Creates the HTTP server
- Attaches Socket.IO to the HTTP server for real-time communication
- Starts listening on a port

Think of it like the **main reception desk of a building** — every request that enters the system passes through here first.

---

## 2. 🔗 Imports Explanation

```js
require('dotenv').config();
require('express-async-errors');
```

| Line | What It Does | Why It Exists |
|---|---|---|
| `require('dotenv').config()` | Reads the `.env` file and injects all key=value pairs into `process.env` | So we can write `process.env.JWT_SECRET` instead of hardcoding secrets |
| `require('express-async-errors')` | Monkey-patches Express so async route handlers automatically forward errors to the error middleware | Without this, an `async` function throwing an error would crash the server silently |

```js
const express   = require('express');
const cors      = require('cors');
const http      = require('http');
const helmet    = require('helmet');
const rateLimit = require('express-rate-limit');
const { Server } = require('socket.io');
const errorHandler  = require('./middleware/errorHandler');
const socketHandler = require('./socket/socketHandler');
const { setIO }     = require('./controllers/messageController');
const compression   = require('compression');
const { ensureBucket } = require('./config/supabase');
```

| Import | Purpose |
|---|---|
| `express` | The web framework — handles HTTP routing and middleware |
| `cors` | Allows the Flutter frontend (different origin/port) to call the backend |
| `http` | Node's built-in HTTP module — needed to create a raw server so Socket.IO can attach |
| `helmet` | Sets secure HTTP headers (prevents XSS, clickjacking, etc.) |
| `rateLimit` | Limits how many requests an IP address can make in a time window |
| `Server` from `socket.io` | The WebSocket server class for real-time messaging |
| `errorHandler` | Custom middleware that formats all error responses consistently |
| `socketHandler` | Function that registers all Socket.IO event listeners |
| `setIO` | Injects the Socket.IO instance into the message controller so REST file-upload routes can also emit real-time events |
| `compression` | Gzip-compresses JSON responses (reduces data transfer by ~80%) |
| `ensureBucket` | Verifies Supabase Storage "files" bucket exists at startup |

---

## 3. 🌐 CORS Configuration (Line-by-Line)

```js
const allowedOrigins = [
  process.env.CLIENT_URL,
  'http://localhost:5173',
  'http://localhost:3000',
  'http://localhost:9090',
  'https://major-three-tau.vercel.app',
  /\.vercel\.app$/,
  ...(process.env.NODE_ENV !== 'production' ? [
    /^http:\/\/localhost:\d+$/,
    /^http:\/\/127\.0\.0\.1:\d+$/,
  ] : []),
].filter(Boolean);
```

**Line-by-Line:**

- `process.env.CLIENT_URL` — The main frontend URL loaded from `.env`. In production, this is the Vercel URL.
- `'http://localhost:5173'` — Vite dev server default port.
- `'http://localhost:3000'` — React dev server default port.
- `'http://localhost:9090'` — Flutter Web dev server often uses this port.
- `'https://major-three-tau.vercel.app'` — The hardcoded Vercel production URL of the Flutter Web frontend.
- `/\.vercel\.app$/` — A **regex** that allows ALL Vercel preview branch URLs (e.g. `adtu-collab-git-main.vercel.app`).
- `process.env.NODE_ENV !== 'production'` — The spread `...[]` only adds localhost regexes in development, reducing attack surface in production.
- `.filter(Boolean)` — Removes any `undefined` entries (e.g. if `CLIENT_URL` isn't set in `.env`).

```js
const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    const allowed = allowedOrigins.some(o =>
      o instanceof RegExp ? o.test(origin) : o === origin
    );
    if (allowed) callback(null, true);
    else callback(new Error(`CORS blocked: ${origin}`));
  },
  credentials: true,
};
```

**Line-by-Line:**
- `origin` — The `Origin` header value sent by the browser.
- `if (!origin)` — Requests with no Origin header (e.g. Postman, cron health checks) are always allowed.
- `o instanceof RegExp ? o.test(origin) : o === origin` — Checks both exact string matches and regex pattern matches.
- `credentials: true` — Allows cookies and `Authorization` headers in cross-origin requests.

---

## 4. ⚡ Socket.IO Setup

```js
const io = new Server(server, {
  cors: { origin: allowedOrigins, methods: ['GET', 'POST'], credentials: true },
});
socketHandler(io);
setIO(io);
```

**Line-by-Line:**
- `new Server(server, {...})` — Attaches Socket.IO to the raw HTTP server. The same server handles both regular HTTP requests and WebSocket connections.
- `cors: { origin: allowedOrigins }` — Socket.IO also needs CORS configured separately.
- `socketHandler(io)` — Calls the function in `socket/socketHandler.js` which registers all socket event listeners (`message:send`, `channel:join`, etc.).
- `setIO(io)` — Injects the `io` instance into `messageController.js` so that when a file is uploaded via REST, the controller can still broadcast a `message:new` socket event to all channel members.

> **Why is this needed?** Text messages go through Socket.IO directly. But file uploads go through REST (because WebSockets can't handle file binary data efficiently). After the file is saved to Supabase, the controller needs to notify all channel members via socket. `setIO()` is the bridge between the REST world and the WebSocket world.

---

## 5. 🛡️ Middleware Stack (Execution Order)

```js
app.use(compression());
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(helmet({ contentSecurityPolicy: { ... } }));
```

**Order matters!** Middleware executes top-to-bottom. Every request passes through each `app.use()` in order.

| Middleware | What It Does |
|---|---|
| `compression()` | Gzip-compresses the response body before sending. Reduces bandwidth by up to 80% for JSON. |
| `cors(corsOptions)` | Adds `Access-Control-Allow-Origin` header to all responses. Without this, browsers block cross-origin requests. |
| `express.json()` | Parses incoming `Content-Type: application/json` request bodies into `req.body`. |
| `express.urlencoded()` | Parses URL-encoded form data (`application/x-www-form-urlencoded`). |
| `helmet(...)` | Sets 11+ secure HTTP headers in one call. |

### Helmet CSP (Content Security Policy) Deep-Dive

```js
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc : ["'self'"],
      scriptSrc  : ["'self'"],
      styleSrc   : ["'self'", "'unsafe-inline'"],
      imgSrc     : ["'self'", 'data:', 'https://*.supabase.co'],
      connectSrc : ["'self'", process.env.CLIENT_URL, '...supabase...'],
      frameSrc   : ["'self'", 'https://docs.google.com', '...supabase...'],
      mediaSrc   : ["'self'", 'https://*.supabase.co'],
    },
  },
}));
```

| Directive | Allows |
|---|---|
| `defaultSrc: ["'self'"]` | By default, only load resources from same origin |
| `scriptSrc: ["'self'"]` | Only execute scripts from same origin (blocks inline `<script>` injection) |
| `styleSrc: ["'self'", "'unsafe-inline'"]` | Allow inline styles (needed for many Flutter/React frameworks) |
| `imgSrc: ["'self'", 'data:', '*.supabase.co']` | Allow images from same origin, base64 data URIs, and Supabase CDN |
| `connectSrc` | Allow XHR/fetch to own API and Supabase |
| `frameSrc: ['docs.google.com']` | Allow embedding Google Docs iframes (for file preview) |

---

## 6. 🏥 Health Check Endpoint

```js
app.get('/api/health', (req, res) =>
  res.json({ success: true, message: 'ADTU Collab API is running 🚀', timestamp: new Date().toISOString() })
);
```

**Why does this exist?**
- Render.com (the hosting platform) pings `/api/health` periodically to confirm the server is alive.
- External monitoring tools (UptimeRobot, etc.) use health endpoints.
- **Critically placed BEFORE the rate limiter** so health pings are never blocked by IP throttling.

---

## 7. 🚦 Rate Limiter

```js
const globalLimiter = rateLimit({
  windowMs       : 15 * 60 * 1000, // 15 minutes
  max            : 200,
  standardHeaders: true,
  legacyHeaders  : false,
  skip           : (req) => req.path === '/api/health',
  message        : { success: false, message: 'Too many requests, please slow down.' },
});
app.use('/api', globalLimiter);
```

**Line-by-Line:**
- `windowMs: 15 * 60 * 1000` — The time window is 15 minutes (in milliseconds). `15 * 60 = 900`, `900 * 1000 = 900000` ms.
- `max: 200` — Maximum 200 requests per IP address per 15-minute window.
- `standardHeaders: true` — Sends `RateLimit-*` headers in responses so clients know their limits.
- `legacyHeaders: false` — Disables older `X-RateLimit-*` headers.
- `skip: (req) => req.path === '/api/health'` — Health check requests never count toward the limit.
- Applied only to `/api/*` — static files (if any) are unaffected.

> **Real-world example:** If a bot tries to brute-force logins, after 200 attempts in 15 minutes it gets a 429 Too Many Requests error. The login route has an even stricter limit of 10/15min.

---

## 8. 🗺️ Route Mounting

```js
app.use('/api/auth',                       authRoutes);
app.use('/api/channels',                   channelRoutes);
app.use('/api/channels/:id/messages',      messageRoutes);
app.use('/api/channels/:id/assignments',   assignmentRoutes);
app.use('/api/channels/:id/announcements', announcementRoutes);
app.use('/api/channels/:id/notes',         actualNotesRoutes);
app.use('/api/notifications',              notificationRoutes);
app.use('/api/projects',                   projectRoutes);
app.use('/api/academic-events',            academicEventRoutes);
app.use('/api/enrollments',               enrollmentRoutes);
app.use('/api/teacher',                   teacherRoutes);
app.use('/api/file-proxy',                downloadRoutes);
```

This is the **URL routing map** of the entire API. Each `app.use()` delegates all matching URLs to a separate router module. The `:id` in the path is a route parameter available as `req.params.id` in sub-routers (which use `mergeParams: true` to access it).

---

## 9. 🔴 404 and Error Handlers

```js
app.use((req, res) => res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` }));
app.use(errorHandler);
```

- The 404 handler catches any request that didn't match any route above.
- `errorHandler` is the last middleware — Express calls it when any middleware calls `next(err)` or when `express-async-errors` catches a thrown exception.

---

## 10. 🚀 Server Startup

```js
const PORT = process.env.PORT || 5000;
server.listen(PORT, async () => {
  console.log(`🚀 Server running on port ${PORT}...`);
  await ensureBucket();
});
```

- `process.env.PORT` — On Render.com, the platform injects the port automatically. Locally, it defaults to 5000.
- `await ensureBucket()` — After the server starts, it checks if the `files` Supabase Storage bucket exists and creates it if not. This is an idempotent operation (safe to call multiple times).

---

## 11. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| CORS abuse | Strict origin whitelist; no wildcard `*` |
| DDoS / brute force | Rate limiting (global + per-route) |
| XSS / header injection | Helmet.js CSP and security headers |
| Credential stuffing | Login-specific rate limiter (10/15min) |
| Misconfiguration exposure | `.env` secrets never committed (`.gitignore`) |

---

## 12. ⚡ Performance Considerations

| Technique | Benefit |
|---|---|
| `compression()` | Reduces response payload by up to 80% |
| Health check skip in rate limiter | Prevents monitoring pings from consuming rate limit slots |
| Route-level modularity | Express only evaluates routes for matching prefixes |

---

## 13. 🐛 Possible Bugs & Issues

1. **`mergeParams` dependency** — Routes like `messageRoutes` use `mergeParams: true` to access `:id` from the parent. If the parent mount path changes, sub-routers break.
2. **`filter(Boolean)` on regex** — `Boolean(/regex/)` is always `true`, so regex entries are never filtered even if malformed. This is safe but slightly misleading.
3. **No request body size limit** — `express.json()` without a `limit` option defaults to 100kb. Large JSON payloads aren't handled.

---

## 14. 🔄 Execution Flow Summary

```
node server.js
  → dotenv loads .env
  → express-async-errors patches async handling
  → Express app created
  → CORS options defined
  → HTTP server created (wrapping Express)
  → Socket.IO attached to HTTP server
  → socketHandler registers socket events
  → setIO injects socket into messageController
  → Middleware chain registered (compression → cors → json → helmet)
  → Health check route registered (before rate limiter)
  → Rate limiter applied to /api/*
  → All feature routes mounted
  → 404 and error handlers registered
  → server.listen() starts accepting connections
  → ensureBucket() verifies Supabase storage
```

---

## 15. ✅ Final Summary

`server.js` is the **orchestration layer** of the backend. It doesn't contain any business logic itself — instead, it:
1. Loads configuration from environment variables.
2. Applies a layered security perimeter (CORS → Helmet → Rate Limiting).
3. Routes requests to the appropriate feature module.
4. Provides both HTTP (REST API) and WebSocket (Socket.IO) transports on a single port.
5. Initializes external dependencies (Supabase bucket) at startup.

Every feature in the app flows through this file. It's the first and last thing that touches every request.
