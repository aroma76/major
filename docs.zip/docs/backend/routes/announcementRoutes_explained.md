# 📄 `routes/announcementRoutes.js` — Complete Explanation

**File Path:** `backend/routes/announcementRoutes.js`
**Lines:** 11
**Mounted at:** `app.use('/api/channels/:id/announcements', announcementRoutes)`
**Role:** Announcement CRUD per channel — read for everyone, create/delete for faculty/admin.

---

## 1. Full Source Code

```js
const express = require('express');
const router = express.Router({ mergeParams: true }); // inherits :id (channelId)

const { getAnnouncements, createAnnouncement, deleteAnnouncement }
  = require('../controllers/announcementController');
const { protect, authorize } = require('../middleware/auth');

router.get('/', protect, getAnnouncements);
router.post('/', protect, authorize('admin', 'faculty'), createAnnouncement);
router.delete('/:announcementId', protect, authorize('admin', 'faculty'), deleteAnnouncement);
```

---

## 2. Route Table

| Method | Path | Access | Purpose |
|---|---|---|---|
| `GET` | `/api/channels/:id/announcements` | All authenticated | List channel announcements |
| `POST` | `/api/channels/:id/announcements` | Admin, Faculty | Post a new announcement |
| `DELETE` | `/api/channels/:id/announcements/:announcementId` | Admin, Faculty | Delete an announcement |

---

## 3. Key Design — Faculty CAN Post

```js
router.post('/', protect, authorize('admin', 'faculty'), createAnnouncement);
```

Faculty are allowed to post announcements (unlike channel creation where only admin can). This reflects real-world logic: teachers communicate with their class directly; an admin would be a bottleneck if required for every announcement.

---

## 4. `mergeParams: true`

The `:id` (channelId) from the parent mount `'/api/channels/:id/announcements'` is needed inside `getAnnouncements` and `createAnnouncement` to know which channel's announcements to fetch/create. Without `mergeParams`, `req.params.id` would be undefined.

---

## 5. No Update Route

There is no `PUT /:announcementId` — announcements cannot be edited after posting. Delete and re-post is the intended workflow. This keeps the implementation simple and prevents ambiguity about edit history.

---

## 6. Frontend Connection (Flutter)

```dart
// AnnouncementsTab in SubjectHubSheet
// Provider: channelAnnouncementsProvider(channelId)
dio.get('/channels/$channelId/announcements')

// TeacherPostAnnouncementDialog
dio.post('/channels/$channelId/announcements', data: {
  'title': 'Mid-Semester Notice',
  'content': '...',
  'is_important': true,
})
```

---

## 7. Final Summary

`announcementRoutes.js` is the smallest route file (11 lines) but demonstrates the core access-control pattern: `protect` for all, `authorize('admin', 'faculty')` for write operations. The no-edit design keeps announcements immutable after posting.
