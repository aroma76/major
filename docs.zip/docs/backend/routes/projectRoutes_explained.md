# Word-by-Word Deep Dive: `backend/routes/projectRoutes.js`

> This file wires HTTP routes to their controller functions for the entire **Kanban Projects** feature. It covers CRUD for projects, member management (add/remove/list candidates), and Kanban task operations (create/edit/status/delete).

---

## Full Route File

```js
const express = require('express');
const router = express.Router();
const {
  getProjects, getProject, createProject,
  getClassroomStudents, addMember, removeMember,
  updateProgress, deleteProject,
  createTask, updateTask, updateTaskStatus, deleteTask,
} = require('../controllers/projectController');
const { protect } = require('../middleware/auth');

router.get('/',                                protect, getProjects);
router.post('/',                               protect, createProject);
router.get('/:id',                             protect, getProject);
router.patch('/:id/progress',                  protect, updateProgress);
router.delete('/:id',                          protect, deleteProject);

// ── Member management ─────────────────────────────────────────────────────────
router.get('/:id/students',                    protect, getClassroomStudents);
router.post('/:id/members',                    protect, addMember);
router.delete('/:id/members/:userId',          protect, removeMember);

// ── Tasks ─────────────────────────────────────────────────────────────────────
router.post('/:id/tasks',                      protect, createTask);
router.patch('/:id/tasks/:taskId',             protect, updateTask);
router.patch('/:id/tasks/:taskId/status',      protect, updateTaskStatus);
router.delete('/:id/tasks/:taskId',            protect, deleteTask);

module.exports = router;
```

---

## Route Groups Explained

### Project CRUD

| Method | Path | Controller | Purpose |
|---|---|---|---|
| GET | `/` | `getProjects` | List all projects the user is a member of |
| POST | `/` | `createProject` | Create a new project (creator auto-added as member) |
| GET | `/:id` | `getProject` | Get a single project with all members and tasks |
| PATCH | `/:id/progress` | `updateProgress` | Manually set project progress (0–100) |
| DELETE | `/:id` | `deleteProject` | Delete a project and all its tasks (creator only) |

### Member Management

| Method | Path | Controller | Purpose |
|---|---|---|---|
| GET | `/:id/students` | `getClassroomStudents` | List students eligible to be added (3-tier fallback) |
| POST | `/:id/members` | `addMember` | Add a student to the project by user_id |
| DELETE | `/:id/members/:userId` | `removeMember` | Remove a member from the project |

**`GET /:id/students`** — used by the member-picker dialog on the frontend. Returns students from the creator's channels → cohort → all, excluding existing members.

**`DELETE /:id/members/:userId`** — uses a **dynamic nested param** `:userId`. Express parses this as `req.params.userId`. The creator cannot be removed.

### Task Operations (Jira Board)

| Method | Path | Controller | Purpose |
|---|---|---|---|
| POST | `/:id/tasks` | `createTask` | Add a new task (starts in 'todo' column) |
| PATCH | `/:id/tasks/:taskId` | `updateTask` | Edit all task fields (title, description, priority, due date, assignee) |
| PATCH | `/:id/tasks/:taskId/status` | `updateTaskStatus` | Move task between kanban columns (todo/in_progress/done) + auto-recalculates project progress |
| DELETE | `/:id/tasks/:taskId` | `deleteTask` | Delete a task + recalculates project progress |

### Why Two PATCH Routes for Tasks?

`PATCH /:id/tasks/:taskId` — full edit (all fields)  
`PATCH /:id/tasks/:taskId/status` — status-only (Kanban drag-and-drop)

They are separate because:
- Kanban drag-and-drop only changes `status` and triggers progress recalculation — it doesn't need to send all other fields
- Full edit updates title/description/priority/due_date/assigned_to_name and does NOT recalculate progress

Express matches the **more specific route first** — `/:id/tasks/:taskId/status` has a literal `/status` segment, so it is matched before `/:id/tasks/:taskId` for requests with `/status`.

---

## Middleware

```js
const { protect } = require('../middleware/auth');
```

**Every route uses `protect`** — the JWT authentication middleware. No unauthenticated user can access any project route. The middleware also sets `req.user` (with `req.user.id`) which controllers use for access control.

---

## Route Parameter Summary

| Param | Type | Where Used |
|---|---|---|
| `:id` | project ID | All project + member + task routes |
| `:taskId` | task ID | Task update/status/delete routes |
| `:userId` | user ID | `removeMember` route |
