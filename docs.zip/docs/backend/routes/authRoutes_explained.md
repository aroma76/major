# 📄 `routes/authRoutes.js` — Complete Explanation

**File Path:** `backend/routes/authRoutes.js`
**Lines:** 24
**Mounted at:** `app.use('/api/auth', authRoutes)` (in `server.js`)
**Role:** Defines all authentication-related HTTP endpoints — registration, login, profile read/update, and password change.

---

## 1. File Purpose

This router maps five HTTP routes to controller functions in `authController.js`. It is the **entry point** for all user identity operations. No business logic lives here — only routing + middleware chain configuration.

---

## 2. Full Source Code with Line-by-Line Explanation

```js
const express    = require('express');       // Line 1: Express framework
const rateLimit  = require('express-rate-limit'); // Line 2: Rate limiting package
const router     = express.Router();         // Line 3: Create isolated sub-router

const { register, login, getMe, updateProfile, changePassword }
  = require('../controllers/authController');  // Line 4: Import controller handlers

const { protect } = require('../middleware/auth'); // Line 5: JWT auth middleware
const upload     = require('../middleware/upload'); // Line 6: Multer file upload middleware
```

---

## 3. `loginLimiter` — Brute-Force Protection

```js
const loginLimiter = rateLimit({
  windowMs      : 15 * 60 * 1000,   // 15-minute window
  max           : 10,               // Max 10 requests per window
  message       : { success: false, message: 'Too many login attempts. Try again in 15 minutes.' },
  standardHeaders: true,            // Set RateLimit-* response headers (RFC 6585)
  legacyHeaders  : false,           // Don't set X-RateLimit-* (deprecated)
});
```

**Why a separate limiter for login?**
The global rate limiter in `server.js` allows 200 requests per 15 minutes. Login is far more sensitive — an attacker trying to brute-force passwords should be blocked much sooner. 10 attempts per 15 minutes is the industry standard for login endpoints.

**`standardHeaders: true`** — Sends `RateLimit-Limit`, `RateLimit-Remaining`, `RateLimit-Reset` headers in the response. The Flutter `ApiService` doesn't read these, but they're useful for debugging and future clients.

---

## 4. Route Table

| Method | Path | Middleware | Controller | Purpose |
|---|---|---|---|---|
| `POST` | `/api/auth/register` | None | `register` | Create a new student account |
| `POST` | `/api/auth/login` | `loginLimiter` | `login` | Authenticate and get JWT |
| `GET` | `/api/auth/me` | `protect` | `getMe` | Get current user's profile |
| `PUT` | `/api/auth/profile` | `protect` + `upload` | `updateProfile` | Update profile + optional avatar |
| `POST` | `/api/auth/change-password` | `protect` | `changePassword` | Change own password |

---

## 5. Middleware Chain Explained

### `POST /register` — No middleware
```
Request → register()
```
Public endpoint. Anyone can register. The controller validates the body (name, email, password, role).

### `POST /login` — Rate limiter only
```
Request → loginLimiter → login()
```
Public but rate-limited. `loginLimiter` checks the IP's request count before calling `login()`. If limit exceeded, `login()` never runs — rate limiter sends the 429 response directly.

### `GET /me` — Auth guard
```
Request → protect → getMe()
```
`protect` extracts the JWT from `Authorization: Bearer <token>`, verifies it, and attaches `req.user`. If invalid → 401, never reaches `getMe()`.

### `PUT /profile` — Auth + file upload
```
Request → protect → upload.single('avatar') → updateProfile()
```
The order matters:
1. `protect` — verifies JWT (if invalid, stops here)
2. `upload.single('avatar')` — processes the `multipart/form-data` body, uploads avatar to Supabase Storage, sets `req.file` with the URL
3. `updateProfile()` — reads `req.user` (set by `protect`) and `req.file` (set by `upload`) to update the database

### `POST /change-password` — Auth only
```
Request → protect → changePassword()
```
`POST` is used here instead of `PUT`/`PATCH` because the route was designed to match how the frontend calls it (a comment in the file confirms this). The controller reads `req.body.currentPassword` and `req.body.newPassword`.

---

## 6. What `protect` Middleware Does

```js
// From middleware/auth.js
const protect = async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1]; // "Bearer <token>"
  if (!token) return res.status(401).json({ message: 'No token' });
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  req.user = await db.query('SELECT * FROM users WHERE id = $1', [decoded.id]);
  next();
};
```

After `protect` runs, every subsequent handler can use `req.user.id`, `req.user.role`, etc.

---

## 7. Security Considerations

| Threat | Mitigation |
|---|---|
| Brute-force login | `loginLimiter` (10 req/15min per IP) |
| Unauthorized profile access | `protect` middleware (JWT required) |
| File upload abuse on avatar | `upload.single('avatar')` limits to one file; Multer validates on backend |
| Password change without auth | `protect` required before `changePassword` |

---

## 8. Frontend Connection

From `ApiService` in the Flutter frontend:
```dart
// Registration
dio.post('/auth/register', data: { name, email, password, role })

// Login
dio.post('/auth/login', data: { email, password })

// Get own profile
dio.get('/auth/me')

// Update profile
dio.put('/auth/profile', data: FormData({ name, avatar: file }))

// Change password
dio.post('/auth/change-password', data: { currentPassword, newPassword })
```

---

## 9. Real-World Analogy

Think of `authRoutes.js` as the **reception desk of a hotel**:
- `/register` — New guest fills out a registration form (no key needed)
- `/login` — Guest shows ID, gets a room key (JWT token)
- `/me` — Guest shows their key to see their own room details
- `/profile` — Guest shows key and asks to update their info
- `/change-password` — Guest shows key to set a new PIN

The `loginLimiter` is like a security guard who counts how many times you've tried to swipe a card — after 10 failed tries, they make you wait 15 minutes.

---

## 10. Final Summary

`authRoutes.js` is the simplest and most critical route file in the project. Its key design decisions are: dedicated `loginLimiter` for brute-force protection, `protect` middleware for all authenticated routes, and the specific middleware ordering (`protect → upload → controller`) which ensures every dependency is available when the controller runs.
