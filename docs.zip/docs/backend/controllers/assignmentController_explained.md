# 📄 `controllers/assignmentController.js` — Complete Explanation

**File Path:** `backend/controllers/assignmentController.js`
**Lines:** 139
**Role:** Full CRUD for assignments, with role-specific query logic, student notification on creation, and cross-channel boundary enforcement.

---

## 1. 📌 File Purpose

`assignmentController.js` handles the academic assignment workflow:
1. **Students** — See assignments with their personal submission status (submitted/graded/pending)
2. **Faculty/Admin** — See assignments with aggregate submission counts
3. **Faculty** — Create assignments with automatic student notifications
4. **Faculty** — Update/delete assignments with cross-channel security checks

> **Beginner Analogy:** Think of this like a homework tracker. When a teacher assigns homework, students see whether they've submitted theirs. When the teacher checks, they see how many students have submitted.

---

## 2. 🔍 `getAssignments` — Role-Dual Query Logic

```js
const getAssignments = async (req, res) => {
  let query, values;
  if (req.user.role === 'student') {
    query = `SELECT a.*, u.name AS created_by_name, s.status AS submission_status, s.submitted_at, s.marks, s.feedback, s.id AS submission_id
             FROM assignments a INNER JOIN users u ON a.created_by = u.id
             LEFT JOIN assignment_submissions s ON s.assignment_id = a.id AND s.student_id = $2
             WHERE a.channel_id = $1 ORDER BY a.due_date ASC`;
    values = [req.params.id, req.user.id];
  } else {
    query = `SELECT a.*, u.name AS created_by_name, COUNT(s.id) AS submission_count
             FROM assignments a INNER JOIN users u ON a.created_by = u.id
             LEFT JOIN assignment_submissions s ON s.assignment_id = a.id
             WHERE a.channel_id = $1 GROUP BY a.id, u.name ORDER BY a.due_date ASC`;
    values = [req.params.id];
  }
  const result = await pool.query(query, values);
  res.json({ success: true, assignments: result.rows });
};
```

### Student Query — Personal Submission JOIN

```sql
LEFT JOIN assignment_submissions s 
  ON s.assignment_id = a.id AND s.student_id = $2
```

**This is a conditional LEFT JOIN.** The join condition includes `s.student_id = $2`. This means:
- For assignments where the student HAS submitted: `s.*` columns are populated
- For assignments where the student HAS NOT submitted: all `s.*` columns are `NULL`

So a student query for 5 assignments where 3 are submitted returns 5 rows total. The 3 submitted ones have `s.marks`, `s.feedback`, `s.submitted_at` filled in. The 2 unsubmitted ones have `NULL` for all submission columns.

**`$2 = req.user.id`** — The student's ID comes from the JWT (server-verified), never from the request body.

### Faculty/Admin Query — Submission Count Aggregate

```sql
COUNT(s.id) AS submission_count
...LEFT JOIN assignment_submissions s ON s.assignment_id = a.id
...GROUP BY a.id, u.name
```

- `LEFT JOIN` with no student filter — joins ALL submissions for each assignment
- `COUNT(s.id)` — counts how many rows were joined (i.e., how many students submitted)
- `GROUP BY a.id, u.name` — required when using `COUNT()`; groups all submissions per assignment into one row

**`COUNT(s.id)` vs `COUNT(*)`:**
- `COUNT(s.id)` — counts non-NULL `s.id` values (i.e., actual submissions)
- `COUNT(*)` — counts all rows including NULLs (would return 1 even for 0 submissions)
So `COUNT(s.id)` correctly returns 0 for assignments with no submissions.

---

## 3. 🔍 `getAssignment` — Single Assignment

```js
const getAssignment = async (req, res) => {
  const result = await pool.query(
    `SELECT a.*, u.name AS created_by_name FROM assignments a 
     INNER JOIN users u ON a.created_by = u.id WHERE a.id=$1`, 
    [req.params.assignId]
  );
  if (!result.rows.length) return res.status(404).json(...);
  res.json({ success: true, assignment: result.rows[0] });
};
```

Note: uses `req.params.assignId` (from `/:assignId`), not `req.params.id` (which is the channel ID from the parent route).

---

## 4. ➕ `createAssignment` — With Student Notifications

```js
const createAssignment = async (req, res) => {
  const { title, description, due_date, max_marks, priority } = req.body;
  if (!title || !due_date) return res.status(400).json(...);
  
  // Input length limits
  if (title.length > 255) return res.status(400).json(...);
  if (description && description.length > 3000) return res.status(400).json(...);
  
  const result = await pool.query(
    `INSERT INTO assignments (channel_id, created_by, title, description, due_date, max_marks, priority, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,'todo') RETURNING *`,
    [req.params.id, req.user.id, title, description, due_date, max_marks || 100, priority || 'medium']
  );
  
  // Notify enrolled students
  const students = await pool.query(
    `SELECT user_id FROM enrollments WHERE channel_id=$1`, [req.params.id]
  );
  await Promise.all(students.rows.map(s =>
    pool.query(
      `INSERT INTO notifications (user_id, type, title, message, ref_id, ref_type) 
       VALUES ($1,'assignment',$2,$3,$4,'assignment')`,
      [s.user_id, `New Assignment: ${title}`, `Due: ${new Date(due_date).toLocaleDateString()}`, result.rows[0].id]
    )
  ));
  
  res.status(201).json({ success: true, assignment: result.rows[0] });
};
```

### Notification Fan-out

```js
const students = await pool.query(`SELECT user_id FROM enrollments WHERE channel_id=$1`, [req.params.id]);
await Promise.all(students.rows.map(s =>
  pool.query(`INSERT INTO notifications ...`, [s.user_id, ...])
));
```

**`Promise.all()` + `.map()`:**
- `.map()` creates an array of promises, one `INSERT` per student
- `Promise.all()` executes ALL inserts in parallel (not sequentially)
- For 100 enrolled students, this fires 100 INSERT queries simultaneously
- Much faster than a `for` loop with sequential `await` (sequential would be 100× slower)

**Notification content:**
- `type: 'assignment'` — For filtering in the notification panel
- `ref_id: result.rows[0].id` — The new assignment's ID, allows deep-linking
- `ref_type: 'assignment'` — Identifies what `ref_id` refers to
- `message: Due: ${new Date(due_date).toLocaleDateString()}` — Human-readable due date string

### Default Values

```js
max_marks || 100   // defaults to 100 if not provided
priority || 'medium'  // defaults to medium priority
status: 'todo'  // hardcoded initial status
```

---

## 5. 🔄 `updateAssignmentStatus` — Kanban Status Change

```js
const updateAssignmentStatus = async (req, res) => {
  const { status } = req.body;
  const allowed = ['todo', 'in_progress', 'done'];
  if (!allowed.includes(status)) return res.status(400).json(...);
  
  const result = await pool.query(
    `UPDATE assignments SET status=$1 WHERE id=$2 RETURNING *`,
    [status, req.params.assignId]
  );
};
```

**Whitelist validation:** `allowed.includes(status)` — Only these three exact strings are accepted. Any other value returns 400. Prevents setting invalid status values.

---

## 6. 🔒 `updateAssignment` — Cross-Channel Boundary Check

```js
const updateAssignment = async (req, res) => {
  const check = await pool.query('SELECT channel_id FROM assignments WHERE id=$1', [req.params.assignId]);
  if (!check.rows.length) return res.status(404).json(...);
  if (String(check.rows[0].channel_id) !== String(req.params.id))
    return res.status(403).json({ success: false, message: 'Assignment does not belong to this channel' });
    
  const result = await pool.query(
    `UPDATE assignments SET title=$1,description=$2,due_date=$3,max_marks=$4 WHERE id=$5 RETURNING *`, 
    [title, description, due_date, max_marks, req.params.assignId]
  );
};
```

**Why this check?**
Without it, a faculty member could craft a URL like `PUT /api/channels/99/assignments/1` where assignment 1 belongs to channel 42 (not 99). The controller would still update assignment 1 because the `WHERE id=$5` doesn't verify channel ownership.

The check:
1. `SELECT channel_id FROM assignments WHERE id=$1` — Gets the assignment's actual channel
2. `String(...) !== String(...)` — Compares as strings to avoid type coercion issues (DB returns `int`, `req.params.id` is `string`)
3. If they don't match → 403 Forbidden

---

## 7. ❌ `deleteAssignment` — With Same Boundary Check

```js
const deleteAssignment = async (req, res) => {
  const check = await pool.query('SELECT channel_id FROM assignments WHERE id=$1', [req.params.assignId]);
  if (!check.rows.length) return res.status(404).json(...);
  if (String(check.rows[0].channel_id) !== String(req.params.id))
    return res.status(403).json(...);
    
  await pool.query('DELETE FROM assignments WHERE id=$1', [req.params.assignId]);
  res.json({ success: true, message: 'Assignment deleted' });
};
```

Same boundary check pattern as `updateAssignment`. `ON DELETE CASCADE` on `assignment_submissions.assignment_id` means all submissions are deleted when the assignment is.

---

## 8. 📋 `getSubmissions` — Faculty Submission View

```js
const getSubmissions = async (req, res) => {
  const result = await pool.query(
    `SELECT sub.*, u.name AS student_name, u.email AS student_email 
     FROM assignment_submissions sub 
     INNER JOIN users u ON sub.student_id = u.id 
     WHERE sub.assignment_id = $1 ORDER BY sub.submitted_at DESC`,
    [req.params.id]   // ← NOTE: this uses req.params.id (channel ID), not req.params.assignId!
  );
};
```

**⚠️ Bug:** `req.params.id` here refers to the **channel ID**, not the assignment ID. It should be `req.params.assignId`. This would return submissions for any assignment in ANY channel matching the channel ID, not just the requested assignment. This is a confirmed bug.

---

## 9. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Student seeing other student's grades | `LEFT JOIN ... AND s.student_id = $2` limits to own data |
| Arbitrary assignment editing | Cross-channel boundary check |
| Status manipulation | Whitelist validation |
| SQL injection | All parameterized queries |
| Notification spam | Promise.all is efficient but no rate limit |

---

## 10. ✅ Final Summary

`assignmentController.js` demonstrates sophisticated PostgreSQL patterns — the dual-query role strategy and the conditional LEFT JOIN are production-level SQL. The cross-channel boundary check prevents an important authorization bypass. The bug in `getSubmissions` (`req.params.id` vs `req.params.assignId`) should be fixed for correct grading functionality.
