# 📄 `controllers/notificationController.js` — Complete Explanation

**File Path:** `backend/controllers/notificationController.js`
**Lines:** 69

---

## 1. File Purpose
Manages a user's notification inbox — retrieval, marking as read, and deletion. All operations are scoped to `req.user.id`, preventing any cross-user access.

---

## 2. `getNotifications`
```js
const getNotifications = async (req, res) => {
  const result = await pool.query(
    `SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50`,
    [req.user.id]
  );
  res.json({ success: true, notifications: result.rows });
};
```
- `LIMIT 50` — Only the 50 most recent; prevents huge payloads for active users
- `ORDER BY created_at DESC` — Newest first
- `WHERE user_id=$1` — Scoped to authenticated user

---

## 3. `markRead` — Single Notification
```js
const markRead = async (req, res) => {
  await pool.query(
    'UPDATE notifications SET is_read=TRUE WHERE id=$1 AND user_id=$2',
    [req.params.id, req.user.id]
  );
  res.json({ success: true });
};
```
**`AND user_id=$2`** — The critical security clause. Without it, any user could mark any notification as read by knowing its ID. With it, the UPDATE silently does nothing if the notification belongs to a different user.

---

## 4. `markAllRead`
```js
const markAllRead = async (req, res) => {
  await pool.query('UPDATE notifications SET is_read=TRUE WHERE user_id=$1', [req.user.id]);
  res.json({ success: true });
};
```
One SQL `UPDATE` with no ID filter — marks ALL unread notifications for this user as read simultaneously. More efficient than calling `markRead` in a loop.

---

## 5. `deleteNotification`
```js
const deleteNotification = async (req, res) => {
  await pool.query(
    'DELETE FROM notifications WHERE id=$1 AND user_id=$2',
    [req.params.id, req.user.id]
  );
  res.json({ success: true });
};
```
Same `AND user_id=$2` ownership check as `markRead`.

---

## 6. `getUnreadCount` — Badge Number
```js
const getUnreadCount = async (req, res) => {
  const result = await pool.query(
    `SELECT COUNT(*) FROM notifications WHERE user_id=$1 AND is_read=FALSE`,
    [req.user.id]
  );
  res.json({ success: true, count: parseInt(result.rows[0].count) });
};
```
- `COUNT(*)` returns a string from pg (e.g., `"5"`) — `parseInt()` converts to number
- Used by the notification bell badge in `TopBarWidget`

---

## 7. Security Considerations
All five operations include `WHERE user_id=$1` or `AND user_id=$2`. This prevents any cross-user notification access even if IDs are guessed. SQL injection is prevented via parameterized queries.

---

## 8. Final Summary
A clean, minimal controller. The `AND user_id` pattern on all operations is the key security feature. The `getUnreadCount` endpoint enables efficient badge display without fetching all notification content.
