# 📄 `controllers/enrollmentController.js` — Complete Explanation

**File Path:** `backend/controllers/enrollmentController.js`
**Lines:** 86

---

## 1. File Purpose
Manages student ↔ channel relationships (enrollments). Supports single enroll/unenroll (by faculty/admin) and bulk enrollment for entire cohorts (by admin).

---

## 2. `enroll` — With Duplicate Handling
```js
const enroll = async (req, res) => {
  const { user_id, channel_id } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO enrollments (user_id, channel_id) VALUES ($1, $2) RETURNING *`,
      [user_id, channel_id]
    );
    res.status(201).json({ success: true, enrollment: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ success: false, message: 'Already enrolled' });
    throw err;  // Re-throw unexpected errors to global error handler
  }
};
```

**PostgreSQL error code `23505`:** This is the `unique_violation` error code. When `UNIQUE (user_id, channel_id)` is violated (student already enrolled), PostgreSQL throws this error instead of inserting a duplicate row.

**`throw err`** — For any OTHER error (connection error, syntax error, etc.), re-throws to the `express-async-errors` global handler. Only `23505` is handled here.

---

## 3. `unenroll` — Silent Delete
```js
const unenroll = async (req, res) => {
  const { user_id, channel_id } = req.body;
  await pool.query('DELETE FROM enrollments WHERE user_id=$1 AND channel_id=$2', [user_id, channel_id]);
  res.json({ success: true, message: 'Unenrolled successfully' });
};
```
No 404 check — if the enrollment doesn't exist, DELETE deletes 0 rows and still returns success. This is idempotent (safe to call multiple times).

---

## 4. `bulkEnroll` — For Loop with Error Swallowing
```js
const bulkEnroll = async (req, res) => {
  const { channel_id, programme_id, current_semester } = req.body;
  const students = await pool.query(
    `SELECT id FROM users WHERE role='student' AND programme_id=$1 AND current_semester=$2`,
    [programme_id, current_semester]
  );
  let enrolled = 0;
  for (const s of students.rows) {
    try {
      await pool.query('INSERT INTO enrollments (user_id, channel_id) VALUES ($1, $2)', [s.id, channel_id]);
      enrolled++;
    } catch (_) {
      // Skip already-enrolled students silently
    }
  }
  res.json({ success: true, message: `Enrolled ${enrolled} students` });
};
```

**Why `for...of` with sequential `await` instead of `Promise.all`?**
- `Promise.all` would fire all INSERTs simultaneously, which could hit DB connection limits for large cohorts (e.g., 300 students)
- Sequential `for...of` is safer for bulk operations — each INSERT completes before the next starts
- Trade-off: slower but more reliable

**Error swallowing (`catch (_) {}`):**
- Swallows `23505` (duplicate enrollment) silently
- Also swallows any other error — this is a bug; real errors like connection failures would be silently ignored

**`enrolled` counter** — Tracks how many NEW enrollments were created (vs skipped duplicates). Response tells admin "Enrolled 45 students" even if 5 were already enrolled.

---

## 5. Final Summary
`enrollmentController.js` handles the critical access-control data. The `23505` error code catch for duplicate enrollment is a clean PostgreSQL-native approach. The `bulkEnroll` sequential loop trades performance for reliability. The silent error swallow in `bulkEnroll` is a minor bug worth fixing.
