# 📄 `controllers/notesController.js` — Complete Explanation

**File Path:** `backend/controllers/notesController.js`
**Lines:** 61

---

## 1. File Purpose
CRUD for student notes within channels. Notes are scoped to channels (one channel can have many notes) and owned by individual users (only creator/faculty/admin can delete).

---

## 2. `getNotes` — With Author Name
```js
const getNotes = async (req, res) => {
  const result = await pool.query(
    `SELECT n.*, u.name AS author_name 
     FROM notes n 
     INNER JOIN users u ON n.created_by = u.id 
     WHERE n.channel_id = $1 
     ORDER BY n.created_at DESC`,
    [req.params.id]
  );
  res.json({ success: true, notes: result.rows });
};
```
JOIN with `users` to include the author's display name without a second query.

---

## 3. `createNote` — Augment Response With Author Name
```js
const createNote = async (req, res) => {
  const { title, content } = req.body;
  if (!title) return res.status(400).json(...);

  const result = await pool.query(
    `INSERT INTO notes (channel_id, created_by, title, content) VALUES ($1, $2, $3, $4) RETURNING *`,
    [req.params.id, req.user.id, title, content]
  );
  const newNote = result.rows[0];
  newNote.author_name = req.user.name;  // Attach from JWT — no extra DB query needed
  res.status(201).json({ success: true, note: newNote });
};
```

**`newNote.author_name = req.user.name`** — Attaches the author name from the already-decoded JWT payload, saving an extra DB query. Since `req.user.name` comes from the verified JWT, it's safe and accurate.

---

## 4. `deleteNote` — Three-Role Authorization in SQL
```js
const deleteNote = async (req, res) => {
  const result = await pool.query(
    `DELETE FROM notes WHERE id = $1 AND (created_by = $2 OR $3 = 'faculty' OR $3 = 'admin') RETURNING id`,
    [req.params.noteId, req.user.id, req.user.role]
  );
  if (!result.rows.length) return res.status(403).json({ success: false, message: 'Not authorized or not found' });
  res.json({ success: true, message: 'Note deleted' });
};
```

**SQL Authorization Expression:**
```sql
WHERE id = $1 AND (created_by = $2 OR $3 = 'faculty' OR $3 = 'admin')
```
This encodes three authorization rules in one WHERE clause:
1. `created_by = $2` — The note owner can delete their own note
2. `$3 = 'faculty'` — Faculty can delete any note in their channels
3. `$3 = 'admin'` — Admin can delete any note

**`RETURNING id`** — If the DELETE matched zero rows (wrong ID or unauthorized), `result.rows` is empty → `!result.rows.length` is true → 403.

The single 403 response doesn't tell the client WHY it failed (not found vs unauthorized). This is a privacy-preserving design — doesn't reveal whether the note exists at all.

---

## 5. Final Summary
`notesController.js` uses the SQL authorization pattern (`AND (condition1 OR condition2 OR condition3)`) elegantly. The `newNote.author_name = req.user.name` optimization avoids a redundant DB query. The 403-for-both-not-found-and-unauthorized prevents information disclosure.
