# 📄 `controllers/submissionController.js` — Complete Explanation

**File Path:** `backend/controllers/submissionController.js`
**Lines:** 88

---

## 1. File Purpose
Handles assignment submissions — students submit files, late detection, resubmission (update), and faculty grading with automatic student notification.

---

## 2. `submitAssignment` — Late Detection + Upsert Pattern

```js
const submitAssignment = async (req, res) => {
  const assignment_id = req.params.assignId;
  const student_id = req.user.id;

  // Verify assignment and get due date
  const assign = await pool.query('SELECT due_date FROM assignments WHERE id=$1', [assignment_id]);
  if (!assign.rows.length) return res.status(404).json(...);

  // Late detection
  const status = new Date() > new Date(assign.rows[0].due_date) ? 'late' : 'submitted';
  const file_url  = req.file?.path         || null;
  const file_name = req.file?.originalname || null;

  // Check if already submitted
  const existing = await pool.query(
    'SELECT id FROM assignment_submissions WHERE assignment_id=$1 AND student_id=$2',
    [assignment_id, student_id]
  );

  let result;
  if (existing.rows.length > 0) {
    // Resubmission (Update)
    result = await pool.query(
      `UPDATE assignment_submissions SET file_url=$1, file_name=$2, status=$3, submitted_at=NOW()
       WHERE assignment_id=$4 AND student_id=$5 RETURNING *`,
      [file_url, file_name, status, assignment_id, student_id]
    );
  } else {
    // First submission (Insert)
    result = await pool.query(
      `INSERT INTO assignment_submissions (assignment_id, student_id, file_url, file_name, status, submitted_at)
       VALUES ($1,$2,$3,$4,$5,NOW()) RETURNING *`,
      [assignment_id, student_id, file_url, file_name, status]
    );
  }
  res.status(201).json({ success: true, submission: result.rows[0] });
};
```

### Late Detection
```js
const status = new Date() > new Date(assign.rows[0].due_date) ? 'late' : 'submitted';
```
- `new Date()` — Current server timestamp
- `new Date(assign.rows[0].due_date)` — Due date from DB as a JavaScript Date object
- `>` — If current time is after the due date, status is `'late'`
- This runs **SERVER-SIDE** — cannot be spoofed by the client

### Manual Upsert Pattern
Instead of `INSERT ... ON CONFLICT DO UPDATE`, this code manually checks for an existing submission then branches to UPDATE or INSERT. This gives full control over what fields to update on resubmission (specifically, it updates `submitted_at=NOW()` to record the resubmission timestamp).

### File Handling
```js
const file_url  = req.file?.path         || null;
const file_name = req.file?.originalname || null;
```
- `req.file?.path` — The Supabase public URL (set by `upload.js` Multer engine)
- `?.` — Optional chaining: if `req.file` is undefined (no file uploaded), returns `undefined` instead of throwing
- `|| null` — Converts `undefined` to `null` for DB storage

---

## 3. `gradeSubmission` — With Student Notification

```js
const gradeSubmission = async (req, res) => {
  const { marks, feedback } = req.body;
  
  const result = await pool.query(
    `UPDATE assignment_submissions SET marks=$1, feedback=$2 WHERE id=$3 RETURNING *`,
    [marks, feedback, req.params.subId]
  );
  if (!result.rows.length) return res.status(404).json(...);

  const sub = result.rows[0];
  
  // Notify the student
  await pool.query(
    `INSERT INTO notifications (user_id, type, title, message, ref_id, ref_type)
     VALUES ($1,'grade','Assignment Graded',$2,$3,'submission')`,
    [sub.student_id, `You received ${marks} marks. Feedback: ${feedback || 'None'}`, sub.id]
  );
  
  res.json({ success: true, submission: result.rows[0] });
};
```

**`sub.student_id`** — Taken from the submission row returned by `RETURNING *`. This avoids a separate query to find who submitted. The notification goes to the student who submitted, identified from the DB record (not from the request).

**`feedback || 'None'`** — If no feedback was provided, shows "None" in the notification rather than "undefined" or an empty string.

---

## 4. `getMySubmission`

```js
const getMySubmission = async (req, res) => {
  const result = await pool.query(
    'SELECT * FROM assignment_submissions WHERE assignment_id=$1 AND student_id=$2',
    [req.params.assignId, req.user.id]
  );
  res.json({ success: true, submission: result.rows[0] || null });
};
```
Returns `null` (not 404) when no submission exists — allows the frontend to distinguish "not submitted yet" from "server error".

---

## 5. Known Bug
In `gradeSubmission`:
```js
WHERE id=$3 RETURNING *
```
`req.params.subId` maps to `$3`. There's no check that this submission belongs to the specified channel/assignment. A faculty member could grade any submission by ID — not just their own channel's submissions.

---

## 6. Final Summary
`submissionController.js` demonstrates the manual upsert pattern, server-side late detection, and grading with automatic notification. The optional chaining for `req.file?.path` is idiomatic modern JavaScript for nullable file uploads.
