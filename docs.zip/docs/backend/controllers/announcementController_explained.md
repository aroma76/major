# 📄 `controllers/announcementController.js` — Complete Explanation

**File Path:** `backend/controllers/announcementController.js`
**Lines:** 92
**Role:** Handles announcement CRUD for channels, with real-time Socket.IO broadcast and asynchronous student notifications.

---

## 1. 📌 File Purpose

`announcementController.js` manages announcements — faculty posts visible to all students in a channel. It demonstrates two important patterns:
1. **Real-time broadcast** via `getIO()` from `messageController`
2. **Fire-and-forget notification** — non-blocking async notifications that don't delay the HTTP response

---

## 2. 📤 Imports

```js
const pool    = require('../config/db');
const { getIO } = require('./messageController');
```

`getIO()` is the Socket.IO instance getter from `messageController.js`. This is the **shared socket bridge** — the announcement controller piggybacks on the socket instance that the message controller owns.

Why import from `messageController`? Because the Socket.IO server is initialized in `socketHandler.js` and registered with `messageController.js` via `setIO()`. Any controller that needs real-time broadcasting imports `getIO()`.

---

## 3. 📋 `getAnnouncements` — Channel Announcement List

```js
const getAnnouncements = async (req, res) => {
  const result = await pool.query(
    `SELECT a.*, u.name AS created_by_name, u.role AS creator_role
     FROM announcements a INNER JOIN users u ON a.user_id = u.id
     WHERE a.channel_id = $1 ORDER BY a.created_at DESC`,
    [req.params.id]
  );
  res.json({ success: true, announcements: result.rows });
};
```

- `a.*` + `u.name AS created_by_name` + `u.role AS creator_role` — All announcement data plus the poster's display name and role
- `INNER JOIN users u ON a.user_id = u.id` — Note: the FK is `user_id` (not `author_id`)
- `ORDER BY a.created_at DESC` — Newest announcements first

---

## 4. 📢 `createAnnouncement` — With Real-Time Broadcast

```js
const createAnnouncement = async (req, res) => {
  const { title, content, is_important = false } = req.body;
  if (!title || !content) {
    return res.status(400).json({ success: false, message: 'title and content required' });
  }

  const result = await pool.query(
    `INSERT INTO announcements (channel_id, user_id, title, content, is_important)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [req.params.id, req.user.id, title, content, is_important]
  );
  const announcement = result.rows[0];

  // Fetch creator info for socket payload
  const creatorRes = await pool.query('SELECT name, role FROM users WHERE id = $1', [req.user.id]);
  const creator = creatorRes.rows[0] ?? {};

  // Real-time broadcast
  try {
    const io = getIO();
    if (io) {
      io.to(`channel_${req.params.id}`).emit('announcement:new', {
        ...announcement,
        created_by_name : creator.name  ?? 'Faculty',
        creator_role    : creator.role  ?? 'faculty',
      });
    }
  } catch (err) {
    console.error('[Socket] Failed to emit announcement:new:', err.message);
  }

  // Fire-and-forget notifications
  pool.query(`SELECT user_id FROM enrollments WHERE channel_id=$1`, [req.params.id])
    .then(({ rows }) =>
      Promise.all(rows.map(s =>
        pool.query(
          `INSERT INTO notifications (user_id, type, title, message, ref_id, ref_type)
           VALUES ($1,'announcement',$2,$3,$4,'announcement')`,
          [s.user_id, `📢 ${title}`, content.substring(0, 120), announcement.id]
        )
      ))
    )
    .catch(err => console.error('[Notifications] Announcement notify error:', err.message));

  res.status(201).json({ success: true, announcement });
};
```

### Real-time Broadcast — Deep Explanation

```js
try {
  const io = getIO();
  if (io) {
    io.to(`channel_${req.params.id}`).emit('announcement:new', { ... });
  }
} catch (err) {
  console.error('[Socket] Failed to emit announcement:new:', err.message);
}
```

**Step 1: `getIO()`** — Retrieves the Socket.IO server instance that was registered by `socketHandler.js`.

**Step 2: `if (io)`** — Guards against the case where sockets haven't been initialized (e.g., in unit tests or if server started without socket support).

**Step 3: `io.to('channel_42').emit('announcement:new', payload)`**
- `to('channel_42')` — Targets the Socket.IO room named after the channel
- `.emit('announcement:new', ...)` — Sends the event to ALL sockets in that room
- This includes the faculty member who posted AND all enrolled students with open connections

**Step 4: `try/catch`** — Socket errors (connection issues, etc.) should NOT cause the 201 response to fail. The announcement IS saved to the DB regardless. The socket broadcast is best-effort.

### Creator Name Fetch

```js
const creatorRes = await pool.query('SELECT name, role FROM users WHERE id = $1', [req.user.id]);
const creator = creatorRes.rows[0] ?? {};
```

Why a second DB query? The announcement INSERT returns only the columns of the `announcements` table. The creator's name is in `users`. Rather than doing a JOIN on INSERT (which PostgreSQL doesn't natively support), a separate SELECT is used.

**`?? {}`** — Nullish coalescing: if `creatorRes.rows[0]` is undefined (shouldn't happen since `req.user.id` is always valid), uses empty object as fallback.

### Fire-and-Forget Notification Pattern

```js
pool.query(...)
  .then(...)
  .catch(err => console.error(...));

res.status(201).json({ success: true, announcement });
```

**Critically:** The `pool.query()` here is NOT awaited. It runs in the background AFTER `res.status(201).json(...)` has already sent the response.

Why? Because notifying 200 enrolled students involves 1 SELECT + 200 INSERTs. If all were awaited:
- The HTTP response would be delayed by 200ms-1000ms
- Any notification DB error would fail the entire announcement creation
- The response time would be O(n) with student count

With fire-and-forget:
- The announcement is created (DB) and broadcast (socket) immediately
- The 201 response is sent in ~10ms
- Notifications are written to DB in the background
- If notifications fail, they log an error but don't affect the announcement

**`.catch(err => console.error(...))`** — Ensures unhandled Promise rejection doesn't crash the Node.js process (which would happen without a `.catch()` on an unhandled Promise).

---

## 5. ❌ `deleteAnnouncement`

```js
const deleteAnnouncement = async (req, res) => {
  await pool.query('DELETE FROM announcements WHERE id=$1', [req.params.announcementId]);
  res.json({ success: true, message: 'Announcement deleted' });
};
```

Simple delete by ID. No ownership check — any faculty/admin can delete any announcement. The `authorize('admin', 'faculty')` middleware on the route handles the role restriction.

**Missing:** No check that the announcement belongs to the specified `channelId`. Could be tightened to `WHERE id=$1 AND channel_id=$2`.

---

## 6. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Student posting announcements | `authorize('admin', 'faculty')` on create/delete routes |
| Real-time exploit | Socket event contains DB-returned data, not client-provided data |
| Notification bombing | Content truncated to 120 chars (`content.substring(0, 120)`) |
| SQL injection | Parameterized queries throughout |

---

## 7. ✅ Final Summary

`announcementController.js` is the most architecturally interesting backend file because it combines three layers: synchronous DB write, real-time socket push, and asynchronous notification persistence — all in the correct order and with appropriate error isolation. The fire-and-forget pattern for notifications is a real production technique used in high-traffic systems.
