# 📄 `controllers/messageController.js` — Complete Explanation

**File Path:** `backend/controllers/messageController.js`
**Lines:** 136
**Role:** Handles all chat message operations — fetching, sending (with file support), pinning, deleting — and bridges REST uploads to real-time Socket.IO broadcasts.

---

## 1. 📌 File Purpose

This controller is the **messaging engine** of the platform. It uniquely bridges two communication protocols:
- **REST API** — For fetching history, file uploads, pinning, deleting
- **Socket.IO** — For real-time broadcast when a new message arrives via REST (file uploads)

> **Beginner Analogy:** The message controller is like a combination of a chat history archive (REST) and a real-time PA system (Socket.IO). When a teacher uploads a file, the controller saves it and immediately announces it to everyone in the class channel.

---

## 2. 🔌 Socket.IO Bridge

```js
let _io;
const setIO = (io) => { _io = io; };
```

- `_io` is a module-level variable that holds the Socket.IO server instance.
- `setIO` is called from `server.js` immediately after the Socket.IO server is created.
- This allows the REST controller to broadcast real-time events even though REST and WebSocket are separate systems.

**Why is this needed?**
Text messages go via WebSocket → `socketHandler.js`.
File uploads go via REST (WebSockets can't handle binary file data efficiently) → `messageController.js`.
After saving the file URL to the DB, the controller needs to tell all channel members via socket. `_io` is the bridge.

---

## 3. 📜 `getMessages()` — Paginated History with Cursor

```js
const getMessages = async (req, res) => {
  const { cursor } = req.query;
  const limit = parseInt(req.query.limit) || 50;

  const query = `
    SELECT m.*, u.name AS sender_name, u.role AS sender_role, u.avatar_url AS sender_avatar,
           p.content AS parent_content, pu.name AS parent_sender_name
    FROM messages m
    INNER JOIN users u ON m.sender_id = u.id
    LEFT JOIN messages p ON m.parent_id = p.id
    LEFT JOIN users pu ON p.sender_id = pu.id
    WHERE m.channel_id = $1 ${cursor ? 'AND m.id < $2' : ''}
    ORDER BY m.id DESC LIMIT $${cursor ? '3' : '2'}
  `;
  // ...
  res.json({ success: true, messages: result.rows.reverse() });
};
```

### JOINs Explained
| JOIN | Purpose |
|---|---|
| `INNER JOIN users u` | Get sender's name, role, and avatar |
| `LEFT JOIN messages p` | Get the parent (replied-to) message content |
| `LEFT JOIN users pu` | Get the parent message sender's name |

### Cursor-Based Pagination
- **Why cursor instead of page numbers?** If new messages arrive while the user scrolls, page-number pagination would show duplicates or skip messages. Cursor-based pagination is stable.
- `cursor` = the ID of the oldest message the client has loaded.
- `AND m.id < $2` — Fetches messages with IDs lower than the cursor (older messages).
- `ORDER BY m.id DESC` — Newest first (so the `LIMIT` takes the most recent ones).
- `result.rows.reverse()` — Reverses back to oldest-first order for UI chronological display.

**Example Flow:**
1. First load: no cursor → gets messages 150-200 (IDs DESC)
2. User scrolls up → sends `cursor=150` → gets messages 100-149
3. User scrolls more → sends `cursor=100` → gets messages 50-99

---

## 4. 📨 `sendMessage()` — File + Text Hybrid

```js
const sendMessage = async (req, res) => {
  const { content, parent_id } = req.body;
  const file_url  = req.file?.path         || null;
  const file_name = req.file?.originalname || null;

  if (!content && !file_url)
    return res.status(400).json({ ... 'Message content or file required' });

  if (content && content.length > 5000)
    return res.status(400).json({ ... 'Message too long (max 5000 characters)' });

  if (parent_id) {
    const parent = await pool.query('SELECT channel_id FROM messages WHERE id = $1', [parent_id]);
    if (!parent.rows.length || String(parent.rows[0].channel_id) !== String(req.params.id))
      return res.status(400).json({ ... 'Invalid parent message' });
  }

  const result = await pool.query(
    `INSERT INTO messages (channel_id, sender_id, content, file_url, file_name, parent_id)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *,
       (SELECT name       FROM users WHERE id=$2) AS sender_name,
       ...`,
    [req.params.id, req.user.id, content || null, file_url, file_name, parent_id || null]
  );

  const saved = result.rows[0];
  if (_io) _io.to(`channel_${req.params.id}`).emit('message:new', saved);
  res.status(201).json({ success: true, message: saved });
};
```

### Cross-Channel Parent Validation
```js
if (parent_id) {
  const parent = await pool.query('SELECT channel_id FROM messages WHERE id = $1', [parent_id]);
  if (!parent.rows.length || String(parent.rows[0].channel_id) !== String(req.params.id))
    return res.status(400).json({ ... 'Invalid parent message' });
}
```
- **Security:** Prevents a user from replying to a message from a different channel.
- Without this check, a user could craft a request to set `parent_id` to a message from a restricted channel, leaking its content in the `parent_content` field of the new message.
- `String(...)` coercion handles type mismatch between DB integer and URL string parameter.

### The RETURNING Subqueries
```js
RETURNING *,
  (SELECT name       FROM users WHERE id=$2) AS sender_name,
  (SELECT role       FROM users WHERE id=$2) AS sender_role,
  (SELECT avatar_url FROM users WHERE id=$2) AS sender_avatar,
  (SELECT p.content  FROM messages p WHERE p.id=$6) AS parent_content,
  (SELECT pu.name    FROM messages p JOIN users pu ON p.sender_id = pu.id WHERE p.id=$6) AS parent_sender_name
```
- Gets all related data in **one query** instead of multiple round-trips.
- The inserted message plus sender info plus parent info = complete object ready for immediate socket emit.

### Socket Broadcast
```js
if (_io) _io.to(`channel_${req.params.id}`).emit('message:new', saved);
```
- Broadcasts the complete message object to all users in the channel's socket room.
- The `if (_io)` guard handles the case where Socket.IO hasn't been initialized yet (shouldn't happen in production).

---

## 5. 📌 `pinMessage()` — Toggle Pin Status

```js
const pinMessage = async (req, res) => {
  const result = await pool.query(
    `UPDATE messages SET is_pinned = NOT is_pinned WHERE id=$1 RETURNING *`,
    [req.params.msgId]
  );
  ...
};
```
- `NOT is_pinned` — SQL toggle: if `true` becomes `false`, if `false` becomes `true`.
- One atomic SQL operation — no race condition between read and write.

---

## 6. 🗑️ `deleteMessage()` — Role-Based Deletion

```js
const deleteMessage = async (req, res) => {
  const msg = await pool.query('SELECT sender_id FROM messages WHERE id=$1', [req.params.msgId]);
  if (msg.rows[0].sender_id !== req.user.id && req.user.role !== 'admin' && req.user.role !== 'faculty')
    return res.status(403).json({ ... 'Not authorized' });
  await pool.query('DELETE FROM messages WHERE id=$1', [req.params.msgId]);
};
```

- Users can delete their own messages.
- Admin and faculty can delete anyone's message.
- This uses application-level authorization, not SQL constraints.

---

## 7. 📤 Exports

```js
module.exports = { getMessages, sendMessage, pinMessage, deleteMessage, getPinnedMessages, setIO, getIO: () => _io };
```
- `getIO` — Allows other modules (announcementController) to get the socket instance for broadcasting.

---

## 8. ✅ Final Summary

`messageController.js` is the most architecturally interesting controller because it bridges REST and WebSocket. The `setIO`/`getIO` pattern is a clean dependency injection that avoids circular imports. The cursor-based pagination is production-quality. The cross-channel parent validation prevents a subtle but real data leakage vulnerability.
