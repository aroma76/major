# 📄 `controllers/projectController.js` — Complete Explanation

**File Path:** `backend/controllers/projectController.js`
**Lines:** 166
**Role:** Full project and task management with PostgreSQL array aggregation, creator-only authorization checks, and automatic progress calculation.

---

## 1. 📌 File Purpose

Manages collaborative academic projects (group assignments, mini-projects, final year projects). Key responsibilities:
- List all projects a user is a member of (with member and task stats)
- Create projects with automatic creator enrollment
- Task Kanban management with auto-calculated progress

---

## 2. 🔍 `getProjects` — Aggregated Project List

```js
const getProjects = async (req, res) => {
  const result = await pool.query(
    `SELECT p.*, 
            u.name AS created_by_name,
            array_agg(DISTINCT m.user_id) AS member_ids,
            array_agg(DISTINCT mu.name) AS member_names,
            (SELECT COUNT(*) FROM project_tasks pt WHERE pt.project_id = p.id) AS task_count,
            (SELECT COUNT(*) FROM project_tasks pt WHERE pt.project_id = p.id AND pt.status = 'done') AS done_count
     FROM projects p
     JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = $1
     JOIN users u ON p.created_by = u.id
     LEFT JOIN project_members m ON m.project_id = p.id
     LEFT JOIN users mu ON mu.id = m.user_id
     GROUP BY p.id, u.name
     ORDER BY p.created_at DESC`,
    [req.user.id]
  );
  res.json({ success: true, projects: result.rows });
};
```

### SQL Deep Dive

**`JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = $1`**
- This is the access gate: only projects where the current user is a member appear
- It's an `INNER JOIN` — if the user is NOT in `project_members` for a project, that project is excluded

**`LEFT JOIN project_members m ON m.project_id = p.id`**
- A second join to `project_members` (aliased `m`) to get ALL members of each project (for the aggregation)
- `LEFT JOIN` — even if a project has no other members (only the creator), the project still appears

**`array_agg(DISTINCT m.user_id) AS member_ids`**
- `array_agg()` — PostgreSQL function that collects values into an array: `{1, 5, 42}`
- `DISTINCT` — Removes duplicates (the creator appears in both the first JOIN and second JOIN)
- Result: each project row has an array of all member IDs e.g., `[1, 5, 42]`

**Subqueries for counts:**
```sql
(SELECT COUNT(*) FROM project_tasks pt WHERE pt.project_id = p.id) AS task_count,
(SELECT COUNT(*) FROM project_tasks pt WHERE pt.project_id = p.id AND pt.status = 'done') AS done_count
```
- **Correlated subqueries** — Run once per project row in the outer query
- More readable than a GROUP BY + HAVING approach but slightly less performant for large datasets
- `done_count` enables the frontend to show "3/5 tasks done" without a second API call

**`GROUP BY p.id, u.name`**
- Required when using `array_agg()` — aggregation groups all member rows into one project row
- Must include `u.name` because it's a non-aggregated selected column (PostgreSQL strict mode requires all non-aggregate SELECTed columns to be in GROUP BY)

---

## 3. 🔍 `getProject` — Single Project with Members and Tasks

```js
const getProject = async (req, res) => {
  const project = await pool.query(
    `SELECT p.*, u.name AS created_by_name FROM projects p JOIN users u ON p.created_by = u.id WHERE p.id = $1`,
    [req.params.id]
  );
  if (!project.rows.length) return res.status(404).json(...);

  const members = await pool.query(
    `SELECT u.id, u.name, u.email, u.role, pm.joined_at FROM project_members pm 
     JOIN users u ON u.id = pm.user_id WHERE pm.project_id = $1`,
    [req.params.id]
  );
  const tasks = await pool.query(
    `SELECT pt.*, u.name AS assigned_to_name FROM project_tasks pt 
     LEFT JOIN users u ON u.id = pt.assigned_to WHERE pt.project_id = $1 ORDER BY pt.created_at DESC`,
    [req.params.id]
  );

  res.json({
    success: true,
    project: { ...project.rows[0], members: members.rows, tasks: tasks.rows }
  });
};
```

**Three separate queries** vs one JOIN:
- Clearer code
- Avoids a complex JOIN that would multiply rows (N members × M tasks = N×M rows to de-duplicate)
- Three small queries are often faster than one large complex query

**`{ ...project.rows[0], members: ..., tasks: ... }`** — Spread operator merges the project object with the member and task arrays into a single rich response object.

---

## 4. ➕ `createProject` — Auto-Add Creator as Member

```js
const createProject = async (req, res) => {
  const { title, description, deadline, member_ids } = req.body;
  
  const result = await pool.query(
    `INSERT INTO projects (title, description, deadline, created_by, progress) 
     VALUES ($1, $2, $3, $4, 0) RETURNING *`,
    [title, description || null, deadline || null, req.user.id]
  );
  const project = result.rows[0];

  // Auto-add creator + requested members (deduplicated)
  const allMembers = [req.user.id, ...(member_ids || [])].filter((v, i, a) => a.indexOf(v) === i);
  await Promise.all(allMembers.map(uid =>
    pool.query(
      `INSERT INTO project_members (project_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, 
      [project.id, uid]
    )
  ));

  res.status(201).json({ success: true, project });
};
```

### Deduplication Logic

```js
const allMembers = [req.user.id, ...(member_ids || [])].filter((v, i, a) => a.indexOf(v) === i);
```

**Breaking it down:**
1. `[req.user.id, ...(member_ids || [])]` — Creates an array starting with the creator, then spreading the requested members. If `member_ids` is undefined, uses `[]`.
2. `.filter((v, i, a) => a.indexOf(v) === i)` — Classic deduplication:
   - `v` = current value
   - `i` = current index
   - `a` = the full array
   - `a.indexOf(v) === i` — true only for the FIRST occurrence of `v`
   - If the creator is also in `member_ids`, they only appear once

### `ON CONFLICT DO NOTHING`

```sql
INSERT INTO project_members (project_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING
```

If a user is already a member (violates the `UNIQUE (project_id, user_id)` constraint), this silently skips rather than throwing an error. Essential for idempotent bulk operations.

---

## 5. 📊 `updateProgress` — Creator-Only Authorization

```js
const updateProgress = async (req, res) => {
  const { progress } = req.body;
  if (progress === undefined || progress < 0 || progress > 100)
    return res.status(400).json({ success: false, message: 'progress must be 0–100' });
    
  const check = await pool.query('SELECT created_by FROM projects WHERE id = $1', [req.params.id]);
  if (!check.rows.length) return res.status(404).json(...);
  if (check.rows[0].created_by !== req.user.id)
    return res.status(403).json({ success: false, message: 'Not authorized to update this project' });
    
  const result = await pool.query(
    `UPDATE projects SET progress = $1 WHERE id = $2 RETURNING *`, [progress, req.params.id]
  );
  res.json({ success: true, project: result.rows[0] });
};
```

**Pattern:** Fetch `created_by` first, compare to `req.user.id`, reject if not the creator. This is a resource-level ownership check — more fine-grained than role-based middleware.

**`progress === undefined`** — Checks for missing field. `progress < 0 || progress > 100` validates range.

---

## 6. ✨ `updateTaskStatus` — Auto Progress Calculation

```js
const updateTaskStatus = async (req, res) => {
  const result = await pool.query(
    `UPDATE project_tasks SET status = $1 WHERE id = $2 AND project_id = $3 RETURNING *`,
    [status, req.params.taskId, req.params.id]
  );
  if (!result.rows.length) return res.status(404).json(...);

  // Auto-update project progress
  const counts = await pool.query(
    `SELECT COUNT(*) AS total, COUNT(*) FILTER (WHERE status = 'done') AS done 
     FROM project_tasks WHERE project_id = $1`,
    [req.params.id]
  );
  const { total, done } = counts.rows[0];
  const progress = total > 0 ? Math.round((done / total) * 100) : 0;
  await pool.query(`UPDATE projects SET progress = $1 WHERE id = $2`, [progress, req.params.id]);

  res.json({ success: true, task: result.rows[0], progress });
};
```

### PostgreSQL `FILTER` Clause

```sql
COUNT(*) FILTER (WHERE status = 'done') AS done
```

`FILTER (WHERE ...)` is a PostgreSQL 9.4+ feature. It applies a condition to the aggregate function:
- `COUNT(*)` counts all tasks
- `COUNT(*) FILTER (WHERE status = 'done')` counts only tasks where status is `'done'`

This replaces the equivalent subquery:
```sql
(SELECT COUNT(*) FROM project_tasks WHERE project_id=$1 AND status='done')
```
The `FILTER` approach is more efficient — one scan vs two.

### Progress Formula

```js
const progress = total > 0 ? Math.round((done / total) * 100) : 0;
```
- `total > 0` — Guard against division by zero
- `Math.round(...)` — Rounds to nearest integer (e.g., 1/3 tasks done → 33%)
- Result stored as `DECIMAL(5,2)` in DB

### Security: Task-Project Binding

```sql
WHERE id = $2 AND project_id = $3
```

Requires both the task ID AND project ID to match. Without `AND project_id = $3`, a user could update any task by knowing only its ID.

---

## 7. ✅ Final Summary

`projectController.js` is the most SQL-sophisticated controller in the codebase. The `array_agg(DISTINCT ...)` pattern in `getProjects`, the `COUNT(*) FILTER` in `updateTaskStatus`, and the creator ownership check pattern are all production-quality PostgreSQL techniques. The auto-progress calculation on task status change creates a seamless UX where the progress bar updates automatically on Kanban moves.
