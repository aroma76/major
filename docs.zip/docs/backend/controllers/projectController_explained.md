# Word-by-Word Deep Dive: `backend/controllers/projectController.js`

> This file manages **collaborative Kanban projects** — faculty or students can create projects, add real classroom members via a member-picker, manage tasks on a Jira-style board, and track progress automatically. Members are stored in the `project_members` table (real user accounts), not as custom name strings.

---

## Auto-Migration (Top of File)

```js
pool.query(`ALTER TABLE project_tasks ADD COLUMN IF NOT EXISTS assigned_to_name TEXT DEFAULT NULL`)
  .catch(err => console.warn('Migration warning (assigned_to_name):', err.message));
```

Runs on server startup to ensure the `assigned_to_name` column exists. Uses `IF NOT EXISTS` so it is safe to run every time — it does nothing if the column already exists. `custom_members` is no longer used; all members live in `project_members`.

---

## `getProjects` — Fetching All Projects With Members

```js
const getProjects = async (req, res) => {
  const result = await pool.query(
    `SELECT p.*,
            u.name AS created_by_name,
            (SELECT COUNT(*) FROM project_tasks pt WHERE pt.project_id = p.id) AS task_count,
            (SELECT COUNT(*) FROM project_tasks pt WHERE pt.project_id = p.id AND pt.status = 'done') AS done_count,
            COALESCE(
              (SELECT json_agg(json_build_object('id', mu.id, 'name', mu.name))
               FROM project_members pm
               JOIN users mu ON pm.user_id = mu.id
               WHERE pm.project_id = p.id),
              '[]'
            ) AS members
     FROM projects p
     JOIN users u ON p.created_by = u.id
     WHERE p.id IN (
       SELECT project_id FROM project_members WHERE user_id = $1
     )
     ORDER BY p.created_at DESC`,
    [req.user.id]
  );
  const projects = result.rows.map(p => ({
    ...p,
    member_names: (p.members || []).map(m => m.name),
  }));
  res.json({ success: true, projects });
};
```

### `WHERE p.id IN (SELECT project_id FROM project_members WHERE user_id = $1)`

A **subquery in WHERE** — filters projects to only those where the logged-in user is a member. This is the access-control gate: you only see projects you belong to.

### `COALESCE(... json_agg(...), '[]')`

- **`json_agg(json_build_object(...))`** — PostgreSQL aggregate that collects rows into a JSON array of objects: `[{"id":1,"name":"Alice"},{"id":2,"name":"Bob"}]`
- **`json_build_object('id', mu.id, 'name', mu.name)`** — builds a JSON object per member
- **`COALESCE(..., '[]')`** — if the subquery returns NULL (no members), fall back to an empty JSON array `'[]'`

### `member_names: (p.members || []).map(m => m.name)`

After the query, a `.map()` extracts a flat string array of names for easy display: `['Alice', 'Bob']`.

---

## `getProject` — Fetching a Single Project With Tasks and Members

```js
const getProject = async (req, res) => {
  const project = await pool.query(
    `SELECT p.*, u.name AS created_by_name,
            COALESCE(
              (SELECT json_agg(json_build_object('id', mu.id, 'name', mu.name))
               FROM project_members pm JOIN users mu ON pm.user_id = mu.id
               WHERE pm.project_id = p.id),
              '[]'
            ) AS members
     FROM projects p JOIN users u ON p.created_by = u.id
     WHERE p.id = $1`,
    [req.params.id]
  );
  const tasks = await pool.query(
    `SELECT pt.* FROM project_tasks pt WHERE pt.project_id = $1 ORDER BY pt.created_at DESC`,
    [req.params.id]
  );
  res.json({
    success: true,
    project: { ...p, member_names: memberNames, members, tasks: tasks.rows }
  });
};
```

Two sequential queries — one for the project + members, one for tasks. The spread operator merges them into one nested response object Flutter can consume directly.

---

## `createProject` — Creating a Project

```js
const createProject = async (req, res) => {
  const { title, description, deadline } = req.body;
  // ... validation ...
  const result = await pool.query(
    `INSERT INTO projects (title, description, deadline, created_by, progress)
     VALUES ($1, $2, $3, $4, 0) RETURNING *`,
    [title, description || null, deadline || null, req.user.id]
  );
  // Always add the creator as a member
  await pool.query(
    `INSERT INTO project_members (project_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
    [project.id, req.user.id]
  );
  res.status(201).json({ success: true, project });
};
```

- `progress: 0` — new projects start at 0%. Automatically recalculated as tasks are completed.
- **Creator is always auto-added** as the first member via `ON CONFLICT DO NOTHING` (safe upsert — no error if already exists).
- Members are **not passed at creation time** — they are added later via the member-picker (see `addMember`).

---

## `getClassroomStudents` — Fetching Addable Members (NEW)

```js
const getClassroomStudents = async (req, res) => {
  const proj = await pool.query(
    `SELECT p.created_by, u.role, u.programme_id, u.current_semester
     FROM projects p JOIN users u ON p.created_by = u.id WHERE p.id = $1`,
    [req.params.id]
  );
  const { created_by: creatorId, role: creatorRole, programme_id, current_semester } = proj.rows[0];
  ...
```

Returns a list of students who can be added to the project, excluding existing members. Uses a **3-tier priority** fallback strategy:

### Priority 1 (Faculty creator)
```sql
SELECT DISTINCT u.id, u.name, u.roll_number
FROM users u
LEFT JOIN enrollments e ON e.user_id = u.id
LEFT JOIN channels c ON e.channel_id = c.id
WHERE (u.role = 'student' OR u.role = 'class_representative')
  AND (
    c.teacher_id = $1
    OR u.programme_id IN (
      SELECT b.programme_id FROM channels ch JOIN batches b ON ch.batch_id = b.id WHERE ch.teacher_id = $1
    )
  )
  AND u.id NOT IN (SELECT user_id FROM project_members WHERE project_id = $2)
```
Gets students enrolled in the faculty's channels OR in programmes those channels belong to.

### Priority 1 (Student creator) — Same Enrolled Channels
```sql
SELECT DISTINCT u.id, u.name, u.roll_number
FROM users u
JOIN enrollments e ON e.user_id = u.id
WHERE ... AND e.channel_id IN (SELECT channel_id FROM enrollments WHERE user_id = $1)
  AND u.id NOT IN (SELECT user_id FROM project_members WHERE project_id = $2)
  AND u.id != $1
```
Gets classmates enrolled in any of the same channels as the creator.

### Priority 2 (Cohort Fallback) — Same Programme + Semester
If enrollment returns 0 results, falls back to users with matching `programme_id` and `current_semester`.

### Final Bulletproof Fallback — All Students
If still 0 results (e.g. new user with no enrollments), returns ALL students and class representatives in the database, minus existing members.

**`DISTINCT`** in all queries prevents duplicate rows when a user is enrolled in multiple matching channels.

---

## `addMember` — Adding a Member to a Project (NEW)

```js
const addMember = async (req, res) => {
  const { user_id } = req.body;
  // ... verify project exists, verify caller is creator ...
  await pool.query(
    `INSERT INTO project_members (project_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
    [req.params.id, user_id]
  );
  const user = await pool.query('SELECT id, name FROM users WHERE id = $1', [user_id]);
  res.status(201).json({ success: true, member: user.rows[0] });
};
```

- Only the **project creator** can add members (`created_by !== req.user.id` → 403).
- Returns the added member's `{id, name}` so the frontend can update the member list immediately without a full re-fetch.

---

## `removeMember` — Removing a Member (NEW)

```js
const removeMember = async (req, res) => {
  // ... verify project exists, verify caller is creator ...
  const targetUserId = parseInt(req.params.userId);
  if (targetUserId === proj.rows[0].created_by)
    return res.status(400).json({ success: false, message: 'Cannot remove the project creator' });

  await pool.query(
    'DELETE FROM project_members WHERE project_id = $1 AND user_id = $2',
    [req.params.id, targetUserId]
  );
  res.json({ success: true, message: 'Member removed' });
};
```

- `parseInt(req.params.userId)` — URL params are strings; convert to number before comparing with DB integer IDs.
- **Guard**: the creator can never be removed from their own project.

---

## `createTask` — Adding a Task

```js
const createTask = async (req, res) => {
  const { title, description, assigned_to_name, due_date, priority } = req.body;
  const result = await pool.query(
    `INSERT INTO project_tasks
       (project_id, title, description, assigned_to_name, due_date, priority, status, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, 'todo', $7) RETURNING *`,
    [req.params.id, title, description || null, assigned_to_name || null,
     due_date || null, priority || 'medium', req.user.id]
  );
  res.status(201).json({ success: true, task: result.rows[0] });
};
```

- `assigned_to_name` — a TEXT field storing the assignee's display name (not a foreign key). Allows flexible assignment without requiring the assignee to be a registered user.
- `status` defaults to `'todo'` — every task starts in the "To Do" column.
- `priority` defaults to `'medium'` if not provided.

---

## `updateTask` — Full Task Edit (NEW)

```js
const updateTask = async (req, res) => {
  const { title, description, priority, due_date, assigned_to_name } = req.body;
  const result = await pool.query(
    `UPDATE project_tasks
     SET title = $1, description = $2, priority = $3, due_date = $4, assigned_to_name = $5
     WHERE id = $6 AND project_id = $7
     RETURNING *`,
    [title, description || null, priority || 'medium',
     due_date || null, assigned_to_name || null,
     req.params.taskId, req.params.id]
  );
  res.json({ success: true, task: result.rows[0] });
};
```

Allows editing ALL task fields in one call. `WHERE id = $6 AND project_id = $7` — double condition ensures the task belongs to this project (prevents cross-project edits).

---

## `updateTaskStatus` — Kanban Column Move + Auto Progress

```js
const updateTaskStatus = async (req, res) => {
  const { status } = req.body;
  const allowed = ['todo', 'in_progress', 'done'];
  if (!allowed.includes(status)) return res.status(400).json({...});

  const result = await pool.query(
    `UPDATE project_tasks SET status = $1 WHERE id = $2 AND project_id = $3 RETURNING *`,
    [status, req.params.taskId, req.params.id]
  );

  const counts = await pool.query(
    `SELECT COUNT(*) AS total, COUNT(*) FILTER (WHERE status = 'done') AS done
     FROM project_tasks WHERE project_id = $1`,
    [req.params.id]
  );
  const { total, done } = counts.rows[0];
  const progress = total > 0 ? Math.round((done / total) * 100) : 0;
  await pool.query(`UPDATE projects SET progress = $1 WHERE id = $2`, [progress, req.params.id]);

  res.json({ success: true, task: result.rows[0], progress });
};
```

### `COUNT(*) FILTER (WHERE status = 'done') AS done`

**`FILTER (WHERE condition)`** — PostgreSQL extension to aggregate functions. Gets total count AND done count in a single query instead of two.

### Auto-Progress Calculation

`progress = total > 0 ? Math.round((done / total) * 100) : 0`

- `total` and `done` come as strings from PostgreSQL (`bigint` → JS string)
- JS coerces strings in arithmetic: `'3' / '5'` → `0.6`
- `Math.round` → integer percentage stored back to `projects.progress`

---

## `deleteTask` — Deleting a Task + Recalculate Progress (NEW)

```js
const deleteTask = async (req, res) => {
  const result = await pool.query(
    `DELETE FROM project_tasks WHERE id = $1 AND project_id = $2 RETURNING *`,
    [req.params.taskId, req.params.id]
  );
  if (!result.rows.length) return res.status(404).json({...});

  // Recalculate progress after deletion
  const counts = await pool.query(...);
  const progress = total > 0 ? Math.round((done / total) * 100) : 0;
  await pool.query(`UPDATE projects SET progress = $1 WHERE id = $2`, [progress, req.params.id]);

  res.json({ success: true, message: 'Task deleted', progress });
};
```

After deleting a task the project progress is recalculated automatically, same logic as `updateTaskStatus`.

---

## Summary Table

| Function | Method | URL | Key Feature |
|---|---|---|---|
| `getProjects` | GET | `/api/projects` | `json_agg` members, correlated subqueries for task counts |
| `getProject` | GET | `/api/projects/:id` | Two queries merged with spread into nested response |
| `createProject` | POST | `/api/projects` | Creator auto-added, no members at creation time |
| `getClassroomStudents` | GET | `/api/projects/:id/students` | 3-tier fallback: channels → cohort → all students |
| `addMember` | POST | `/api/projects/:id/members` | Creator-only, `ON CONFLICT DO NOTHING` |
| `removeMember` | DELETE | `/api/projects/:id/members/:userId` | Creator-only, cannot remove creator |
| `updateProgress` | PATCH | `/api/projects/:id/progress` | Manual override (0–100) |
| `deleteProject` | DELETE | `/api/projects/:id` | Creator-only, cascades tasks |
| `createTask` | POST | `/api/projects/:id/tasks` | assigned_to_name (TEXT), status defaults to 'todo' |
| `updateTask` | PATCH | `/api/projects/:id/tasks/:taskId` | Full field edit |
| `updateTaskStatus` | PATCH | `.../tasks/:taskId/status` | Auto-recalculates project % using `FILTER` aggregate |
| `deleteTask` | DELETE | `.../tasks/:taskId` | Deletes + recalculates project progress |

| SQL Technique | Where | What It Does |
|---|---|---|
| `json_agg(json_build_object(...))` | `getProjects`, `getProject` | Collect members as JSON array of objects |
| `COALESCE(..., '[]')` | `getProjects`, `getProject` | Safe default when no members exist |
| Subquery in WHERE (`IN`) | `getProjects` | Filter to only user's projects |
| `ON CONFLICT DO NOTHING` | `createProject`, `addMember` | Safe INSERT ignoring duplicates |
| `COUNT(*) FILTER (WHERE ...)` | `updateTaskStatus`, `deleteTask` | Count done vs total in one query |
| `DISTINCT` | `getClassroomStudents` | Prevent duplicates from multi-channel enrollment |
