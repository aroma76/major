# 📄 `controllers/channelController.js` — Complete Explanation

**File Path:** `backend/controllers/channelController.js`
**Lines:** 129
**Role:** Handles all CRUD operations for Channels (subject rooms), including role-based filtered listing and member retrieval.

---

## 1. 📌 File Purpose

`channelController.js` manages the **subject room** resource — the core academic entity around which all content (messages, assignments, announcements) is organized. It answers:
- What channels can *this* user see? (role-dependent)
- What is the detail of *this* channel?
- How do admins create/update/delete channels?
- Who are the members of *this* channel?

> **Beginner Analogy:** Think of channels as university classrooms. An admin can see all classrooms. A teacher only sees the ones they teach. A student only sees the ones they're enrolled in.

---

## 2. 📤 Import

```js
const pool = require('../config/db');
```
Only one import: the PostgreSQL connection pool. No authentication middleware is imported here — that's handled by the router before this controller runs.

---

## 3. 🔍 `getChannels` — Role-Based Channel List

```js
const getChannels = async (req, res) => {
  let result;
  if (req.user.role === 'admin') {
    result = await pool.query(
      `SELECT c.*, u.name AS teacher_name, p.name AS programme_name 
       FROM channels c 
       LEFT JOIN users u ON c.teacher_id = u.id 
       LEFT JOIN batches b ON c.batch_id = b.id
       LEFT JOIN programmes p ON b.programme_id = p.id
       ORDER BY c.subject_name`
    );
  } else if (req.user.role === 'faculty') {
    result = await pool.query(
      `SELECT c.*, u.name AS teacher_name, p.name AS programme_name 
       FROM channels c 
       LEFT JOIN users u ON c.teacher_id = u.id 
       LEFT JOIN batches b ON c.batch_id = b.id
       LEFT JOIN programmes p ON b.programme_id = p.id
       WHERE c.teacher_id = $1 ORDER BY c.subject_name`, 
      [req.user.id]
    );
  } else {
    result = await pool.query(
      `SELECT c.*, u.name AS teacher_name, p.name AS programme_name 
       FROM channels c 
       LEFT JOIN users u ON c.teacher_id = u.id 
       LEFT JOIN batches b ON c.batch_id = b.id
       LEFT JOIN programmes p ON b.programme_id = p.id
       INNER JOIN enrollments e ON e.channel_id = c.id 
       WHERE e.user_id = $1 ORDER BY c.subject_name`, 
      [req.user.id]
    );
  }
  res.json({ success: true, channels: result.rows });
};
```

### Line-by-Line Explanation

**`let result;`** — Declares `result` without initializing it. The correct query is assigned based on role in the if/else chain.

**Admin branch:**
```sql
SELECT c.*, u.name AS teacher_name, p.name AS programme_name 
FROM channels c 
LEFT JOIN users u ON c.teacher_id = u.id 
LEFT JOIN batches b ON c.batch_id = b.id
LEFT JOIN programmes p ON b.programme_id = p.id
ORDER BY c.subject_name
```
- `c.*` — All columns from the `channels` table
- `u.name AS teacher_name` — Teacher's name aliased for the frontend
- `p.name AS programme_name` — Programme (degree) name via two-hop JOIN: `channels → batches → programmes`
- `LEFT JOIN` — If `teacher_id` is NULL, the channel still appears (created without an assigned teacher)
- No `WHERE` clause — admin sees everything

**Faculty branch:**
- Adds `WHERE c.teacher_id = $1` — only channels taught by this faculty member
- `$1 = req.user.id` — parameterized, never interpolated (SQL injection safe)

**Student branch:**
- Uses `INNER JOIN enrollments e ON e.channel_id = c.id` — only channels with an enrollment record for this student
- `INNER JOIN` (not LEFT) — channel must have a matching enrollment to appear
- Students see EXACTLY the channels they are enrolled in, nothing else

**`res.json({ success: true, channels: result.rows })`**
- `result.rows` — Array of row objects from pg
- Consistent JSON envelope: `{ success: true, data }` pattern used throughout the app

---

## 4. 🔍 `getChannel` — Single Channel Detail

```js
const getChannel = async (req, res) => {
  const result = await pool.query(
    `SELECT c.*, u.name AS teacher_name, p.name AS programme_name 
     FROM channels c 
     LEFT JOIN users u ON c.teacher_id = u.id 
     LEFT JOIN batches b ON c.batch_id = b.id
     LEFT JOIN programmes p ON b.programme_id = p.id
     WHERE c.id = $1`, 
    [req.params.id]
  );
  if (!result.rows.length) return res.status(404).json({ success: false, message: 'Channel not found' });
  res.json({ success: true, channel: result.rows[0] });
};
```

- `req.params.id` — The `:id` URL segment from `GET /api/channels/:id`
- `!result.rows.length` — Empty array means no channel with that ID
- Returns `result.rows[0]` — First (and only) row since ID is a primary key

---

## 5. ➕ `createChannel` — Admin Channel Creation

```js
const createChannel = async (req, res) => {
  const { batch_id, semester_number, subject_name, subject_slug, channel_name, teacher_id } = req.body;
  
  if (!batch_id || !semester_number || !subject_name || !subject_slug || !channel_name)
    return res.status(400).json({ success: false, message: 'Missing required channel information' });
    
  const result = await pool.query(
    `INSERT INTO channels (batch_id, semester_number, subject_name, subject_slug, channel_name, teacher_id) 
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
    [batch_id, semester_number, subject_name, subject_slug, channel_name, teacher_id || null]
  );
  res.status(201).json({ success: true, channel: result.rows[0] });
};
```

- **Destructuring** — `const { batch_id, ... } = req.body` extracts exactly the fields needed
- **Validation** — Checks all required fields before touching the database
- **`teacher_id || null`** — If `teacher_id` is falsy (`undefined`, `0`, empty string), stores `NULL`. This allows creating channels without an assigned teacher.
- **`RETURNING *`** — Returns the fully inserted row including the auto-generated `id` and `created_at`
- **`res.status(201)`** — HTTP 201 Created (not 200 OK) for resource creation

---

## 6. ✏️ `updateChannel` — Admin Channel Update

```js
const updateChannel = async (req, res) => {
  const { subject_name, subject_slug, channel_name, teacher_id } = req.body;
  const result = await pool.query(
    `UPDATE channels SET subject_name=$1, subject_slug=$2, channel_name=$3, teacher_id=$4 WHERE id=$5 RETURNING *`,
    [subject_name, subject_slug, channel_name, teacher_id, req.params.id]
  );
  if (!result.rows.length) return res.status(404).json({ success: false, message: 'Channel not found' });
  res.json({ success: true, channel: result.rows[0] });
};
```

- **Flat `SET`** — Replaces all four fields every time (no partial update). If any field is `undefined`, it will be set to `null` in the DB — a potential bug.
- **`WHERE id=$5`** — Uses the URL param to identify which channel to update
- **`RETURNING *`** — Returns updated row for immediate display

---

## 7. ❌ `deleteChannel` — Admin Channel Delete

```js
const deleteChannel = async (req, res) => {
  await pool.query('DELETE FROM channels WHERE id=$1', [req.params.id]);
  res.json({ success: true, message: 'Channel deleted' });
};
```

**⚠️ Cascade behavior:** The DB schema has `ON DELETE CASCADE` on:
- `enrollments.channel_id` → all enrollments deleted
- `messages.channel_id` → all messages deleted
- `assignments.channel_id` → all assignments deleted
- `announcements.channel_id` → all announcements deleted

So one `DELETE channels WHERE id=$1` cascades to delete ALL related data. This is intentional.

**No 404 check:** If the channel doesn't exist, the `DELETE` simply deletes 0 rows and still returns `{ success: true }`. This is acceptable (idempotent delete).

---

## 8. 👥 `getChannelMembers` — Enrolled User List

```js
const getChannelMembers = async (req, res) => {
  const result = await pool.query(
    `SELECT u.id, u.name, u.email, u.role, u.roll_number, u.avatar_initials, u.avatar_url
     FROM users u 
     INNER JOIN enrollments e ON e.user_id = u.id 
     WHERE e.channel_id = $1 ORDER BY u.role, u.name`,
    [req.params.id]
  );
  res.json({ success: true, members: result.rows });
};
```

- **Selective columns** — Only safe, non-sensitive fields (no `password` hash)
- **`ORDER BY u.role, u.name`** — Sorts by role first (faculty before student alphabetically) then by name
- **`INNER JOIN enrollments`** — Only enrolled users appear; faculty assigned as `teacher_id` but not enrolled won't appear

---

## 9. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Student reading other channels | `INNER JOIN enrollments WHERE e.user_id = $1` |
| SQL injection | 100% parameterized queries |
| Unauthorized create/update/delete | `authorize('admin')` middleware on routes |
| Password leak | `getChannelMembers` explicitly lists only safe columns |

---

## 10. 🐛 Issues

1. **`updateChannel` null overwrite** — If `teacher_id` is omitted from the request body, it becomes `undefined` which pg sends as `NULL`, removing the teacher assignment unintentionally.
2. **No cross-role access check for `getChannel`** — Any authenticated user can fetch details of any channel by ID, even ones they're not enrolled in. The frontend doesn't call this for unenrolled channels, but the API is technically open.
3. **No 404 for `deleteChannel`** — Silent success even if channel ID doesn't exist.

---

## 11. ✅ Final Summary

`channelController.js` implements clean role-based data access through three distinct SQL queries in `getChannels`. The cascade deletion strategy keeps the controller simple. The only significant gap is the lack of partial-update support in `updateChannel` and the missing access check in `getChannel`.
