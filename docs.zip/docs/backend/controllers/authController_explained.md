# 📄 `controllers/authController.js` — Complete Explanation

**File Path:** `backend/controllers/authController.js`
**Lines:** 175
**Role:** Handles user registration, login, profile retrieval, profile update, and password change.

---

## 1. 📌 File Purpose

This is the **authentication brain** of the backend. It manages the complete user identity lifecycle:
- Creating new accounts with hashed passwords
- Verifying credentials and issuing JWT tokens
- Returning the current user's profile
- Updating profile fields
- Changing passwords securely

---

## 2. 🔗 Imports

```js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
```

| Import | Purpose |
|---|---|
| `bcrypt` | Password hashing and comparison |
| `jwt` | JWT token generation |
| `pool` | Database connection for user queries |

---

## 3. 🔑 `generateToken()` Helper — Line-by-Line

```js
const generateToken = (user) =>
  jwt.sign(
    { id: user.id, role: user.role, name: user.name, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
```

- `jwt.sign(payload, secret, options)` — Creates a JWT.
- **Payload:** `{ id, role, name, email }` — The data embedded in the token. Embedding `role` is the key optimization that lets `auth.js` skip the DB query on every request.
- **Secret:** `JWT_SECRET` from `.env` — A long random string used to sign the token. Anyone with this secret can forge tokens.
- **Expiry:** `JWT_EXPIRES_IN` (default `'7d'`) — Token becomes invalid after 7 days.

> **Security principle:** Only embed public-safe data in JWT. Never embed passwords, SSNs, or sensitive fields.

---

## 4. 📝 `register()` — Complete Line-by-Line

```js
const register = async (req, res) => {
  const { name, email, password, roll_number } = req.body;
  const role = 'student'; // [C1] Role hardcoded — never from request
```

### Security: Role Hardcoding
```js
const role = 'student';
```
- **Critical security decision:** The role is NEVER taken from `req.body`.
- Without this, a malicious user could send `{ role: 'admin' }` and gain admin access.
- Admin and faculty accounts are created through database seeding or a separate admin-only endpoint.

### Password Validation
```js
const strongPassword = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;
if (!strongPassword.test(password))
  return res.status(400).json({ ... });
```
- Regex breakdown:
  - `(?=.*[A-Za-z])` — Lookahead: must contain at least one letter
  - `(?=.*\d)` — Lookahead: must contain at least one digit
  - `.{8,}` — At least 8 characters total
- Returns 400 if the password is too weak.

### Duplicate Checks
```js
const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
if (existing.rows.length > 0)
  return res.status(400).json({ ... 'This email is already registered' });

const rollExist = await pool.query('SELECT id FROM users WHERE roll_number = $1', [roll_number]);
if (rollExist.rows.length > 0)
  return res.status(400).json({ ... 'This Roll Number is already registered' });
```
- Two separate queries check email and roll_number uniqueness.
- Returns 400 with specific messages so the user knows exactly what's wrong.

### Password Hashing
```js
const hashed = await bcrypt.hash(password, 10);
```
- `bcrypt.hash(plaintext, saltRounds)` — Hashes the password.
- `10` salt rounds = ~100ms computation time. This is intentional — makes brute-force attacks slow.
- The hash is stored in the database. The original password is NEVER stored.

### Avatar Initials
```js
const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
```
- Example: `"Rahul Kumar Sharma"` → `['R', 'K', 'S']` → `"RKS"` → `"RK"` (max 2)
- Used for avatar fallback when no profile photo is set.

### Database INSERT
```js
const result = await pool.query(
  `INSERT INTO users (name, email, password, role, roll_number, avatar_initials)
   VALUES ($1, $2, $3, $4, $5, $6)
   RETURNING id, name, email, role, roll_number, avatar_initials`,
  [name, email, hashed, role, roll_number || null, initials]
);
```
- Parameterized query — `$1` through `$6` prevent SQL injection.
- `RETURNING` — Returns the new row data immediately without a second SELECT.
- Password hash is stored but NOT returned.

### Response
```js
res.status(201).json({ success: true, token: generateToken(user), user });
```
- 201 Created.
- Returns a JWT immediately — user is logged in right after registration.

---

## 5. 🔓 `login()` — Complete Line-by-Line

```js
const login = async (req, res) => {
  const { identifier, password } = req.body;
```

- `identifier` — Can be either email (`john@adtu.in`) or roll number (`21CS001`).

```js
const isEmail = identifier.includes('@');
const query = isEmail
  ? 'SELECT * FROM users WHERE email = $1'
  : 'SELECT * FROM users WHERE roll_number = $1';
```
- Smart detection: if the identifier contains `@`, treat as email; otherwise treat as roll number.
- `SELECT *` is acceptable here because we need all fields (including password hash for comparison).

```js
if (result.rows.length === 0)
  return res.status(401).json({ success: false, message: 'Invalid credentials' });
```
- **Security:** Same message whether the account doesn't exist OR the password is wrong.
- This prevents "account enumeration" — an attacker can't tell if a specific email/roll number is registered.

```js
const match = await bcrypt.compare(password, user.password);
if (!match)
  return res.status(401).json({ success: false, message: 'Invalid credentials' });
```
- `bcrypt.compare(plaintext, hash)` — Verifies the password against the stored hash.
- Returns `true` if they match, `false` otherwise.
- bcrypt internally re-hashes the input with the stored salt and compares — no rainbow table attacks possible.

```js
const { password: _, ...safeUser } = user;
res.json({ success: true, token: generateToken(safeUser), user: safeUser });
```
- **Destructuring to exclude password:** `{ password: _, ...safeUser }` renames `password` to `_` (discards it) and spreads the rest into `safeUser`.
- The password hash is NEVER sent to the client.

---

## 6. 👤 `getMe()` — Profile Retrieval

```js
const getMe = async (req, res) => res.json({ success: true, user: req.user });
```
- One line! The `protect` middleware already populated `req.user` from the JWT.
- No database query needed for modern tokens.

---

## 7. ✏️ `updateProfile()` — Dynamic Update

```js
const updateProfile = async (req, res) => {
  const { name, dob } = req.body;
  const avatar_url = req.file?.path || null;
  const fields = []; const values = []; let idx = 1;

  if (name) {
    fields.push(`name = $${idx++}`); values.push(name);
    const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
    fields.push(`avatar_initials = $${idx++}`); values.push(initials);
  }
  if (dob)        { fields.push(`dob = $${idx++}`);        values.push(dob); }
  if (avatar_url) { fields.push(`avatar_url = $${idx++}`); values.push(avatar_url); }
  if (!fields.length) return res.status(400).json({ ... 'No fields to update' });

  values.push(req.user.id);
  const result = await pool.query(
    `UPDATE users SET ${fields.join(', ')} WHERE id = $${idx} RETURNING ...`,
    values
  );
};
```

**Dynamic query building:**
- Only updates fields that are actually provided in the request.
- `$${idx++}` — Builds parameterized placeholders dynamically (`$1`, `$2`, `$3`, ...).
- This prevents partial updates from accidentally clearing existing data.
- `avatar_url = req.file?.path` — The uploaded avatar file URL from Supabase Storage (set by `upload` middleware).

---

## 8. 🔒 `changePassword()` — Security-Critical Operation

```js
const changePassword = async (req, res) => {
  // Verify current password first
  const result = await pool.query('SELECT * FROM users WHERE id = $1', [req.user.id]);
  const match = await bcrypt.compare(currentPassword, user.password);
  if (!match) return res.status(401).json({ ... 'Incorrect current password' });

  // Hash and store new password
  const hashedNewPassword = await bcrypt.hash(newPassword, 10);
  await pool.query('UPDATE users SET password = $1 WHERE id = $2', [hashedNewPassword, req.user.id]);
};
```

- **Must verify current password first** — prevents an attacker with a stolen session from changing the password.
- Same strong password policy as registration.
- The new password is hashed before storage.

---

## 9. 🔒 Security Analysis

| Concern | Implementation |
|---|---|
| Password storage | bcrypt hash (cost 10), never plaintext |
| Role escalation | Role hardcoded to 'student' on registration |
| Account enumeration | Same error message for wrong email vs wrong password |
| Password strength | Minimum 8 chars with letter + number |
| Session fixation | New JWT issued on login, not modified |
| CSRF | JWT Bearer tokens are immune to CSRF |

---

## 10. ✅ Final Summary

`authController.js` is a textbook implementation of secure authentication in Node.js. It follows OWASP best practices: no role from client, bcrypt hashing, generic error messages, and no password exposure in responses. The `generateToken` helper embeds role in the JWT — a performance optimization that eliminates one DB query per request on every subsequent API call.
