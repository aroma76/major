# 📄 `controllers/teacherController.js` — Complete Explanation

**File Path:** `backend/controllers/teacherController.js`
**Lines:** 148

---

## 1. File Purpose
Dashboard data aggregation for the faculty role — parallel-queried stats, recent announcements, and dual-role recent-activity endpoint (teacher + student views).

---

## 2. `getTeacherStats` — Parallel DB Queries

```js
const getTeacherStats = async (req, res) => {
  const channelRes = await pool.query(`SELECT id FROM channels WHERE teacher_id = $1`, [teacherId]);
  const channelIds = channelRes.rows.map(r => r.id);

  if (channelIds.length === 0) {
    return res.json({ success: true, stats: { totalStudents: 0, pendingReviews: 0, activeProjects: 0, totalSubjects: 0 } });
  }

  const [studentRes, pendingRes, projectRes] = await Promise.all([
    pool.query(`SELECT COUNT(DISTINCT user_id) AS total FROM enrollments WHERE channel_id = ANY($1::int[])`, [channelIds]),
    pool.query(`SELECT COUNT(*) AS total FROM assignment_submissions sub
                INNER JOIN assignments a ON sub.assignment_id = a.id
                WHERE a.channel_id = ANY($1::int[]) AND sub.marks IS NULL`, [channelIds]),
    pool.query(`SELECT COUNT(*) AS total FROM projects WHERE created_by = $1`, [teacherId]),
  ]);

  res.json({
    success: true,
    stats: {
      totalStudents: parseInt(studentRes.rows[0]?.total ?? 0),
      pendingReviews: parseInt(pendingRes.rows[0]?.total ?? 0),
      activeProjects: parseInt(projectRes.rows[0]?.total ?? 0),
      totalSubjects: channelIds.length,
    },
  });
};
```

### `ANY($1::int[])` — Array Parameter
```sql
WHERE channel_id = ANY($1::int[])
```
- `ANY(array)` — PostgreSQL operator equivalent to SQL `IN (list)` but accepts an array parameter
- `$1::int[]` — Casts the parameter to `integer[]` (PostgreSQL array type)
- This allows passing `channelIds = [1, 2, 3]` as a single parameter instead of building `IN ($1, $2, $3)` dynamically

### Parallel Execution
```js
const [studentRes, pendingRes, projectRes] = await Promise.all([query1, query2, query3]);
```
Three DB queries run simultaneously. Each takes ~5ms → total ~5ms (not 15ms sequential).

### `COUNT(DISTINCT user_id)`
```sql
SELECT COUNT(DISTINCT user_id) AS total FROM enrollments WHERE channel_id = ANY(...)
```
Counts unique students across ALL teacher's channels (not double-counting students enrolled in multiple channels of the same teacher).

### `sub.marks IS NULL`
```sql
WHERE a.channel_id = ANY(...) AND sub.marks IS NULL
```
Submissions where `marks` is NULL = not yet graded = "pending review". This is the faculty's pending workload.

---

## 3. `getStudentRecentActivity`
```js
const getStudentRecentActivity = async (req, res) => {
  const enrollRes = await pool.query(
    `SELECT e.channel_id, ch.subject_name FROM enrollments e
     INNER JOIN channels ch ON ch.id = e.channel_id WHERE e.user_id = $1`,
    [studentId]
  );
  const channelIds = enrollRes.rows.map(r => parseInt(r.channel_id));

  const annRes = await pool.query(
    `SELECT ann.*, u.name AS created_by_name, ch.subject_name FROM announcements ann
     INNER JOIN users u ON ann.user_id = u.id
     INNER JOIN channels ch ON ann.channel_id = ch.id
     WHERE ann.channel_id = ANY($1::int[])
     ORDER BY ann.created_at DESC LIMIT 5`,
    [channelIds]
  );
  res.json({ success: true, announcements: annRes.rows, recentMessages: [] });
};
```

**Used by both students AND teachers** (no role check) — the student home dashboard and the teacher's "student activity" view both call this. The `recentMessages: []` is a placeholder — real-time messages are handled by Socket.IO, not REST.

---

## 4. Final Summary
`teacherController.js` demonstrates parallel query execution with `Promise.all` and PostgreSQL's `ANY($1::int[])` pattern for array-based filtering. The `DISTINCT` count prevents double-counting enrolled students. The `marks IS NULL` pending review count gives faculty an instant workload overview.
