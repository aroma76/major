# 📄 `config/db.js` — Complete Explanation

**File Path:** `backend/config/db.js`
**Lines:** 21
**Role:** Creates and exports a PostgreSQL connection pool for the entire backend.

---

## 1. 📌 File Purpose

This file is the **database gateway**. It creates a single, shared PostgreSQL connection pool that every controller in the backend imports and reuses. It's responsible for:
- Connecting to the PostgreSQL database (hosted on Neon.tech via Supabase)
- Managing a pool of reusable connections
- Logging connection events
- Handling connection errors

> **Beginner Analogy:** A connection pool is like a taxi rank. Instead of calling a new taxi every time you need a ride (expensive), there are 5 taxis always waiting. When you need one, you take it, use it, then return it to the rank. The next person reuses the same taxi. This is much faster than summoning a fresh taxi every time.

---

## 2. 🔗 Imports

```js
const { Pool } = require('pg');
require('dotenv').config();
```

| Import | Purpose |
|---|---|
| `Pool` from `pg` | The PostgreSQL connection pool class from the `node-postgres` library |
| `dotenv.config()` | Loads `DATABASE_URL` from `.env` into `process.env` |

> `pg` is Node.js's most popular PostgreSQL driver. The `Pool` class manages multiple database connections efficiently.

---

## 3. 🏊 Pool Configuration — Line-by-Line

```js
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false },
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});
```

### Line 1: `connectionString: process.env.DATABASE_URL`
- `DATABASE_URL` is a full PostgreSQL connection string in the format:
  `postgresql://user:password@host:5432/database`
- This single string contains all connection info: hostname, port, username, password, database name.
- Example value: `postgresql://neondb_owner:abc123@ep-cool.neon.tech:5432/neondb?sslmode=require`

### Line 2: `ssl: ...`
```js
ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false }
```
- `?.includes('localhost')` — Uses optional chaining. If `DATABASE_URL` is undefined, this safely returns `undefined` instead of throwing.
- If the URL contains `localhost` → SSL is disabled (local development, no SSL needed).
- Otherwise → SSL is enabled but `rejectUnauthorized: false` means it accepts self-signed certificates (needed for Neon.tech's SSL configuration).

> **Security Note:** `rejectUnauthorized: false` is a pragmatic tradeoff. In enterprise production, you'd provide the CA certificate explicitly.

### Line 3: `max: 5`
- Maximum **5 simultaneous connections** in the pool.
- Neon.tech's free tier has a limit on concurrent connections. 5 is safely within that limit.
- If all 5 are busy, new queries wait in a queue.

### Line 4: `idleTimeoutMillis: 30000`
- Connections that haven't been used for **30 seconds** are closed.
- Prevents "zombie" connections that consume server resources.

### Line 5: `connectionTimeoutMillis: 5000`
- If no connection is available within **5 seconds**, the query throws an error.
- Prevents requests from hanging forever when the DB is overloaded.

---

## 4. 📡 Event Listeners

```js
pool.on('connect', () => {
  console.log('✅ Connected to PostgreSQL database');
});

pool.on('error', (err) => {
  console.error('❌ Database error:', err.message);
});
```

- `'connect'` fires when a new physical connection is opened to the database.
- `'error'` fires for unexpected errors on idle connections (e.g., DB server restart).

> **Note:** These are pool-level events, not query-level errors. Query errors are handled individually in each controller with `try/catch` (via `express-async-errors`).

---

## 5. 📤 Export

```js
module.exports = pool;
```

The pool is exported as a **singleton**. Every time another file does `require('../config/db')`, they get the **same pool instance** — not a new one. This is essential because Node.js caches `require()` results.

**Usage in controllers:**
```js
const pool = require('../config/db');

// Run a query
const result = await pool.query('SELECT * FROM users WHERE id = $1', [userId]);
```

---

## 6. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| SQL Injection | All queries use `$1, $2` parameterized placeholders — `pg` escapes them automatically |
| Credential exposure | `DATABASE_URL` is in `.env` (gitignored), not hardcoded |
| Connection exhaustion | `max: 5` caps connections; `connectionTimeoutMillis` prevents hangs |

---

## 7. ⚡ Performance Considerations

| Technique | Benefit |
|---|---|
| Connection pooling | Reuses connections instead of creating one per request (10-100x faster) |
| `max: 5` | Matches Neon free tier limits; avoids "too many clients" error |
| `idleTimeoutMillis` | Frees idle connections on Neon's serverless compute (which sleep when idle) |

---

## 8. 🐛 Possible Issues

1. **No retry logic** — If the database temporarily goes offline, no automatic reconnection is attempted. The server must be restarted.
2. **`rejectUnauthorized: false`** — Technically allows man-in-the-middle attacks on the DB connection. Acceptable for this use case but not ideal for banking systems.
3. **No query logging** — Failed queries are not logged centrally. Each controller handles its own error logging.

---

## 9. 🔄 How It Connects With Other Files

```
db.js
  └── imported by ALL controllers:
      ├── authController.js      → user login/register queries
      ├── messageController.js   → message INSERT/SELECT queries
      ├── assignmentController.js → assignment queries
      ├── channelController.js   → channel queries
      ├── notificationController.js → notification queries
      ├── projectController.js   → project + task queries
      ├── enrollmentController.js → enrollment queries
      ├── notesController.js     → notes queries
      ├── announcementController.js → announcement queries
      ├── academicEventController.js → event queries
      ├── submissionController.js → submission queries
      ├── teacherController.js   → stats queries
      └── socket/socketHandler.js → message INSERT from WebSocket
```

---

## 10. ✅ Final Summary

`db.js` is a **thin, critical infrastructure file**. It has just one job: create and export a PostgreSQL connection pool. Despite being only 21 lines, it's one of the most important files in the backend — every single database operation in the entire system depends on it. It's designed to be simple, safe, and efficient within the constraints of Neon's free PostgreSQL tier.
