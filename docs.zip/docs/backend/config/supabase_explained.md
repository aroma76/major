# 📄 `config/supabase.js` — Complete Explanation

**File Path:** `backend/config/supabase.js`
**Lines:** 29
**Role:** Initializes the Supabase client for file storage operations and ensures the storage bucket exists.

---

## 1. 📌 File Purpose

This file creates a **Supabase client** used exclusively for **file storage** (not for database queries — that's handled by `db.js` via PostgreSQL directly). It:
- Creates a Supabase JavaScript client with the service role key (full admin access)
- Exports the `BUCKET` name constant
- Exports `ensureBucket()` — a function called at startup to ensure the storage bucket exists

> **Beginner Analogy:** Think of Supabase Storage like Google Drive for your app. This file is the code that "logs in" to Google Drive using admin credentials, and then checks that the "Files" folder exists before the app starts serving users.

---

## 2. 🔗 Imports

```js
const { createClient } = require('@supabase/supabase-js');
```

`createClient` from the official `@supabase/supabase-js` SDK. This is the same library used in Flutter frontends but here it runs on Node.js server-side.

---

## 3. 🔑 Supabase Client Creation — Line-by-Line

```js
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY,
);
```

| Parameter | Value | Why |
|---|---|---|
| `SUPABASE_URL` | `https://your-project.supabase.co` | The unique base URL of your Supabase project |
| `SUPABASE_SERVICE_KEY` | A long JWT string starting with `eyJ...` | The **service role key** — bypasses all Row Level Security (RLS) policies |

### 🔐 Why Service Role Key?

There are two types of Supabase keys:
1. **Anon Key** — limited public access, RLS applies
2. **Service Role Key** — full admin access, bypasses RLS

The backend uses the **service role key** because:
- It needs to upload files to storage on behalf of any user
- It runs in a trusted server environment (not exposed to browsers)
- The backend enforces its own authentication (JWT protect middleware)

> ⚠️ **Critical Security Note:** The service role key must NEVER be exposed to frontend code or committed to version control. It gives unrestricted access to the entire database and storage.

---

## 4. 🪣 Bucket Constant

```js
const BUCKET = 'files';
```

A simple string constant naming the Supabase Storage bucket. Centralizing it here means if the bucket name ever changes, it only needs to change in one place.

Used in:
- `upload.js` middleware when uploading files
- `supabase.js` itself in `ensureBucket()`

---

## 5. ✅ `ensureBucket()` Function — Line-by-Line

```js
async function ensureBucket() {
  const { error } = await supabase.storage.createBucket(BUCKET, {
    public: true,
    allowedMimeTypes: null,
    fileSizeLimit: 52428800, // 50 MB
  });
  if (error && !error.message.includes('already exists')) {
    console.warn('[Supabase] Could not create bucket:', error.message);
  } else {
    console.log(`[Supabase] Storage bucket "${BUCKET}" ready.`);
  }
}
```

### Line: `await supabase.storage.createBucket(BUCKET, { ... })`
- Calls Supabase's Storage API to create a new bucket named `'files'`.
- `public: true` — Files are accessible via public URL without authentication. This is needed so students can view assignment files and notes.
- `allowedMimeTypes: null` — No MIME type restriction at the bucket level. Restrictions are applied in `upload.js` middleware instead.
- `fileSizeLimit: 52428800` — 50 MB limit per file (`50 * 1024 * 1024 = 52,428,800` bytes). Matches the multer limit in `upload.js`.

### Line: `if (error && !error.message.includes('already exists'))`
- `createBucket` returns an error if the bucket already exists (which is normal after the first deployment).
- This line **ignores** "already exists" errors — they're not real problems.
- Only logs a warning for genuine errors (e.g., Supabase is unreachable, invalid credentials).

### Why is this called at startup?
Called in `server.js` → `server.listen(PORT, async () => { await ensureBucket(); })`. This guarantees the bucket exists before the first file upload request arrives, without failing silently.

---

## 6. 📤 Exports

```js
module.exports = { supabase, BUCKET, ensureBucket };
```

Three exports:
| Export | Used By |
|---|---|
| `supabase` | `middleware/upload.js` — for uploading files and getting public URLs |
| `BUCKET` | `middleware/upload.js` — knows which bucket to upload to |
| `ensureBucket` | `server.js` — called once at startup |

---

## 7. 🏗️ Supabase Architecture in This Project

```
Supabase Project
├── PostgreSQL Database  ← NOT used via this file (db.js uses pg directly)
│   └── All tables (users, messages, assignments, etc.)
│
└── Storage
    └── Bucket: "files"  ← THIS file manages this
        └── Folder: adtu-collab/
            ├── 1716000000000-assignment1.pdf
            ├── 1716000001000-lecture_notes.png
            └── 1716000002000-submission.zip
```

The backend uses Supabase in a **hybrid mode**:
- Database queries → direct PostgreSQL via `pg` Pool (faster, more control)
- File storage → Supabase Storage SDK (S3-compatible cloud storage)

---

## 8. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Service key exposure | Stored in `.env`, never committed to git |
| Public bucket | Files are public URLs but have unpredictable hashed paths |
| Malicious files | MIME type filtering in `upload.js`, not bucket-level |
| File size abuse | 50MB limit enforced at both multer and Supabase levels |

---

## 9. ⚡ Performance Notes

- `createClient` creates a single SDK instance. It's efficient — doesn't open persistent connections (Supabase storage uses HTTP REST).
- The `supabase` singleton is shared across all requests via `upload.js`.

---

## 10. 🔄 How It Connects With Other Files

```
supabase.js
  ├── exports supabase → used by upload.js
  │     ├── supabase.storage.from(BUCKET).upload(...)
  │     └── supabase.storage.from(BUCKET).getPublicUrl(...)
  └── exports ensureBucket → called by server.js on startup
```

---

## 11. ✅ Final Summary

`supabase.js` is the **file storage gateway** of the backend. It's intentionally minimal — just 29 lines — but it unlocks the entire file upload pipeline. Without it, no files (assignments, notes, lecture materials, profile avatars) can be stored. The service role key gives it unrestricted access to Supabase, which is appropriate for a trusted server-side environment. The `ensureBucket()` startup check prevents "bucket not found" errors in production.
