# 📄 `core/theme/app_colors.dart` — Complete Explanation

**File Path:** `frontend/lib/core/theme/app_colors.dart`
**Lines:** 163
**Role:** Central design system — color palette, theme state management, and notification state for the entire Flutter application.

---

## 1. 📌 File Purpose

This file is the **design system hub** of the entire frontend. Despite the name "app_colors", it contains much more:
1. **`AppColors`** — All color constants (dark AND light mode)
2. **`ThemeModeNotifier`** — Riverpod state for dark/light mode toggle
3. **`NotificationNotifier`** — In-app notification list state
4. **`NotificationsEnabledNotifier`** — Push notification preference toggle
5. **`EmailSummaryEnabledNotifier`** — Email digest preference toggle

> **Beginner Note:** Mixing color constants and state management in one file is a code organization smell. Ideally, colors should be in `app_colors.dart` and notifiers should be in `app_theme_provider.dart` or `notification_provider.dart`. But for a small project, this works fine.

---

## 2. 📤 Top-Level Provider Declarations

```dart
final themeModeProvider =
    NotifierProvider<ThemeModeNotifier, ThemeMode>(() => ThemeModeNotifier());

final notificationProvider =
    NotifierProvider<NotificationNotifier, List<AppNotification>>(
        () => NotificationNotifier());

final isNotificationsEnabledProvider =
    NotifierProvider<NotificationsEnabledNotifier, bool>(
        () => NotificationsEnabledNotifier());

final isEmailSummaryEnabledProvider =
    NotifierProvider<EmailSummaryEnabledNotifier, bool>(
        () => EmailSummaryEnabledNotifier());
```

These are declared at **file-top level** (global variables in Dart are singletons within the app). Riverpod providers declared this way are accessible from anywhere via `ref.watch(themeModeProvider)`.

---

## 3. 🎨 `ThemeModeNotifier` — Dark/Light Toggle

```dart
class ThemeModeNotifier extends Notifier<ThemeMode> {
  @override
  ThemeMode build() => ThemeMode.dark;  // Default: dark mode
  
  void toggle() =>
      state = state == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
  
  void setTheme(ThemeMode mode) => state = mode;
}
```

**`ThemeMode`** is a Flutter enum: `ThemeMode.dark`, `ThemeMode.light`, `ThemeMode.system`.

The notifier defaults to **dark mode** (`build() => ThemeMode.dark`). This matches the app's GitHub-inspired dark design aesthetic.

**Usage in `main.dart`:**
```dart
final themeMode = ref.watch(themeModeProvider);
MaterialApp(
  theme: lightTheme,
  darkTheme: darkTheme,
  themeMode: themeMode,  // ← driven by Riverpod
)
```

**`AppColors.getBackgroundColor(context)` connection:**
When `themeMode` changes → Flutter updates `Theme.of(context).brightness` → all `AppColors.getXxx(context)` methods return the new theme's color → entire app repaints with new colors.

---

## 4. 🔔 `AppNotification` — Data Class

```dart
class AppNotification {
  final String id;
  final String title;
  final String message;
  final DateTime timestamp;
  bool isRead;  // ← mutable! (not final)

  AppNotification({
    required this.id,
    required this.title,
    required this.message,
    required this.timestamp,
    this.isRead = false,
  });
}
```

**`isRead` is mutable (`bool`, not `final bool`):**
- This is technically a design inconsistency — most Dart data classes are fully immutable.
- The `markAsRead()` method in `NotificationNotifier` creates a **new** `AppNotification` with `isRead: true` rather than modifying the existing one. So the mutable field is actually not mutated in practice.
- However, the lack of `final` is still a code smell.

---

## 5. 🔔 `NotificationNotifier` — In-App Notifications State

```dart
class NotificationNotifier extends Notifier<List<AppNotification>> {
  @override
  List<AppNotification> build() => [
    AppNotification(
      id: '1', title: 'New Assignment',
      message: 'Mobile App Assignment 3 has been posted.',
      timestamp: DateTime.now().subtract(const Duration(hours: 2)),
    ),
    // ... 2 more hardcoded notifications
  ];
```

**Hardcoded initial notifications:**
These are demo data. Real notifications come from:
1. `notificationsApiProvider` (REST API fetch)
2. Socket `notification:new` events → `notificationProvider.add()`

The two systems currently run in parallel without merging.

### `markAsRead()` — Immutable Update

```dart
void markAsRead(String id) {
  state = [
    for (final n in state)
      if (n.id == id)
        AppNotification(
            id: n.id, title: n.title, message: n.message,
            timestamp: n.timestamp, isRead: true)
      else
        n
  ];
}
```

- Collection `for` + `if` — creates a new list.
- For the matching notification: creates a **new** `AppNotification` with `isRead: true`.
- For all others: keeps the original object.
- Riverpod detects the new list reference → triggers rebuild of notification badge.

---

## 6. 🎨 `AppColors` — Complete Color System

### Dark Mode Colors

```dart
static const Color background       = Color(0xFF0D1117);  // GitHub dark background
static const Color surface          = Color(0xFF161B22);  // Card/panel background
static const Color cardBackground   = Color(0xFF21262D);  // Elevated card
static const Color accent           = Color(0xFF58A6FF);  // GitHub blue
static const Color secondaryBackground = Color(0xFF010409); // Near-black sidebar
static const Color textBody         = Color(0xFF8B949E);  // Secondary text (grey)
static const Color textHeading      = Color(0xFFC9D1D9);  // Primary text (light grey)
```

**Color Philosophy:**
The dark palette is inspired by **GitHub's dark mode** (`0D1117` = exactly GitHub's dark background). This creates a familiar academic/developer aesthetic.

```dart
static const Color priorityHigh   = Color(0xFFFF4D4D);  // Red — urgent
static const Color priorityMedium = Color(0xFFFFD93D);  // Yellow — caution
static const Color priorityLow    = Color(0xFF4CAF50);  // Green — low urgency

static const Color todoColor       = Color(0xFF7D8590);  // Grey — backlog
static const Color inProgressColor = Color(0xFFD29922);  // Amber — active
static const Color doneColor       = Color(0xFF238636);  // Green — completed
```

These colors match GitHub's issue label colors for `priority:high`, `priority:medium`, `priority:low` — another intentional design reference.

### Accent Gradient

```dart
static const LinearGradient accentGradient = LinearGradient(
  colors: [Color(0xFF58A6FF), Color(0xFF1F6FEB)],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);
```

Used on buttons, cards, and highlighted elements. The gradient goes from a lighter GitHub blue (`#58A6FF`) to a deeper GitHub link blue (`#1F6FEB`).

### Light Mode Colors

```dart
static const Color lightBackground     = Color(0xFFF6F8FA);  // GitHub light background
static const Color lightSurface        = Colors.white;
static const Color lightCardBackground = Colors.white;
static const Color lightTextBody       = Color(0xFF57606A);  // GitHub light secondary text
static const Color lightTextHeading    = Color(0xFF24292F);  // GitHub light primary text
static const Color lightSecondaryBackground = Color(0xFFF3F4F6);
```

Again, these match GitHub's light mode colors almost exactly.

---

## 7. 🔄 Context-Aware Color Methods

```dart
static Color getBackgroundColor(BuildContext context) {
  return Theme.of(context).brightness == Brightness.dark
      ? background
      : lightBackground;
}
```

All 6 `getXxx(context)` methods follow this same pattern:
- Check `Theme.of(context).brightness`
- Return dark or light color accordingly

**Why methods instead of just using `Theme.of(context).colors.surface`?**
Flutter's `ThemeData.colorScheme` has limited color slots. The design system here needs more granularity (`background`, `surface`, `cardBackground`, `secondaryBackground` are all different). The custom `AppColors` class provides this additional specificity.

**`getBorderColor(context)` — Inline color:**
```dart
static Color getBorderColor(BuildContext context) {
  return Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFF30363D)   // GitHub dark border
      : const Color(0xFFD0D7DE);  // GitHub light border
}
```
These colors aren't defined as named constants — they're only used for borders. Named constants would be overkill here.

---

## 8. ⚡ Performance

- All color constants are `const` — no heap allocation, zero runtime cost.
- `LinearGradient` as `const` — created once at compile time.
- `getXxx(context)` methods — `Theme.of(context)` is O(1) (looks up inherited widget in tree).
- Widgets using `AppColors.getXxx(context)` rebuild when theme changes (because `ThemeModeNotifier` changes `MaterialApp.themeMode`, which propagates down the widget tree).

---

## 9. 🐛 Issues & Improvements

1. **Mixed responsibilities** — Colors, theme state, notification state, and settings state in one file. Should be split.
2. **Hardcoded demo notifications** — The initial 3 notifications are dummy data.
3. **No theme persistence** — The dark/light preference is in-memory. App restarts always show dark mode.
4. **Two notification systems** — `notificationProvider` (this file) and `notificationsApiProvider` (api_providers.dart) are separate and don't sync.
5. **`isRead` not `final`** — Minor inconsistency in `AppNotification`.

---

## 10. 🔄 Data Flow Diagram

```
User taps theme toggle in SettingsViewWidget
    │
    ▼
ref.read(themeModeProvider.notifier).toggle()
    │
    ▼
ThemeModeNotifier.state changes: dark → light
    │
    ▼
MaterialApp.themeMode updates (watched in main.dart)
    │
    ▼
Flutter rebuilds entire app with new ThemeData
    │
    ▼
AppColors.getBackgroundColor(context) now returns lightBackground
    │
    ▼
All widgets using AppColors.getXxx() show light colors
```

---

## 11. ✅ Final Summary

`app_colors.dart` is the **design system foundation** of the Flutter app. Its GitHub-inspired dark palette creates a professional academic aesthetic. The context-aware `getXxx()` methods elegantly support both dark and light mode without widget-level `if` statements. The Riverpod notifiers for theme and notification state are well-implemented, though the file's mixed concerns (colors + multiple state managers) is worth refactoring as the codebase grows.
