# 📄 `widgets/messages_view_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/messages_view_widget.dart`
**Lines:** 2038 (largest file in the project)
**Role:** Full real-time chat widget — channel sidebar, message history with infinite scroll (load-more), optimistic UI for text messages, multi-file upload queue, reply-to threading, typing indicators, drag-and-drop file upload (web), and file save-to-notes/question-papers.

---

## 1. File Purpose

`MessagesViewWidget` is the most complex widget in the project. It implements a Discord/Slack-style channel chat with:
- Two-panel layout on desktop (channel list + chat area), single-panel on mobile
- Real-time message delivery via Socket.IO
- Optimistic UI (sender sees messages instantly before server confirmation)
- Multi-file upload with MIME type detection
- HTML5 drag-and-drop (web only)
- Reply threading (parent_id)
- Typing indicators
- Infinite scroll (load-older-messages on scroll-to-top)
- File saving to `savedFilesProvider` (Notes or Question Papers)

---

## 2. State Variables

```dart
List<PlatformFile> _pendingFiles = [];  // Multi-file queue (WhatsApp-style)
bool _isSending = false;                // Upload in progress
String? _typingUser;                    // Name of user currently typing
ApiMessageModel? _replyingTo;           // Message being replied to
bool _isDragging = false;               // File drag-over state (web)
```

---

## 3. Socket Listeners — Real-Time Message Delivery

```dart
void _initSocketListeners() {
  final socket = SocketService();
  socket.onNewMessage((data) {
    final chanId = (data['channel_id'] as num?)?.toInt();
    final myId = AuthService().currentUser?['id']?.toString();
    final senderId = (data['sender_id'] as num?)?.toInt().toString();
    if (senderId != null && senderId == myId) return; // Skip own messages

    final msg = ApiMessageModel.fromJson(data);
    ref.read(messagesNotifierProvider(chanId).notifier).append(msg);
    if (chanId == selected) _scrollToBottom();
  });

  socket.onTypingStart((name) => setState(() => _typingUser = name));
  socket.onTypingStop(() => setState(() => _typingUser = null));
}
```

**Own-message deduplication:** When the user sends a text message, an optimistic copy is immediately appended. The socket event for the same message (echoed by the server to all room members including the sender) must be ignored — hence the `senderId == myId` check.

**File uploads do NOT use this skip** — file messages go through the REST API (`_uploadFiles`), and the server's socket echo is used to show the message to other users.

---

## 4. Optimistic UI for Text Messages

```dart
final tempMsg = ApiMessageModel(
  id: DateTime.now().millisecondsSinceEpoch,  // Temp ID
  channelId: channel.id,
  senderId: ...,
  senderName: ...,
  content: text,
  createdAt: DateTime.now(),
  parentId: parentId,
);
ref.read(messagesNotifierProvider(channel.id).notifier).append(tempMsg);

SocketService().sendMessage(channelId: channel.id, content: text, parentId: parentId);
_inputCtrl.clear();
_scrollToBottom();
```

The message appears **instantly** from the sender's perspective. The socket emission happens in parallel. If the socket fails, the optimistic message stays visible (a known limitation — no rollback mechanism).

---

## 5. `_WebDropZone` — HTML5 Drag-and-Drop

```dart
_onDragEnter = (html.Event e) {
  e.preventDefault();
  _dragCounter++;
  if (_dragCounter == 1) widget.onDragStateChanged(true);
};

_onDragOver = (html.Event e) {
  e.preventDefault(); // CRITICAL: without this, browser won't fire drop
};

_onDrop = (html.Event e) async {
  e.preventDefault();
  _dragCounter = 0;
  // Read dropped files via html.FileReader as ArrayBuffer → Uint8List
  final reader = html.FileReader();
  reader.readAsArrayBuffer(jsFileTyped);
  await reader.onLoadEnd.first;
  final bytes = (reader.result as ByteBuffer).asUint8List();
  result.add(PlatformFile(name: jsFileTyped.name, bytes: bytes));
};

// CRITICAL: use capture phase (true) to intercept events before Flutter's CanvasKit glass-pane
html.window.addEventListener('dragenter', _onDragEnter, true);
html.window.addEventListener('dragover', _onDragOver, true);
html.window.addEventListener('dragleave', _onDragLeave, true);
html.window.addEventListener('drop', _onDrop, true);
```

**`_dragCounter`** — Tracks nested drag events. Without a counter, dragging over a child element fires `dragleave` then `dragenter` — flickering the drag overlay. The counter absorbs these false negatives.

**Capture phase (`true`)** — Flutter Web renders to a `<canvas>` element via CanvasKit. Native DOM drag events get absorbed before reaching Flutter's widget tree unless captured at the window level with the `useCapture` flag.

**`html.FileReader.readAsArrayBuffer`** — Reads file bytes as `ByteBuffer`. Needed because `PlatformFile` (from `file_picker`) expects `Uint8List` bytes — the standard file picker format.

---

## 6. File Upload Pipeline

```dart
Future<void> _uploadFiles(int channelId, String caption, int? parentId) async {
  for (final file in files) {
    final bytes = file.bytes;
    final mime = _mimeFromExt(ext);
    final parts = mime.split('/');
    final formData = FormData.fromMap({
      'content': caption.isNotEmpty ? caption : file.name,
      'file': MultipartFile.fromBytes(
        bytes,
        filename: file.name,
        contentType: MediaType(parts[0], parts.length > 1 ? parts[1] : 'octet-stream'),
      ),
      if (parentId != null) 'parent_id': parentId,
    });
    final response = await ApiService().sendMessage(channelId, formData);
    final saved = response.data['message'];
    ref.read(messagesNotifierProvider(channelId).notifier).append(ApiMessageModel.fromJson(saved));
    caption = ''; // Only first file gets the caption
  }
}
```

Files are uploaded **sequentially** (not concurrently). The caption text applies only to the first file — subsequent files get the filename as their caption.

`MediaType` from `http_parser` sets the correct `Content-Type` multipart header — required by the backend to identify file type.

---

## 7. MIME Type Lookup Table

```dart
static String _mimeFromExt(String ext) {
  const map = {
    'jpg': 'image/jpeg', 'pdf': 'application/pdf',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'zip': 'application/zip', ...
  };
  return map[ext] ?? 'application/octet-stream'; // Default binary
}
```

`'application/octet-stream'` is the RFC standard for "unknown binary" — the server's Multer middleware accepts any type but uses this as a fallback.

---

## 8. Typing Indicator Emission

```dart
void _emitTyping() {
  final name = AuthService().currentUser?['name'] ?? 'Someone';
  SocketService().emitTypingStart(channel.id, name);
  Future.delayed(const Duration(seconds: 2), () => SocketService().emitTypingStop(channel.id));
}
```

Each keystroke calls `_emitTyping()`. The "stop" event fires 2 seconds after the last emission. This is a simplified approach — production apps track the last-typed timestamp and only emit stop after actual idle.

---

## 9. Infinite Scroll — Load-Older-Messages

```dart
NotificationListener<ScrollNotification>(
  onNotification: (scrollInfo) {
    if (scrollInfo.metrics.pixels <= 200) {
      ref.read(messagesNotifierProvider(channel.id).notifier).loadMore();
    }
    return false;
  },
  child: ListView.builder(controller: scrollCtrl, ...),
)
```

When the user scrolls within 200px of the top (oldest visible message), `loadMore()` fetches the next page of older messages. `return false` means the notification continues bubbling (doesn't stop parent scroll handlers).

---

## 10. `selectedChannelProvider` — Channel Selection State

```dart
void _selectChannel(ChannelModel ch) {
  final prev = ref.read(selectedChannelProvider);
  if (prev != null) SocketService().leaveChannel(prev.id);  // Leave old Socket.IO room
  ref.read(selectedChannelProvider.notifier).select(ch);   // Update selected
  setState(() => _replyingTo = null);                       // Clear reply state
  SocketService().joinChannel(ch.id);                       // Join new Socket.IO room
}
```

When selecting a new channel:
1. Leave the previous Socket.IO room (stop receiving its messages)
2. Update the `selectedChannelProvider`
3. Clear reply state (can't reply to a message in a different channel)
4. Join the new Socket.IO room

---

## 11. Responsive Layout

```dart
if (isMobile) {
  if (selectedChannel != null) return _buildDropTarget(selectedChannel, _ChatArea(...));
  return Column([channel list]);  // Full-screen channel list
}

// Desktop: side-by-side
return LayoutBuilder(builder: (ctx, constraints) {
  final panelWidth = (constraints.maxWidth * 0.28).clamp(240.0, 340.0);
  return Row([
    Container(width: panelWidth, child: [channel list]),
    Expanded(child: selectedChannel == null ? _EmptyState() : _ChatArea(...)),
  ]);
});
```

Mobile: Single panel that shows either channel list OR chat (back button returns to list).
Desktop: Fixed-width channel sidebar (28% of width, clamped 240–340px) + chat area.

---

## 12. File-Save-to-Notes Flow

Within `_MessageBubble` (the message card), files show a save button:

```dart
ref.read(savedFilesProvider.notifier).save(
  SavedFile(
    id: '${msg.id}_${file.url}',
    fileName: file.name,
    fileUrl: file.url,
    sharedBy: msg.senderName,
    savedAt: DateTime.now(),
    subjectName: channel.subjectName,
    type: SavedFileType.note,  // or .questionPaper
  ),
);
```

The file is saved to `savedFilesProvider` (in-memory Riverpod state). It then appears in the Notes/Question Papers views.

---

## 13. Security Considerations

- **Own-message deduplication** — Prevents seeing duplicate messages
- **Socket.IO room isolation** — Users only receive messages from joined channels
- **No message editing/deletion** — Simpler but limits misuse
- **File type validation** — `_mimeFromExt` provides correct MIME; server uses Multer with storage type detection

---

## 14. Known Issues / Limitations

1. **No optimistic rollback** — If socket fails, the optimistic message stays stuck
2. **Typing indicator is naive** — Fires on every keystroke, 2s fixed stop delay
3. **Sequential file uploads** — Multiple files upload one at a time (slow for many files)
4. **`dart:html` web-only** — The `import 'dart:html' as html` makes this file non-compilable for non-web targets

---

## 15. Final Summary

`MessagesViewWidget` is the architectural centerpiece of the frontend — integrating Socket.IO, REST API, Riverpod family providers, optimistic UI, HTML5 drag-and-drop, multi-file upload, and infinite scroll. The `_WebDropZone` with counter-based drag tracking and capture-phase event listeners is the most technically sophisticated implementation in the entire codebase.
