# 📄 `widgets/today_overview_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/today_overview_widget.dart`
**Lines:** 874
**Role:** Student home dashboard — greeting banner, quick actions grid, deadline cards, subject progress rows (with animated progress bars), task board, and recent announcements.

---

## 1. File Purpose

`TodayOverviewWidget` is the student home screen. It aggregates data from multiple providers and presents a rich, animated overview of the student's academic day.

---

## 2. Entrance Animation

```dart
class _TodayOverviewWidgetState extends ConsumerState<TodayOverviewWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }
```

**Dual animation:** The entire screen fades in (opacity 0→1) AND slides up (6% of height → 0). The combination creates a smooth "reveal from below" effect.

**`Curves.easeOutCubic`** — Starts fast, decelerates at the end (natural motion).

Applied via:
```dart
return FadeTransition(opacity: _fadeAnim,
  child: SlideTransition(position: _slideAnim,
    child: SingleChildScrollView(...)));
```

---

## 3. Greeting Logic

```dart
String _getGreeting() {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Good Morning';
  if (hour < 17) return 'Good Afternoon';
  return 'Good Evening';
}
```

Server-independent: uses device time. Intentional — a greeting is a UX feature, not a business-critical operation.

---

## 4. Task Statistics Computation

```dart
final tasks = ref.watch(taskProvider);
final pendingCount = tasks.where((t) => t.status != TaskStatus.done).length;
final urgentCount = tasks
    .where((t) => t.priority == TaskPriority.high && t.status != TaskStatus.done).length;

final upcomingTasks = tasks
    .where((t) =>
        t.dueDate.isAfter(now) &&
        t.dueDate.isBefore(now.add(const Duration(days: 7))) &&
        t.status != TaskStatus.done)
    .toList()
  ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
```

All computed inline during `build()`. Since `taskProvider` is a synchronous `NotifierProvider`, no loading state needed.

**`..sort(...)`** — Dart's cascade operator: calls `sort()` on the list AND returns the same list. Equivalent to `list.sort(); return list;` but in one expression.

---

## 5. Subject Progress Calculation from API Data

```dart
channelsAsync.whenOrNull(
  data: (channels) => Consumer(
    builder: (context, ref, _) {
      final assignmentsAsync = ref.watch(allAssignmentsProvider);
      return assignmentsAsync.when(
        loading: () => ...channels.map((ch) => _SubjectProgressRow(name: ch.subjectName, progress: 0.0, ...)),
        error: (_, __) => ...channels.map((ch) => _SubjectProgressRow(...progress: 0.0...)),
        data: (allAssignments) => ...channels.map((ch) {
          final chAssignments = allAssignments.where((a) => a.channelId == ch.id).toList();
          final total = chAssignments.length;
          final submitted = chAssignments.where((a) => a.isSubmitted).length;
          final progress = total > 0 ? submitted / total : 0.0;
          return _SubjectProgressRow(name: ch.subjectName, progress: progress, ...);
        }),
      );
    },
  ),
) ?? const SizedBox.shrink()
```

**Nested `whenOrNull` + `Consumer` pattern:**
- `channelsAsync.whenOrNull(data: ...)` — Only renders if channels are loaded
- Inner `Consumer` re-reads `allAssignmentsProvider` — keeps the subject progress section separate from the channel list loading state
- Progress formula: `submitted / total` (0.0 to 1.0 for `LinearProgressIndicator`)

**Loading state shows 0% progress** — Channels display immediately with empty bars while assignments load.

---

## 6. `_SubjectProgressRow` — Animated Progress Bar

```dart
class _SubjectProgressRowState extends State<_SubjectProgressRow>
    with SingleTickerProviderStateMixin {
  late AnimationController _barCtrl;
  late Animation<double> _barAnim;

  @override
  void initState() {
    _barCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _barAnim = Tween<double>(begin: 0, end: widget.progress)
        .animate(CurvedAnimation(parent: _barCtrl, curve: Curves.easeOutCubic));
    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) _barCtrl.forward();
    });
  }
```

**Staggered start:** `Future.delayed(150ms)` — Each progress bar starts animating 150ms after the widget builds. Combined with the overall screen entrance animation (700ms), the progress bars "reveal" after the screen has appeared.

**`if (mounted) _barCtrl.forward()`** — Checks if the widget is still in the tree before starting the animation (safe async pattern).

---

## 7. `_QuickActionCard` — Hover Effect

```dart
class _QuickActionCardState extends State<_QuickActionCard> {
  bool _hovered = false;

  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: GestureDetector(
        child: AnimatedContainer(
          color: _hovered ? widget.action.color.withValues(alpha: 0.15) : AppColors.getSurfaceColor(context),
          border: Border.all(
            color: _hovered ? widget.action.color.withValues(alpha: 0.5) : AppColors.getBorderColor(context),
          ),
          boxShadow: _hovered ? [BoxShadow(color: widget.action.color.withValues(alpha: 0.2), ...)] : [],
        ),
      ),
    );
  }
}
```

**`MouseRegion`** — Detects mouse hover events. On mobile (no mouse), this is a no-op.

On hover:
1. Background changes to 15% tinted with the action's color
2. Border changes to 50% tinted color
3. Shadow appears with 20% tinted color

`AnimatedContainer` smoothly interpolates between the two states over 200ms.

---

## 8. Final Summary

`TodayOverviewWidget` is the most data-rich widget in the app, combining:
1. Entrance animations (fade + slide)
2. Real-time task statistics (local state)
3. API-driven subject progress (nested async providers)
4. Staggered progress bar animations
5. Quick action grid with hover effects
6. Embedded Kanban board and announcements panel

The nested `whenOrNull` + inner `Consumer` pattern for subject progress is sophisticated — it handles the two-step async (channels then assignments) gracefully with a zero-progress loading state.
