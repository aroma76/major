# Word-by-Word Deep Dive: `task_and_project_dialogs_explained.md`

> Covers **two dialogs** used in the Projects / Kanban board feature:
> 1. `task_details_dialog.dart` — full-screen dialog for viewing/moving/deleting a local task
> 2. `create_project_dialog.dart` — form dialog for creating a new API-backed project

---

# Part 1: `task_details_dialog.dart`

> The full-screen dialog that appears when you tap a task card. It shows all task metadata, allows moving the task between Kanban columns (without drag-and-drop), and allows deleting. It uses several small private widget classes as a "design system in miniature."

---

## Before Reading — `Dialog` vs `showDialog`

**`showDialog(context, builder)`** — a Flutter function that creates and shows a dialog OVERLAY. The builder returns a widget.

**`Dialog`** widget — the actual dialog container. Controls:
- `backgroundColor` — the dialog's own background
- `shape` — border radius
- `child` — the content

**`ConstrainedBox`** — adds size constraints to the dialog content. Without it, `Dialog` would try to be as large as its content (which can overflow the screen).

---

## Dialog Structure

```dart
return Dialog(
  backgroundColor: isDark
      ? AppColors.secondaryBackground
      : AppColors.lightSecondaryBackground,
  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
  child: ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 520, maxHeight: 680),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Header (gradient, title, badges)
        // Flexible scrollable body (description, notes, questions)
        // Status move buttons ("Move to" row)
        // Action buttons (Delete + Close)
      ],
    ),
  ),
);
```

**`maxWidth: 520`** — dialog never exceeds 520px wide. On mobile it takes full width (capped by screen).

**`maxHeight: 680`** — dialog never exceeds 680px tall. If content overflows, the `Flexible` scrollable body scrolls instead of the dialog growing further.

**`Column(mainAxisSize: MainAxisSize.min)`** — the column only takes the height it needs (not full screen height). Combined with `maxHeight: 680`, it's tightly constrained.

---

## Header Section

```dart
Container(
  decoration: BoxDecoration(
    gradient: LinearGradient(
      colors: [
        AppColors.accent.withValues(alpha: 0.12),
        AppColors.accent.withValues(alpha: 0.03),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
    borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
    border: Border(
      bottom: BorderSide(color: AppColors.getBorderColor(context)),
    ),
  ),
```

**`LinearGradient` with two `alpha` values** — the gradient fades from 12% accent at top-left to 3% accent at bottom-right. Creates a subtle, elegant "glow" header without being harsh.

**`BorderRadius.vertical(top: Radius.circular(24))`** — rounds only the TOP two corners. The bottom edge connects flush to the dialog body. `BorderRadius.vertical` is a shorthand for `BorderRadius.only(topLeft: ..., topRight: ...)`.

**`Border(bottom: BorderSide(...))`** — only draws a BOTTOM border (the separator between header and body). Dart's named parameter `bottom:` allows single-side borders.

### Pill Badges in Header

```dart
_PillBadge(label: task.subject, color: AppColors.accent),
_PillBadge(label: task.priority.name.toUpperCase(), color: priorityColor),
```

Two badges side-by-side: subject name (always blue) and priority level (colored by priority).

**`task.priority.name.toUpperCase()`** — `TaskPriority.high.name` = `'high'` → `.toUpperCase()` = `'HIGH'`.

---

## Flexible Scrollable Body

```dart
Flexible(
  child: SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
    child: Column(
      children: [
        // Meta cards row (Deadline + Status)
        // Description section (if not empty)
        // Notes section (if not empty)
        // Questions section (if not empty)
      ],
    ),
  ),
),
```

**`Flexible`** — allows the body to expand to fill available space but NOT push out of the `ConstrainedBox(maxHeight: 680)`.

**`SingleChildScrollView`** — enables scrolling when content exceeds the flexible height.

### Conditional Sections

```dart
if (task.description.isNotEmpty) ...[
  _DetailSection(icon: FeatherIcons.alignLeft, title: 'Description', content: task.description, accentColor: AppColors.accent),
  const SizedBox(height: 16),
],

if (task.notes != null && task.notes!.isNotEmpty) ...[
  _DetailSection(icon: FeatherIcons.edit3, title: 'Notes', content: task.notes!, accentColor: const Color(0xFF3FB950)),
  const SizedBox(height: 16),
],
```

**`if (condition) ...[widget1, widget2]`** — collection if with a spread. If `description` is empty, neither the `_DetailSection` nor the `SizedBox` appear. Avoids ghost whitespace for empty fields.

**`task.notes!`** — non-null assertion. Already checked `task.notes != null`, so `!` is safe.

---

## "Move to" Status Chips

```dart
Row(
  children: [
    _StatusChip(
      label: 'To Do',
      color: AppColors.todoColor,
      isActive: task.status == TaskStatus.todo,
      onTap: task.status == TaskStatus.todo
          ? null                          // already here — disable tap
          : () {
              ref.read(taskProvider.notifier).updateTaskStatus(task.id, TaskStatus.todo);
              Navigator.pop(context);     // close dialog
              ScaffoldMessenger.of(context).showSnackBar(...);
            },
    ),
    // same for 'In Progress' and 'Done'
  ],
),
```

**`onTap: task.status == TaskStatus.todo ? null : () { ... }`** — if the task is ALREADY in "To Do", `onTap = null` → the chip is non-interactive (disabled). Prevents meaningless state updates.

**`ref.read(taskProvider.notifier).updateTaskStatus(...)`** — updates the task status in the global Kanban board state without triggering a rebuild.

**`Navigator.pop(context)`** — closes the dialog immediately after the status change.

---

## Delete + Close Actions

```dart
Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [
    TextButton.icon(
      icon: const Icon(FeatherIcons.trash2, size: 16, color: Colors.red),
      label: const Text('Delete', style: TextStyle(color: Colors.red)),
      onPressed: () {
        ref.read(taskProvider.notifier).removeTask(task.id);
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Task "${task.title}" deleted')));
      },
    ),
    ElevatedButton(
      onPressed: () => Navigator.pop(context),
      child: Text('Close'),
    ),
  ],
),
```

**Delete flow:** Remove from provider → Close dialog → Show snackbar. All three happen synchronously (no `await` needed since `removeTask` is a synchronous state mutation).

**`mainAxisAlignment: MainAxisAlignment.spaceBetween`** — Delete is on the LEFT, Close is on the RIGHT. Destructive actions are separated from neutral actions.

---

## Private Helper Widgets

### `_PillBadge`

```dart
Container(
  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
  decoration: BoxDecoration(
    color: color.withValues(alpha: 0.12),
    borderRadius: BorderRadius.circular(50),   // fully rounded pill
  ),
  child: Text(label, style: GoogleFonts.outfit(fontSize: 10, fontWeight: FontWeight.w700, color: color)),
)
```

**`borderRadius: BorderRadius.circular(50)`** — very large radius on a short container → fully rounded "pill" shape.

### `_DetailSection`

```dart
Container(
  decoration: BoxDecoration(
    border: Border(left: BorderSide(color: accentColor, width: 3)),
  ),
  ...
)
```

**`Border(left: ...)`** — 3px colored vertical bar on the left edge, blockquote style. Each section has a different color (blue = description, green = notes, amber = questions).

### `_StatusChip`

```dart
Expanded(
  child: GestureDetector(
    onTap: onTap,   // null = GestureDetector ignores taps (disabled)
    child: AnimatedContainer(
      decoration: BoxDecoration(
        color: isActive ? color.withValues(alpha: 0.18) : ...,
        border: Border.all(
          color: isActive ? color : AppColors.getBorderColor(context),
          width: isActive ? 1.5 : 1.0,
        ),
      ),
    ),
  ),
)
```

**`VoidCallback? onTap`** — nullable. When `null`, `GestureDetector` doesn't respond to taps.

**`Expanded`** — all three chips share the row width equally.

---

## Summary: TaskDetailsDialog Component Hierarchy

```
TaskDetailsDialog (ConsumerWidget)
  └─ Dialog
     └─ ConstrainedBox(maxW:520, maxH:680)
        └─ Column(min-size)
           ├─ Header Container (gradient bg, rounded top)
           │   ├─ Priority icon box
           │   ├─ Title + _PillBadge × 2
           │   └─ Close IconButton
           │
           ├─ Flexible → SingleChildScrollView
           │   ├─ Row[_MetaCard(Deadline), _MetaCard(Status)]
           │   ├─ _DetailSection(Description) [if non-empty]
           │   ├─ _DetailSection(Notes) [if non-empty]
           │   └─ _DetailSection(Questions) [if non-empty]
           │
           ├─ "Move to" Row
           │   └─ _StatusChip × 3 [active = current status]
           │
           └─ Actions Row
               ├─ TextButton(Delete) [red, left]
               └─ ElevatedButton(Close) [blue, right]
```

---

# Part 2: `create_project_dialog.dart` (UPDATED)

> The dialog for creating a new API-backed Kanban project. **Note:** The Team Members section was removed — members are now added after project creation via the member-picker on the `ProjectDetailScreen`.

---

## State Fields

```dart
class _CreateProjectDialogState extends State<CreateProjectDialog> {
  final _formKey        = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descController = TextEditingController();

  String   _priority = 'Medium';
  DateTime? _deadline;
```

| Field | Type | Purpose |
|---|---|---|
| `_formKey` | `GlobalKey<FormState>` | Validates all form fields before submit |
| `_nameController` | `TextEditingController` | Tracks the project name input |
| `_descController` | `TextEditingController` | Tracks the description input |
| `_priority` | `String` | Selected priority chip ('Low', 'Medium', 'High') |
| `_deadline` | `DateTime?` | Optional deadline picked from date picker |

**No member fields** — members are NOT collected at creation time. The project is created with just the creator as a member; others are added later via the Jira-style member-picker on the detail screen.

---

## `_pickDeadline` — Themed Date Picker

```dart
Future<void> _pickDeadline() async {
  final isDark = Theme.of(context).brightness == Brightness.dark;
  final picked = await showDatePicker(
    context: context,
    initialDate: _deadline ?? now.add(const Duration(days: 14)),
    firstDate: now,
    lastDate: now.add(const Duration(days: 365 * 2)),
    builder: (ctx, child) => Theme(
      data: Theme.of(ctx).copyWith(
        colorScheme: isDark
            ? ColorScheme.dark(primary: AppColors.accent, ...)
            : ColorScheme.light(primary: AppColors.accent, ...),
      ),
      child: child!,
    ),
  );
  if (picked != null) setState(() => _deadline = picked);
}
```

**`showDatePicker`** — Flutter's built-in material date picker dialog.

**`builder: (ctx, child) => Theme(...)`** — wraps the date picker in a custom `Theme` to apply the app's accent color instead of the system default. Without this, the date picker would show Material default blue, breaking the visual consistency.

**`initialDate: _deadline ?? now.add(const Duration(days: 14))`** — defaults to 14 days from now if no deadline was previously picked.

---

## Form Fields: Name + Description

```dart
_textField(context: context, controller: _nameController,
    hint: 'Enter project title...', isDark: isDark,
    validator: (v) => v == null || v.trim().isEmpty ? 'Name is required' : null),
```

**`validator`** — called when `_formKey.currentState!.validate()` is invoked. Returns a String error message or null (valid).

**`.trim().isEmpty`** — trims whitespace first. A field with only spaces is treated as empty.

---

## Deadline Picker Row

```dart
GestureDetector(
  onTap: _pickDeadline,
  child: Container(
    decoration: BoxDecoration(
      border: Border.all(
        color: _deadline != null ? AppColors.accent : AppColors.getBorderColor(context),
        width: _deadline != null ? 1.5 : 1,
      ),
    ),
    child: Row(children: [
      Icon(FeatherIcons.calendar, color: _deadline != null ? AppColors.accent : ...),
      Text(_deadline == null ? 'Pick a date' : DateFormat('MMM d, yyyy').format(_deadline!)),
    ]),
  ),
),
```

**`_deadline != null ? AppColors.accent : ...`** — the border and icon color changes to accent when a date is selected. Visual feedback that the field is filled.

**`DateFormat('MMM d, yyyy').format(_deadline!)`** — formats the date as e.g. `Jun 15, 2025`. `!` is safe since we're inside the `_deadline != null` branch.

---

## Priority Chips

```dart
Row(
  children: ['Low', 'Medium', 'High'].map((p) => Padding(
    child: ChoiceChip(
      label: Text(p, style: GoogleFonts.outfit(
          color: _priority == p ? AppColors.accent : AppColors.getBodyColor(context),
          fontWeight: _priority == p ? FontWeight.bold : FontWeight.normal)),
      selected: _priority == p,
      onSelected: (s) { if (s) setState(() => _priority = p); },
      selectedColor: AppColors.accent.withValues(alpha: 0.2),
    ),
  )).toList(),
),
```

**`ChoiceChip`** — Flutter's built-in single-select chip. Only one can be selected at a time.

**`.map((p) => ...).toList()`** — generates all three chips from a list. DRY (Don't Repeat Yourself) pattern.

**`if (s) setState(() => _priority = p)`** — `onSelected` fires with `true` when selected, `false` when the same chip is tapped again. The `if (s)` ensures we only update state on selection, not deselection.

---

## Submit — What Is Returned

```dart
ElevatedButton.icon(
  onPressed: () {
    if (_formKey.currentState!.validate()) {
      Navigator.pop(context, {
        'name':         _nameController.text.trim(),
        'description':  _descController.text.trim(),
        'priority':     _priority,
        'deadline':     _deadline?.toIso8601String(),
        'member_names': <String>[],   // always empty — members added post-creation
      });
    }
  },
```

**`Navigator.pop(context, result)`** — pops the dialog AND returns the `result` map to the caller (via `showDialog<Map<String, dynamic>>(...)`).

**`_deadline?.toIso8601String()`** — null-safe call. If deadline is null, returns `null` (not sent in the body). If set, returns e.g. `'2025-06-15T00:00:00.000'`.

**`'member_names': <String>[]`** — always returns an empty list. This is a legacy field kept for API compatibility. The backend ignores member names at creation — the creator is auto-added via `project_members` table; additional members are added after creation via `POST /projects/:id/members`.

---

## Summary: CreateProjectDialog

| Form Field | State Variable | Sent to Backend |
|---|---|---|
| Project Name | `_nameController.text` | `title` (required) |
| Description | `_descController.text` | `description` (optional) |
| Priority | `_priority` | Informational only (not persisted to DB in current backend) |
| Deadline | `_deadline` | `deadline` as ISO 8601 string (optional) |
| Members | N/A — removed | Members added post-creation via member-picker |

> **Design Decision**: Members are intentionally NOT collected at creation time. The member-picker (which requires fetching classroom students from the backend) lives on the `ProjectDetailScreen` and allows adding/removing members at any time after the project exists.
