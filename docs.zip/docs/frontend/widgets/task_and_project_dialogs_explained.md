# 📄 `widgets/create_task_dialog.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/create_task_dialog.dart`
**Lines:** 676
**Role:** Full task creation dialog with animated entrance, form validation, date+time pickers, subject dropdown (from enrolled channels or custom), priority selector, notes/questions fields.

---

## 1. File Purpose

`CreateTaskDialog` is a rich, scrollable dialog for creating personal tasks. It bridges the user's enrolled channels (`channelsProvider`) with the local task store (`taskProvider`).

---

## 2. Key State Variables

```dart
TaskPriority _priority = TaskPriority.medium;  // Default priority
String? _selectedSubject;                       // From dropdown
bool _useCustomSubject = false;                 // Toggle to custom text field
DateTime _dueDate = DateTime.now().add(const Duration(days: 7));  // Default: 1 week
TimeOfDay _dueTime = const TimeOfDay(hour: 23, minute: 59);       // Default: end of day
```

**Default deadline = 7 days** — A reasonable default for academic assignments.
**Default time = 23:59** — End of day deadline, common in academic contexts.

---

## 3. Entrance Animation

```dart
_animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 350));
_fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
_animCtrl.forward();
```

The dialog fades in over 350ms. `FadeTransition` wraps the entire `Dialog` widget.

---

## 4. Subject Selection — Dropdown + Custom Toggle

```dart
final channelNames = channelsAsync.maybeWhen(
  data: (channels) => channels.map((c) => c.subjectName.isNotEmpty ? c.subjectName : c.channelName).toList(),
  orElse: () => [],
);
```

**`maybeWhen`** — Returns `[]` for loading/error states (no subject available yet).

**The dropdown has a special `'__custom__'` value:**
```dart
DropdownMenuItem(
  value: '__custom__',
  child: Row(children: [Icon(FeatherIcons.plus), Text('Create my own subject')]),
),
```

When selected:
```dart
if (value == '__custom__') {
  setState(() => _useCustomSubject = true);
}
```

This switches to a free-text field for the subject name. A switch-back button (`FeatherIcons.list`) reverts to the dropdown.

---

## 5. Date + Time Pickers

```dart
Future<void> _pickDate() async {
  final picked = await showDatePicker(
    context: context,
    initialDate: _dueDate,
    firstDate: DateTime.now(),
    lastDate: DateTime.now().add(const Duration(days: 365)),
    builder: (ctx, child) => Theme(
      data: Theme.of(ctx).copyWith(
        colorScheme: ColorScheme.dark(primary: AppColors.accent, surface: AppColors.surface),
      ),
      child: child!,
    ),
  );
  if (picked != null) setState(() => _dueDate = picked);
}
```

**Custom `Theme` wrapper** — Forces the date picker to use the app's dark theme and accent color. Without this, the date picker shows the system's default light theme.

**`firstDate: DateTime.now()`** — Prevents selecting past dates.

---

## 6. `_submit()` — Task Assembly

```dart
void _submit(List<String> channelNames) {
  if (!_formKey.currentState!.validate()) return;

  final subject = _useCustomSubject
      ? _customSubjectController.text.trim()
      : (_selectedSubject ?? (channelNames.isNotEmpty ? channelNames.first : 'General'));

  final deadline = DateTime(
    _dueDate.year, _dueDate.month, _dueDate.day,
    _dueTime.hour, _dueTime.minute,
  );

  final task = TaskModel(
    id: DateTime.now().millisecondsSinceEpoch.toString(),  // Unique ID
    ...
  );
  ref.read(taskProvider.notifier).addTask(task);
  Navigator.pop(context);
}
```

**ID generation:** `DateTime.now().millisecondsSinceEpoch.toString()` — A millisecond-precision timestamp as a string ID. Sufficient for local-only task management (no DB).

**Subject fallback chain:** `customText → selectedDropdown → firstChannelName → 'General'`

---

## 7. `_fieldDecoration` — Consistent Input Styling

A helper method that returns `InputDecoration` with:
- `enabledBorder` (grey border)
- `focusedBorder` (accent blue border, 1.5px)
- `errorBorder` (red border)
- Dark/light adaptive `fillColor`

Reused by all text inputs in the dialog.

---

## 8. Final Summary

`CreateTaskDialog` is the most feature-rich form in the project. It demonstrates: conditional form fields (dropdown ↔ custom text), native date/time pickers with custom theming, millisecond-based local ID generation, and comprehensive input validation.

---

# 📄 `widgets/task_details_dialog.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/task_details_dialog.dart`
**Lines:** 554
**Role:** Read-only task details dialog with inline status-change chips, delete action, and snackbar feedback.

---

## 1. File Purpose

`TaskDetailsDialog` opens when a task card is tapped (from either `KanbanBoardWidget` or `AssignmentsViewWidget`). Shows full task details and allows changing status or deleting the task.

---

## 2. Status Change Chips

```dart
_StatusChip(
  label: 'To Do',
  icon: FeatherIcons.circle,
  color: AppColors.todoColor,
  isActive: task.status == TaskStatus.todo,
  onTap: task.status == TaskStatus.todo
      ? null   // Disabled — already this status
      : () {
          ref.read(taskProvider.notifier).updateTaskStatus(task.id, TaskStatus.todo);
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('"${task.title}" moved to To Do'),
            behavior: SnackBarBehavior.floating,
          ));
        },
),
```

**`onTap: null`** — Disabling the current status chip prevents unnecessary state updates.

**Post-update pattern:** After updating status:
1. `ref.read(taskProvider.notifier).updateTaskStatus(...)` — Updates provider
2. `Navigator.pop(context)` — Closes dialog
3. `ScaffoldMessenger.showSnackBar(...)` — Shows confirmation

**`SnackBarBehavior.floating`** — The snackbar floats above the bottom of the screen instead of pushing content up.

---

## 3. `_StatusChip` — `AnimatedContainer` Active State

```dart
AnimatedContainer(
  duration: const Duration(milliseconds: 200),
  decoration: BoxDecoration(
    color: isActive ? color.withValues(alpha: 0.18) : AppColors.getSurfaceColor(context),
    border: Border.all(
      color: isActive ? color : AppColors.getBorderColor(context),
      width: isActive ? 1.5 : 1.0,
    ),
  ),
)
```

When `isActive`, the chip has a tinted background + thicker colored border. The transition is animated over 200ms.

---

## 4. Delete Action

```dart
TextButton.icon(
  icon: const Icon(FeatherIcons.trash2, size: 16, color: Colors.red),
  label: const Text('Delete', style: TextStyle(color: Colors.red)),
  onPressed: () {
    ref.read(taskProvider.notifier).removeTask(task.id);
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Task "${task.title}" deleted'),
      behavior: SnackBarBehavior.floating,
    ));
  },
),
```

No confirmation dialog — just immediate delete with a snackbar. Since tasks are local-only, there's no "Are you sure?" prompt.

---

## 5. `_DetailSection` — Left-Border Card Pattern

```dart
Container(
  padding: const EdgeInsets.all(16),
  decoration: BoxDecoration(
    border: Border(left: BorderSide(color: accentColor, width: 3)),
  ),
)
```

Each content section (Description, Notes, Questions) has a 3px colored left border — matching the `_SubjectManagementCard` pattern. Three different accent colors distinguish the sections visually.

---

## 6. Final Summary

`TaskDetailsDialog` uses the standard `_StatusChip` pattern with `AnimatedContainer`, `onTap: null` for current-status disabling, and the three-step post-update flow (update → pop → snackbar). The left-border detail section pattern is a consistent design motif across the app.

---

# 📄 `widgets/create_project_dialog.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/create_project_dialog.dart`
**Lines:** 221
**Role:** Project creation dialog with name, description, team members, deadline, and priority — currently a UI shell with unimplemented backend submission.

---

## 1. File Purpose

`CreateProjectDialog` is the dialog for creating new projects. It collects project details but does **not** call any API on submit.

---

## 2. Key Issue — Unimplemented Submission

```dart
ElevatedButton(
  onPressed: () {
    if (_formKey.currentState!.validate()) {
      // Logic to save project can be added here
      Navigator.pop(context);
    }
  },
)
```

The comment says "Logic to save project can be added here" — the form closes but no data is saved. There's no `ref.read(projectsProvider.notifier).createProject(...)` call.

---

## 3. `readOnly: onTap != null`

```dart
TextFormField(
  onTap: onTap,
  readOnly: onTap != null,
)
```

If `onTap` is provided (for the deadline field), the field is `readOnly` — prevents keyboard from opening. The intended behavior is to show a date picker instead. However, the `onTap` callback passed for deadline is empty (`() {}`), so no date picker opens.

---

## 4. Priority `ChoiceChip` Selector

```dart
Row(
  children: ['Low', 'Medium', 'High'].map((p) => ChoiceChip(
    label: Text(p),
    selected: _priority == p,
    onSelected: (selected) { if (selected) setState(() => _priority = p); },
    selectedColor: AppColors.accent.withValues(alpha: 0.2),
  )).toList(),
)
```

`ChoiceChip` from Material — single-selection chips. The app maintains `_priority` as a `String` (not `TaskPriority` enum) — an inconsistency with the rest of the codebase.

---

## 5. Final Summary

`CreateProjectDialog` is a UI placeholder. The form fields are styled and the priority selector works, but the backend submission (`POST /api/projects`) is not implemented. This is one of the incomplete features identified across the project.
