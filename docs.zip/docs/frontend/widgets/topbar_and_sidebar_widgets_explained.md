# 📄 `widgets/top_bar_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/top_bar_widget.dart`
**Lines:** 497
**Role:** Persistent app header — notification bell with overlay panel, theme toggle, search bar (desktop/mobile variants), and create-task button.

---

## 1. File Purpose

`TopBarWidget` sits at the top of every screen in the app. It contains:
- **Desktop:** Search bar + notification bell + theme toggle + create button
- **Mobile:** Hamburger menu + page title + notification bell + search icon + create button
- **Notification overlay:** A floating `OverlayEntry` panel anchored to the bell icon

---

## 2. Overlay Notification Panel

The notification bell doesn't use a route or dialog — it uses Flutter's `Overlay` system for a floating panel that sits ABOVE the normal widget tree without affecting layout.

### Key State Variables

```dart
final LayerLink _notificationLink = LayerLink();
OverlayEntry? _overlayEntry;
```

**`LayerLink`** — A link between two widgets. `CompositedTransformTarget` marks the anchor point (the bell icon), and `CompositedTransformFollower` in the overlay follows that anchor point as the UI scrolls/resizes. This is how the panel stays aligned to the bell icon.

**`_overlayEntry`** — Reference to the current overlay. `null` = panel is closed.

### Toggle Logic

```dart
void _toggleNotifications() {
  if (_overlayEntry == null) {
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
  } else {
    _dismissOverlay();
  }
}
```

`Overlay.of(context).insert(entry)` — Adds the overlay entry to Flutter's overlay stack (like a layer above all other widgets on the screen).

### Overlay Entry Construction

```dart
OverlayEntry _createOverlayEntry() {
  return OverlayEntry(
    builder: (context) => Stack(
      children: [
        // Transparent full-screen hit area — tap anywhere to dismiss
        Positioned.fill(
          child: GestureDetector(
            onTap: _dismissOverlay,
            behavior: HitTestBehavior.translucent,
          ),
        ),
        // The panel itself, anchored to the bell
        Positioned(
          width: isMobile ? screenWidth - 32 : 350,
          child: CompositedTransformFollower(
            link: _notificationLink,
            showWhenUnlinked: false,
            offset: isMobile
                ? Offset(-(screenWidth - 32 - 40), 50)
                : const Offset(-310, 50),
            child: Material(elevation: 8, child: const NotificationPanel()),
          ),
        ),
      ],
    ),
  );
}
```

**`Positioned.fill` + `GestureDetector`** — A transparent layer that covers the ENTIRE screen. Tapping anywhere outside the notification panel triggers `_dismissOverlay`. This is the "click outside to close" pattern.

**`HitTestBehavior.translucent`** — The hit test goes through this transparent layer to the widgets underneath. Without this, the transparent layer would block all taps.

**`CompositedTransformFollower`** — Follows the `CompositedTransformTarget` (on the bell icon). `offset: Offset(-310, 50)` positions the panel 310px to the left and 50px below the bell icon — so it appears as a dropdown.

**`Material(elevation: 8)`** — Adds a shadow to the panel to visually float above the content.

**Auto-dismiss on navigation:**
```dart
ref.listen(navigationProvider, (_, __) => _dismissOverlay());
```
`ref.listen` fires a side effect when `navigationProvider` changes. When the user switches tabs, the notification panel closes automatically.

---

## 3. Unread Count Badge

```dart
final notifAsync = ref.watch(notificationsApiProvider);
final unreadCount = notifAsync.whenOrNull(
      data: (list) => list.where((n) => !(n['is_read'] as bool? ?? false)).length,
    ) ?? 0;
```

**`whenOrNull(data: ...)`** — Returns a value only in the `data` state; returns `null` for loading/error → `?? 0` defaults to 0 (no badge).

**`!(n['is_read'] as bool? ?? false)`** — Counts items where `is_read` is false or null.

```dart
if (unreadCount > 0)
  Positioned(
    top: -3, right: -3,
    child: Container(
      width: 14, height: 14,
      decoration: BoxDecoration(color: Colors.red, shape: BoxShape.circle),
      child: Text('$unreadCount', style: TextStyle(fontSize: 8, color: Colors.white)),
    ),
  ),
```

A 14×14 red circle with white text, positioned at `-3, -3` (top-right corner, overlapping the bell icon border).

---

## 4. Mobile Search Bottom Sheet

```dart
void _showMobileSearch(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => _MobileSearchSheet(ref: ref),
  );
}
```

**`isScrollControlled: true`** — Allows the sheet to resize when the keyboard appears. Without this, the keyboard would overlap the text field.

**`backgroundColor: Colors.transparent`** — The sheet itself is transparent; the actual decoration is on the child Container (for the rounded top corners).

**`_MobileSearchSheet.dispose()` side effect:**
```dart
@override
void dispose() {
  _ctrl.dispose();
  ref.read(searchQueryProvider.notifier).set('');  // Clear search on close
  super.dispose();
}
```
When the bottom sheet is dismissed, the search query is cleared. This ensures the assignment/subject lists go back to showing everything.

---

## 5. `_CreateButton` Widget

```dart
class _CreateButton extends ConsumerWidget {
  Widget build(BuildContext context, WidgetRef ref) {
    return InkWell(
      onTap: () => showDialog(context: context, builder: (_) => const CreateTaskDialog()),
```

Opens `CreateTaskDialog` on tap. For faculty, the label shows "Post / Create". For students: "New Task". Both open the same dialog (the dialog internally adapts to role).

---

## 6. Resource Cleanup

```dart
@override
void dispose() {
  _dismissOverlay();  // Remove overlay before widget is destroyed
  super.dispose();
}
```

Critical: if the overlay is showing and the widget disposes (e.g., hot reload), the overlay must be removed first to prevent memory leaks.

---

## 7. Final Summary

`TopBarWidget` is architecturally notable for its `Overlay`-based notification panel (more flexible than `Dialog` or `Popup`), the `LayerLink`/`CompositedTransformFollower` positioning system, and the `ref.listen` auto-dismiss pattern. The transparent hit-test backdrop for click-outside-to-close is a standard Flutter overlay pattern.

---

# 📄 `widgets/sidebar_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/sidebar_widget.dart`
**Lines:** 377
**Role:** Left navigation sidebar — role-adaptive nav items, animated selection highlight, settings/logout at bottom, and user profile card.

---

## 1. File Purpose

`SidebarWidget` is the persistent left navigation panel. It:
- Shows different nav items for students vs faculty
- Animated highlight on selected item (180ms)
- Auto-closes drawer on mobile when a nav item is tapped
- Shows the user's profile card at the bottom with logout

---

## 2. Role-Based Navigation Items

```dart
static final List<SidebarItemModel> studentItems = [
  SidebarItemModel(icon: FeatherIcons.grid, title: 'Dashboard'),
  SidebarItemModel(icon: FeatherIcons.book, title: 'Subjects'),
  SidebarItemModel(icon: FeatherIcons.folder, title: 'Projects'),
  SidebarItemModel(icon: FeatherIcons.calendar, title: 'Calendar'),
  SidebarItemModel(icon: FeatherIcons.messageSquare, title: 'Messages'),
  SidebarItemModel(icon: FeatherIcons.bookOpen, title: 'Notes'),
  SidebarItemModel(icon: FeatherIcons.fileMinus, title: 'Question Papers'),
];

static final List<SidebarItemModel> facultyItems = [
  SidebarItemModel(icon: FeatherIcons.grid, title: 'Dashboard'),
  SidebarItemModel(icon: FeatherIcons.bookOpen, title: 'Manage Subjects'),
  SidebarItemModel(icon: FeatherIcons.folder, title: 'Student Projects'),
  SidebarItemModel(icon: FeatherIcons.calendar, title: 'Schedule'),
  SidebarItemModel(icon: FeatherIcons.messageSquare, title: 'Messages'),
];
```

Students get 7 items; faculty get 5. The `index` of each item maps to the navigation index in `_LazyIndexedStack`.

---

## 3. Item Selection Logic

```dart
final isSelected = selectedIndex == index;

AnimatedContainer(
  duration: const Duration(milliseconds: 180),
  decoration: BoxDecoration(
    color: isSelected ? AppColors.accent.withValues(alpha: 0.12) : Colors.transparent,
    borderRadius: BorderRadius.circular(12),
    border: isSelected ? Border.all(color: AppColors.accent.withValues(alpha: 0.3), width: 1) : null,
  ),
  ...
)
```

**`AnimatedContainer`** — When `isSelected` changes (user taps a different nav item), the container smoothly animates from one decoration to another over 180ms. This creates a smooth highlight transition.

Selected state: semi-transparent blue background + blue border.
Unselected: transparent, no border.

---

## 4. Auto-Close Drawer on Mobile

```dart
onTap: () {
  ref.read(navigationProvider.notifier).navigateTo(index);
  if (Navigator.of(context).canPop()) {
    Navigator.of(context).pop();
  }
},
```

**`Navigator.of(context).canPop()`** — Returns `true` if there's a route to pop (i.e., the sidebar is inside a `Drawer`). On desktop, the sidebar is always visible (not a Drawer), so `canPop()` returns false and no pop occurs.

---

## 5. Profile Card with Logout Dialog

```dart
Tooltip(message: 'Logout',
  child: InkWell(
    onTap: () async {
      final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(...));
      if (confirm == true) {
        await ref.read(authProvider.notifier).logout();
      }
    },
    child: Icon(FeatherIcons.logOut, size: 17, color: Colors.red.shade400),
  ),
),
```

**`showDialog<bool>`** — Returns a `bool?`. The dialog's "Sign Out" button does `Navigator.pop(ctx, true)`, and "Cancel" does `Navigator.pop(ctx, false)`.

**`if (confirm == true)`** — Only proceeds if explicitly confirmed (not null from dialog dismiss).

---

## 6. Settings as Separate Item

```dart
onTap: () {
  ref.read(navigationProvider.notifier).navigateTo(7); // hardcoded index
  if (Navigator.of(context).canPop()) Navigator.of(context).pop();
},
```

Settings is hardcoded to index 7 — it's not in the `studentItems` or `facultyItems` lists. It's always at the bottom of the sidebar, separated by a divider.

---

## 7. Final Summary

`SidebarWidget` uses `AnimatedContainer` for smooth selection transitions, role-based item lists, and the `canPop()` pattern for universal mobile/desktop behavior. The logout confirmation dialog uses Flutter's `showDialog<bool>` return value pattern.
