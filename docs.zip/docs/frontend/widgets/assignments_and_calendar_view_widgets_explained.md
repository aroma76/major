# 📄 `widgets/assignments_view_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/assignments_view_widget.dart`
**Lines:** 481
**Role:** Personal assignments screen with dual-view toggle (List/Kanban), subject+priority filter dropdowns, animated view switcher, and `TaskDetailsDialog` on tap.

---

## 1. File Purpose

`AssignmentsViewWidget` is the "Assignments" tab in the sidebar. It displays all the user's local `TaskModel` items with filtering capabilities and two view modes:
- **List view** — traditional scrollable rows with status icons and priority tags
- **Kanban view** — delegates to `KanbanBoardWidget` for drag-and-drop columns

---

## 2. Provider Dependencies

```dart
final tasks = ref.watch(taskProvider);             // All tasks (local state)
final viewType = ref.watch(assignmentViewTypeProvider);  // List or Kanban
final selectedSubject = ref.watch(selectedSubjectFilterProvider);  // Nullable filter
final selectedPriority = ref.watch(selectedPriorityFilterProvider); // Nullable filter
```

All providers are synchronous (no `AsyncValue`) — tasks live in in-memory Riverpod state.

---

## 3. Client-Side Filtering

```dart
final filteredTasks = tasks.where((task) {
  final matchesSubject = selectedSubject == null || task.subject == selectedSubject;
  final matchesPriority = selectedPriority == null || task.priority == selectedPriority;
  return matchesSubject && matchesPriority;
}).toList();
```

- `selectedSubject == null` → "All Subjects" selected, no filter
- `selectedSubject == 'Data Structures'` → only DS tasks shown
- Both conditions must match (AND logic)
- Filtering happens every `build()` — fast since task lists are small

---

## 4. `AnimatedSwitcher` — View Mode Transition

```dart
AnimatedSwitcher(
  duration: const Duration(milliseconds: 300),
  child: viewType == AssignmentViewType.kanban
      ? const KanbanBoardWidget()
      : _buildListView(context, filteredTasks),
),
```

When the user switches from List to Kanban, `AnimatedSwitcher` cross-fades between the two views over 300ms. The `key` on each child would be needed to force the animation (if both views are the same widget type), but since they're different widget types, Flutter detects the change automatically.

---

## 5. Generic `_buildDropdownFilter<T>` Method

```dart
Widget _buildDropdownFilter<T>(
  BuildContext context, {
  required String hint,
  required T value,
  required List<DropdownMenuItem<T>> items,
  required ValueChanged<T> onChanged,
})
```

A **generic** dropdown builder that works for both `String?` (subjects) and `TaskPriority?` (priorities). Using generics avoids two separate methods. `DropdownButtonHideUnderline` removes Flutter's default underline decoration.

---

## 6. Subject List from Task Data

```dart
final subjects = allTasks.map((t) => t.subject).toSet().toList();
```

- `.map((t) => t.subject)` — Extract subject name from every task
- `.toSet()` — Remove duplicates (multiple tasks from same subject)
- `.toList()` — Convert back for `DropdownMenuItem` mapping

The subject list is dynamically built from existing tasks — no separate API call.

---

## 7. Status Icon System

```dart
Widget _buildStatusIcon(TaskStatus status) {
  switch (status) {
    case TaskStatus.todo:      color = AppColors.todoColor;       icon = Icons.radio_button_unchecked;
    case TaskStatus.inProgress: color = AppColors.inProgressColor; icon = Icons.pending_actions;
    case TaskStatus.done:      color = AppColors.doneColor;       icon = Icons.check_circle_outline;
  }
  return Container(
    padding: const EdgeInsets.all(8),
    decoration: BoxDecoration(color: color.withValues(alpha: 0.1), shape: BoxShape.circle),
    child: Icon(icon, color: color, size: 20),
  );
}
```

Each task status maps to a unique icon + color. The icon is in a 10% opacity circle background — consistent with the overall design pattern.

---

## 8. Final Summary

`AssignmentsViewWidget` demonstrates client-side filtering with nullable filter providers, generic UI builder methods, and `AnimatedSwitcher` for smooth view mode transitions. The List and Kanban views share the same underlying `taskProvider` data — switching views doesn't lose filter state.

---

# 📄 `widgets/calendar_view_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/calendar_view_widget.dart`
**Lines:** 450
**Role:** Academic calendar with `table_calendar` package integration, event markers, type filter chips, day selection, and upcoming event list.

---

## 1. File Purpose

`CalendarViewWidget` renders the academic calendar powered by `table_calendar`. Events come from `academicEventsProvider` (API: `GET /api/academic-events`). Supports 7 event types with color coding and filter chips.

---

## 2. Event Type System

```dart
static final _typeColors = <String, Color>{
  'exam': Color(0xFFef4444),     // Red
  'holiday': Color(0xFF22c55e), // Green
  'semester': Color(0xFF3b82f6),// Blue
  'fest': Color(0xFFec4899),    // Pink
  'workshop': Color(0xFF06b6d4),// Cyan
  'deadline': Color(0xFFf97316),// Orange
  'other': Color(0xFF6b7280),   // Gray
};

static final _typeIcons = <String, IconData>{
  'exam': FeatherIcons.fileText,
  'holiday': FeatherIcons.sun,
  // ...
};
```

Map-based type → color/icon lookup (O(1) access). Color values are CSS-standard Tailwind colors.

---

## 3. Custom Color from DB

```dart
Color _colorFor(String? hex) {
  if (hex == null) return AppColors.accent;
  try {
    return Color(int.parse(hex.replaceFirst('#', '0xFF')));
  } catch (_) {
    return AppColors.accent;
  }
}
```

Academic events store a custom `colour` field in the DB (e.g., `'#FF5733'`). This converts the hex string:
- `'#FF5733'` → `'0xFFFF5733'` (Flutter's ARGB format, full alpha)
- `int.parse('0xFFFF5733')` → the integer representation

`try/catch` handles malformed hex strings gracefully (falls back to accent).

---

## 4. Multi-Day Event Overlap Check

```dart
List<Map<String, dynamic>> _eventsOnDay(List<Map<String, dynamic>> events, DateTime day) {
  return events.where((e) {
    final start = DateTime.tryParse(e['start_date'] as String? ?? '');
    final end = DateTime.tryParse(e['end_date'] as String? ?? '');
    if (start == null) return false;
    final endDay = end ?? start;
    return !day.isBefore(DateTime(start.year, start.month, start.day)) &&
           !day.isAfter(DateTime(endDay.year, endDay.month, endDay.day));
  }).toList();
}
```

For an event from May 20 to May 25:
- Any day D is "on" the event if `D >= May 20` AND `D <= May 25`
- `!day.isBefore(start)` = D >= start
- `!day.isAfter(end)` = D <= end

The time component is stripped by using `DateTime(year, month, day)` (midnight) for comparison — prevents timezone hour issues.

---

## 5. `TableCalendar` Integration

```dart
TableCalendar<Map<String, dynamic>>(
  firstDay: DateTime(year - 1, 7, 1),   // Academic year: July previous year
  lastDay: DateTime(year + 1, 6, 30),   // To June next year
  focusedDay: _focusedDay,
  eventLoader: (day) => _eventsOnDay(filtered, day),  // Events per day
  calendarBuilders: CalendarBuilders(
    markerBuilder: (context, day, events) {
      // Custom colored dots below calendar days
      return Row(children: events.take(3).map((e) => Container(
        width: 6, height: 6,
        decoration: BoxDecoration(color: _colorFor(e['colour']), shape: BoxShape.circle),
      )).toList());
    },
  ),
```

**`eventLoader`** — Called for every visible day; returns the list of events for that day. `table_calendar` uses this for event markers and count.

**`markerBuilder`** — Custom marker: 3 colored dots (one per event type) replace the default single dot. `events.take(3)` limits to 3 dots max.

**`onPageChanged`** — When user navigates to a different month, if the month is in a different year:
```dart
ref.invalidate(academicEventsProvider(focusedDay.year));
```
Automatically loads the new year's events.

---

## 6. Year-Parameterized Provider

```dart
final year = _focusedDay.year;
final eventsAsync = ref.watch(academicEventsProvider(year));
```

`academicEventsProvider` is a **family provider** — `academicEventsProvider(2024)` and `academicEventsProvider(2025)` are cached separately. Navigating between years keeps both cached.

---

## 7. Event List — Day Selection vs. Upcoming

```dart
if (_selectedDay != null) {
  display = _eventsOnDay(events, _selectedDay!);
} else {
  display = events.where((e) {
    final end = DateTime.tryParse(e['end_date'] ?? '') ?? DateTime.tryParse(e['start_date'] ?? '');
    return end != null && !end.isBefore(DateTime(now.year, now.month, now.day));
  }).toList()
  ..sort((a, b) => (a['start_date'] as String).compareTo(b['start_date'] as String))
  ..take(20);
}
```

- If a day is selected: show events ON that day
- Otherwise: show next 20 upcoming events (sorted by start date)
- String comparison for dates works here because ISO 8601 dates are lexicographically sortable

---

## 8. Final Summary

`CalendarViewWidget` integrates `table_calendar` with custom event markers, multi-day event detection, and a hex-to-Color parser. The year-parameterized provider supports lazy loading of different year's events without re-fetching already-loaded data.
