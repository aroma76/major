# 📄 `widgets/teacher_create_assignment_dialog.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/teacher_create_assignment_dialog.dart`
**Lines:** 417
**Role:** Faculty assignment creation dialog — selects a subject channel, fills assignment details, posts to `POST /channels/:id/assignments`, and invalidates relevant providers.

---

## 1. File Purpose

`TeacherCreateAssignmentDialog` is the **fully implemented** faculty counterpart to the student-facing assignment view. It hits the real API (unlike `CreateProjectDialog` which is a stub) and invalidates the relevant providers so the assignment list auto-refreshes.

---

## 2. State Variables

```dart
ChannelModel? _selectedChannel;  // Which subject to assign to
DateTime? _dueDate;              // Null until user picks
String _priority = 'medium';    // Default priority (lowercase string)
bool _loading = false;           // Shows spinner during API call
String? _error;                  // Inline error message
```

---

## 3. `_submit()` — Full API Flow

```dart
Future<void> _submit() async {
  if (!_formKey.currentState!.validate()) return;
  if (_selectedChannel == null) {
    setState(() => _error = 'Please select a subject');
    return;
  }
  if (_dueDate == null) {
    setState(() => _error = 'Please select a due date');
    return;
  }

  setState(() { _loading = true; _error = null; });

  try {
    final api = ApiService();
    await api.dio.post(
      '/channels/${_selectedChannel!.id}/assignments',
      data: {
        'title': _titleCtrl.text.trim(),
        'description': _descCtrl.text.trim(),
        'due_date': _dueDate!.toIso8601String(),
        'max_marks': int.tryParse(_marksCtrl.text.trim()) ?? 100,
        'priority': _priority,
      },
    );
    // Invalidate providers so assignment lists refresh
    ref.invalidate(channelAssignmentsProvider(_selectedChannel!.id));
    ref.invalidate(allAssignmentsProvider);

    if (mounted) Navigator.pop(context, true);
  } catch (e) {
    setState(() {
      _error = 'Failed to create assignment. Please try again.';
      _loading = false;
    });
  }
}
```

**`_dueDate!.toIso8601String()`** — Converts `DateTime` to ISO 8601 format (e.g., `'2025-05-30T00:00:00.000'`) — the format PostgreSQL expects for timestamps.

**`int.tryParse(...) ?? 100`** — Gracefully handles non-numeric input for max marks (falls back to 100).

**Two `ref.invalidate` calls:**
- `channelAssignmentsProvider(_selectedChannel!.id)` — Refreshes the assignment list in the `SubjectHubSheet` for this specific channel
- `allAssignmentsProvider` — Refreshes the global assignment list (student view)

**`Navigator.pop(context, true)`** — Closes with a `true` result. Callers can `await showDialog(...)` and check the result to know if an assignment was created.

**Error handling:** Catches any exception → sets `_error` string → re-enables submit button (`_loading = false`).

---

## 4. Loading State Button

```dart
child: _loading
    ? const SizedBox(
        width: 18, height: 18,
        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
      )
    : Text('Create Assignment'),
```

The submit button shows a small inline spinner during the API call. `onPressed: _loading ? null : _submit` disables the button during loading to prevent double-submit.

---

## 5. Generic `_styledDropdown<T>` Method

Same pattern as `AssignmentsViewWidget` — a generic method handles both `ChannelModel?` and `String` dropdowns with the same visual style.

---

## 6. Final Summary

`TeacherCreateAssignmentDialog` is the cleanest dialog implementation — it has real API integration, loading states, error display, provider cache invalidation, and two-step validation (form + null checks for channel and date). Contrast with `CreateProjectDialog` which is a UI-only stub.

---

# 📄 `widgets/teacher_post_announcement_dialog.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/teacher_post_announcement_dialog.dart`
**Lines:** 364
**Role:** Faculty announcement posting dialog — selects a subject, fills title + content + important flag, posts via `ApiService.createAnnouncement()`, and invalidates three providers.

---

## 1. File Purpose

`TeacherPostAnnouncementDialog` posts announcements from the teacher dashboard's quick action. It uses `ApiService.createAnnouncement()` (a typed wrapper) rather than raw `api.dio.post()`.

---

## 2. `_submit()` — Three-Provider Invalidation

```dart
try {
  final api = ApiService();
  await api.createAnnouncement(
    _selectedChannel!.id,
    _titleCtrl.text.trim(),
    _contentCtrl.text.trim(),
    isImportant: _isImportant,
  );
  // Per-channel provider (Subject Hub announcements tab)
  ref.invalidate(channelAnnouncementsProvider(_selectedChannel!.id));
  // Dashboard feed for both roles (teacher dashboard home + student announcement panel)
  ref.invalidate(dashboardRecentActivityProvider(true));
  ref.invalidate(dashboardRecentActivityProvider(false));
  if (mounted) Navigator.pop(context, true);
```

**Why invalidate `dashboardRecentActivityProvider` for BOTH `true` and `false`?**
- `true` = faculty role — the teacher's own dashboard `AnnouncementsPanel`
- `false` = student role — students viewing the dashboard on their end

After a teacher posts, both the teacher's own view and the student activity feed must reflect the new announcement. The `dashboardRecentActivityProvider(isFaculty)` family provider is cached separately for each boolean key — both must be invalidated.

---

## 3. "Mark as Important" Toggle

```dart
GestureDetector(
  onTap: () => setState(() => _isImportant = !_isImportant),
  child: AnimatedContainer(
    duration: const Duration(milliseconds: 180),
    decoration: BoxDecoration(
      color: _isImportant ? Colors.red.withValues(alpha: 0.08) : background,
      border: Border.all(
        color: _isImportant ? Colors.red.withValues(alpha: 0.4) : borderColor,
      ),
    ),
    child: Row(children: [
      Icon(_isImportant ? FeatherIcons.alertCircle : FeatherIcons.circle, color: ...),
      Text('Mark as Important'),
      Text(_isImportant ? 'ON' : 'OFF'),
    ]),
  ),
),
```

An `AnimatedContainer` toggle button (not a `Switch` widget). The entire container changes color, border, and icon on tap. This custom toggle is more visually integrated than a standard `Switch`.

---

## 4. Compared to Assignment Dialog

| Feature | `TeacherCreateAssignmentDialog` | `TeacherPostAnnouncementDialog` |
|---|---|---|
| API call | `api.dio.post(...)` | `api.createAnnouncement(...)` |
| Provider invalids | 2 | 3 |
| Extra fields | Due date, Max marks | Important flag |
| Error handling | Yes | Yes |
| Loading state | Yes | Yes |

Both dialogs follow the same structure: validate → load → API → invalidate → close.

---

## 5. Final Summary

`TeacherPostAnnouncementDialog` demonstrates the three-provider invalidation pattern needed when a single action affects multiple data consumers (subject hub, faculty dashboard, student dashboard). The custom `AnimatedContainer` toggle is a design polish choice over a standard checkbox/switch.
