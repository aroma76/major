# 📄 `widgets/teacher_overview_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/teacher_overview_widget.dart`
**Lines:** 990
**Role:** Faculty home dashboard — animated hero banner with real-time stats chips, API-driven stat cards, quick action grid with dialog/navigation routing, subject management cards with animated progress bars, and the shared `AnnouncementsPanel`.

---

## 1. File Purpose

`TeacherOverviewWidget` is the faculty equivalent of `TodayOverviewWidget`. It aggregates data from `teacherStatsProvider` and `channelsProvider` to display a faculty-specific dashboard experience.

---

## 2. Entrance Animation (Same Pattern as Student Dashboard)

```dart
_controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
_fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
_slideAnim = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
    .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
_controller.forward();
```

Same fade + slide-up entrance as `TodayOverviewWidget`. The screens feel consistently animated even though they're separate widgets.

---

## 3. Hero Banner with Live Stats Chips

```dart
final statsAsync = ref.watch(teacherStatsProvider);
final statsData = statsAsync.asData?.value;
final students = statsData?['totalStudents'] as int? ?? 0;
```

**`statsAsync.asData?.value`** — Gets the `data` if available, returns null for loading/error → defaults to 0. This means the chips show "0 Students" while loading, then update when data arrives. No loading indicator in the banner — it just renders 0s.

**Pending Reviews chip:**
```dart
if (pending > 0)
  _BannerChip(
    icon: FeatherIcons.alertCircle,
    label: '$pending Pending Reviews',
    isUrgent: true,
  ),
```
The "Pending Reviews" chip is conditionally shown and styled in red — only appears when there are ungraded submissions. Teachers see the urgency at a glance.

**Banner gradient:** `LinearGradient([purple → violet → blue])` — distinct from the student banner (blue/teal gradient) to visually differentiate the two roles.

---

## 4. `teacherStatsProvider` — API Data Binding

```dart
ref.watch(teacherStatsProvider).when(
  loading: () => SizedBox(height: 120, child: CircularProgressIndicator()),
  error: (_, __) => const SizedBox.shrink(),
  data: (stats) {
    final students = stats['totalStudents'] as int? ?? 0;
    final liveStats = [
      _TeacherStat(label: 'Total Students', value: '$students', ...),
      _TeacherStat(label: 'Pending Reviews', value: '$pending', ...),
      _TeacherStat(label: 'Active Projects', value: '$projects', ...),
      _TeacherStat(label: 'My Subjects', value: '$subjects', ...),
    ];
    return _StatGrid(stats: liveStats);
  },
),
```

Stats come from `GET /api/teacher/stats` (via `teacherStatsProvider`). The four stat cards are built dynamically from API data — not hardcoded. `error: SizedBox.shrink()` silently hides the section on error.

---

## 5. Quick Actions — String-Based Action Router

```dart
void _handleTap(BuildContext context) {
  final a = widget.action;
  if (a.label == 'New Assignment') {
    showDialog(context: context, builder: (_) => const TeacherCreateAssignmentDialog());
  } else if (a.label == 'Announcement') {
    showDialog(context: context, builder: (_) => const TeacherPostAnnouncementDialog());
  } else if (a.label == 'Grade Work') {
    widget.ref.read(navigationProvider.notifier).navigateTo(2);
  } else if (a.label == 'Schedule') {
    widget.ref.read(navigationProvider.notifier).navigateTo(3);
  }
}
```

**String-based routing** — Action is identified by its `label` string. This is fragile (if the label changes, the action breaks). A better approach would be an `ActionType` enum.

**Two routing modes:**
1. `showDialog` — Opens a floating dialog (New Assignment, Announcement)
2. `navigateTo(index)` — Changes the sidebar navigation index (Grade Work → Projects, Schedule → Calendar)

---

## 6. Managed Subjects Section

```dart
studentCount: 0,
pendingSubmissions: 0,
avgProgress: 0.5,
```

⚠️ **Hardcoded values** — The subject cards display `0 students`, `0 submissions`, and 50% progress for every subject. The API data (`channelsProvider`) doesn't return per-channel statistics. Full implementation would require a separate endpoint or query enhancement.

**Left border accent:**
```dart
decoration: BoxDecoration(
  border: Border(left: BorderSide(color: widget.color, width: 4)),
),
```
Each subject card has a 4px colored left border — a visual pattern for categorizing channels.

---

## 7. `_SubjectManagementCard` — Animated Progress Bar

Same staggered animation as `_SubjectProgressRow` in `TodayOverviewWidget`:
- `AnimationController` (900ms, `easeOutCubic`)
- `Future.delayed(150ms)` start for stagger effect

---

## 8. Responsive Quick Actions Grid

```dart
if (isMobile) {
  // 2×2 grid on mobile
  for (int row = 0; row < 2; row++) Row([actions[row*2], actions[row*2+1]])
} else {
  // Desktop: single row of 4
  Row(children: actions.map(...).toList())
}
```

On mobile: manual 2×2 grid using nested `Row` + `Column`. On desktop: single horizontal `Row` of 4 cards with `Expanded` spacing.

---

## 9. Final Summary

`TeacherOverviewWidget` mirrors the student dashboard architecture but is faculty-specific. Key architectural choices: `statsAsync.asData?.value` for non-blocking stat display in the banner, string-based quick action routing (refactor candidate), and hardcoded subject stats (incomplete feature). The consistent `AnimationController` + `FadeTransition` + `SlideTransition` pattern makes both dashboards feel cohesive.
