# 📄 `widgets/subjects_view_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/subjects_view_widget.dart`
**Lines:** 321
**Role:** Grid of subject (channel) cards with hover effects, responsive column count, and navigation to `SubjectHubSheet`.

---

## 1. File Purpose

Displays the student's enrolled channels (subjects) as interactive cards in a responsive grid. Tapping any card opens `SubjectHubSheet` — the channel's full content hub — as a bottom sheet.

---

## 2. Responsive Grid Layout

```dart
LayoutBuilder(
  builder: (ctx, constraints) {
    final cols = constraints.maxWidth > 900 ? 3 : 2;
    final ratio = isMobile ? 2.1 : 1.75;
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: cols,
        crossAxisSpacing: isMobile ? 10 : 20,
        mainAxisSpacing: isMobile ? 10 : 20,
        childAspectRatio: ratio,
      ),
```

**`crossAxisCount`:** 3 columns on desktop (>900px), 2 on tablet and mobile.

**`childAspectRatio`:** Controls card height. `2.1` on mobile = each card is 2.1× wider than tall (shorter cards). `1.75` on desktop = slightly taller cards.

**`shrinkWrap: true` + `NeverScrollableScrollPhysics()`:** The GridView is inside a `SingleChildScrollView`. It must use `shrinkWrap` (size to content, not infinite height) and disable its own scroll so the parent scrolls.

**`index % _palette.length`:** Each card gets a color from the 7-color palette cycling by index. Cards 0, 7, 14 get the same color.

---

## 3. `_SubjectCard` — Hover + Navigation

```dart
onTap: () {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => SubjectHubSheet(channel: widget.channel, color: widget.color),
  );
},
```

Tapping opens `SubjectHubSheet` as a modal bottom sheet. `isScrollControlled: true` allows it to be full-height (takes 90% of screen by default via internal `DraggableScrollableSheet`).

**Hover effects** (via `MouseRegion`):
- Background: transparent → 7% tinted with subject color
- Border: grey → 50% tinted color
- Shadow: none → colored drop shadow (18% opacity, 18px blur)

---

## 4. Data Sources

- `channelsProvider` → `GET /api/channels/me` (returns enrolled channels for students, all channels for admins)
- Each channel card shows: subject name, teacher name, semester badge

**`ch.subjectName.isNotEmpty ? ch.subjectName : ch.channelName`** — Falls back to `channelName` if `subjectName` is empty (old channels pre-migration may not have `subjectName`).

---

## 5. Final Summary

`SubjectsViewWidget` is a clean grid view with responsive layout, consistent color theming, and hover interactivity. The `showModalBottomSheet` navigation keeps the subject hub within the existing route without a full page push.

---

# 📄 `widgets/projects_view_widget.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/projects_view_widget.dart`
**Lines:** 445
**Role:** Project list with progress bars, member avatars (stacked overlap), deadline coloring, and navigation to `ProjectDetailScreen`.

---

## 1. File Purpose

Displays all projects the user is a member of. Each card shows: title, description, deadline, progress bar, member avatars, and a "View Details" button. Creates new projects via `CreateProjectDialog`.

---

## 2. `projectsProvider` Data Source

```dart
final projectsAsync = ref.watch(projectsProvider);
```

`projectsProvider` calls `GET /api/projects` → returns projects with aggregated `members` array (names and IDs from `array_agg`).

---

## 3. Data Extraction from `Map<String, dynamic>`

```dart
final title = p['title'] as String? ?? 'Untitled';
final progress = ((p['progress'] as num?) ?? 0) / 100.0;
final deadlineRaw = p['deadline'] as String?;
final deadline = deadlineRaw != null ? DateTime.tryParse(deadlineRaw) : null;
final members = (p['members'] as List<dynamic>?)
    ?.map((m) => (m['name'] ?? m['roll_number'] ?? '?').toString())
    .toList() ?? [];
```

**Note:** `_ProjectCard` uses `Map<String, dynamic>` directly (raw API data) rather than a typed model. This is a slight inconsistency — other views use typed models.

**`progress / 100.0`** — DB stores progress as 0-100 integer; `LinearProgressIndicator` expects 0.0-1.0.

**Members extraction:** `m['name'] ?? m['roll_number'] ?? '?'` — Tries name first, falls back to roll number, then `?` as last resort.

---

## 4. Overlapping Member Avatars

```dart
for (int i = 0; i < members.take(4).length; i++)
  Align(
    widthFactor: 0.65,
    child: CircleAvatar(
      radius: 14,
      backgroundColor: AppColors.getSurfaceColor(context),
      child: CircleAvatar(radius: 12, ...),
    ),
  ),
```

**`widthFactor: 0.65`** — Each `Align` takes only 65% of its child's width, causing each avatar to overlap the previous by 35%. Creates the "stacked avatars" effect seen on GitHub/Jira.

**Double `CircleAvatar`** — The outer avatar (radius 14) has the surface color background — creates a white/dark border ring around the inner avatar (radius 12) with the colored background and letter.

**`take(4)`** — Shows max 4 avatars.

**`+${members.length - 4} more`** — Shows overflow count if more than 4 members.

---

## 5. Deadline Color

```dart
color: deadline.isBefore(DateTime.now()) ? Colors.red.shade400 : AppColors.getHeadingColor(context)
```

Past deadline → red text. Future deadline → normal color.

---

## 6. `ProjectModel` Construction

```dart
final projectModel = ProjectModel(
  id: id.toString(),
  title: title,
  teamMembers: members,
  progress: progress,
  deadline: deadline ?? DateTime.now().add(const Duration(days: 30)),
  description: description,
  color: color,
);
```

Converts the raw `Map` into a typed `ProjectModel` for passing to `ProjectDetailScreen`. The `deadline ?? DateTime.now().add(...)` fallback prevents null deadline issues.

---

## 7. Final Summary

`ProjectsViewWidget` demonstrates the overlapping avatar technique using `Align(widthFactor: 0.65)`, deadline urgency coloring, progress bar with `AlwaysStoppedAnimation<Color>`, and the `Map<String, dynamic>` → typed model bridge pattern. The card hover effect is consistent with the `SubjectsViewWidget` pattern.
