# 📄 `widgets/notification_panel.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/notification_panel.dart`
**Lines:** 285
**Role:** The floating notification inbox shown when the bell icon is tapped — lists notifications with read/unread states, mark-read actions, and manual refresh.

---

## 1. File Purpose

`NotificationPanel` is the dropdown panel that appears when the user taps the notification bell in `TopBarWidget`. It renders inside an `OverlayEntry` (managed by `TopBarWidget`), not as a route.

---

## 2. State Watching

```dart
final notificationsAsync = ref.watch(notificationsApiProvider);
```

`notificationsApiProvider` — An `AsyncNotifierProvider` that calls `GET /api/notifications`. The panel subscribes to it and rebuilds on every refetch.

---

## 3. Panel Structure

- **Fixed dimensions:** `width: 360, maxHeight: 520` — capped so the panel doesn't overflow the screen
- **`Flexible` child** — The notification list can scroll inside the constrained height

---

## 4. Refresh Button

```dart
IconButton(
  icon: Icon(FeatherIcons.refreshCw, ...),
  onPressed: () => ref.invalidate(notificationsApiProvider),
),
```

`ref.invalidate(notificationsApiProvider)` — Forces the provider to re-fetch from the API. The panel goes to `AsyncLoading` state briefly then shows fresh data.

---

## 5. "Mark All Read" Button

```dart
notificationsAsync.whenOrNull(
  data: (list) => list.isNotEmpty
    ? TextButton(
        onPressed: () async {
          await ApiService().dio.patch('/notifications/read-all');
          ref.invalidate(notificationsApiProvider);
        },
        child: Text('Mark all read'),
      )
    : null,
) ?? const SizedBox.shrink()
```

**Direct Dio call** — `ApiService().dio.patch(...)` bypasses the repository layer. This is a quick one-off API call; since `notificationsApiProvider` is invalidated afterward, the panel refreshes to show all notifications as read.

**`?? const SizedBox.shrink()`** — If `whenOrNull` returns null (loading/error state), an invisible widget is shown instead.

---

## 6. Notification Item Rendering

```dart
final isRead = n['is_read'] as bool? ?? false;
...
color: isRead ? Colors.transparent : AppColors.accent.withValues(alpha: 0.04),
```

Unread notifications have a very subtle blue background (4% opacity) — enough to distinguish them from read notifications without being distracting.

**Unread indicator:**
```dart
if (!isRead)
  Container(width: 7, height: 7, decoration: BoxDecoration(color: AppColors.accent, shape: BoxShape.circle))
```
A 7×7 blue dot next to unread notification titles.

**Date formatting:**
```dart
DateFormat('MMM d, h:mm a').format(timestamp)
```
Example: "May 22, 3:45 PM" — human-readable notification time.

**`DateTime.tryParse`** — Safe parse that returns null if the string isn't a valid ISO date (instead of throwing).

---

## 7. Mark-as-Read Action

```dart
IconButton(
  onPressed: () async {
    await ApiService().markNotificationRead(id);
    ref.invalidate(notificationsApiProvider);
  },
),
```

Calls `PATCH /api/notifications/:id/read` then refreshes the entire list. Only shown for unread notifications (`if (!isRead)`).

---

## 8. State Variants

| State | Rendered |
|---|---|
| Loading | Centered `CircularProgressIndicator` |
| Error | Icon + error message + Retry button |
| Empty | "All caught up!" with `bellOff` icon |
| Has notifications | `ListView` of notification items |

---

## 9. Final Summary

`NotificationPanel` uses the standard `AsyncValue.when()` pattern for all states, `ref.invalidate()` for cache busting, and direct Dio calls for simple one-off mutations. The 4% opacity unread background and 7px blue dot are subtle but effective read-state indicators.

---

# 📄 `widgets/announcements_panel.dart` — Complete Explanation

**File Path:** `frontend/lib/.../widgets/announcements_panel.dart`
**Lines:** 332
**Role:** Dashboard announcements feed with real-time socket listener and role-specific empty state messages.

---

## 1. File Purpose

`AnnouncementsPanel` shows the most recent announcements from the user's channels on the home dashboard. It subscribes to real-time socket events so new announcements appear instantly without manual refresh.

---

## 2. `initState()` — Race Condition Prevention

```dart
@override
void initState() {
  super.initState();
  
  WidgetsBinding.instance.addPostFrameCallback((_) {
    if (!mounted) return;
    ref.read(authProvider).whenData((auth) {
      ref.invalidate(dashboardRecentActivityProvider(auth.isFaculty));
    });
  });
```

**`addPostFrameCallback`** — Runs AFTER the first frame is rendered. This is important because:
1. During `initState()`, Riverpod providers may not be fully initialized
2. Calling `ref.invalidate()` during `initState()` can cause rebuild loops

**`whenData`** — Only invalidates if auth is in the `data` state (authenticated). During auth loading, `isFaculty` defaults to `false`, which would invalidate the wrong provider variant.

**Why invalidate at all?** To ensure fresh announcements every time the dashboard panel mounts (e.g., after navigation away and back).

---

## 3. Real-Time Socket Listener

```dart
SocketService().onNewAnnouncement((_) {
  if (!mounted) return;
  final isFaculty = ref.read(authProvider).value?.isFaculty ?? false;
  ref.invalidate(dashboardRecentActivityProvider(isFaculty));
});
```

**`onNewAnnouncement`** — Registers a listener for the `'announcement:new'` Socket.IO event emitted by `announcementController.js` when a teacher posts.

**Effect:** When a teacher posts an announcement, the backend emits `announcement:new` to all connected channel members. This listener fires, `invalidates` the provider, which triggers a re-fetch of `GET /api/teacher/recent-activity` (or student equivalent). The new announcement appears in the panel without any user action.

---

## 4. Socket Cleanup

```dart
@override
void dispose() {
  SocketService().off('announcement:new');
  super.dispose();
}
```

**Critical:** Removes the socket listener when the widget is removed from the tree. Without this, the listener would accumulate (memory leak) every time the dashboard is navigated to.

---

## 5. Provider Parameterization

```dart
final activityAsync = ref.watch(dashboardRecentActivityProvider(isFaculty));
```

`dashboardRecentActivityProvider` is a **family provider** (parameterized). 
- `dashboardRecentActivityProvider(true)` → calls `GET /api/teacher/recent-activity`
- `dashboardRecentActivityProvider(false)` → calls `GET /api/student/recent-activity`

The correct endpoint is chosen at runtime based on the user's role.

---

## 6. `_AnnouncementItem` — Time Ago + Color Hash

**Color hash from sender name:**
```dart
final colorIndex = sender.isNotEmpty ? sender.codeUnitAt(0) % _colors.length : 0;
final color = isImportant ? Colors.orange : _colors[colorIndex];
```
- `sender.codeUnitAt(0)` — Unicode code of the first character of the sender's name
- `% _colors.length` — Maps to a palette index
- Same sender always gets same color (like `SubjectColorManager` but for names)
- Important announcements override the color to orange

**`_formatTimeAgo`:**
```dart
if (diff.inMinutes < 1) return 'Just now';
if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
if (diff.inHours < 24) return '${diff.inHours}h ago';
if (diff.inDays < 7) return '${diff.inDays}d ago';
return DateFormat('MMM d').format(dt.toLocal());
```
Progressive time formatting: "Just now" → "5m ago" → "3h ago" → "2d ago" → "May 15".

**`.toLocal()`** — Converts the UTC timestamp from the DB to the device's local timezone.

---

## 7. Final Summary

`AnnouncementsPanel` demonstrates the `addPostFrameCallback` safety pattern for `initState` provider operations, socket listener lifecycle management, and family provider parameterization. The real-time update flow (socket → invalidate → re-fetch → rebuild) is the gold standard for Riverpod + Socket.IO integration.
