# 📄 `core/services/api_service.dart` — Complete Explanation

**File Path:** `frontend/lib/core/services/api_service.dart`
**Lines:** ~200
**Role:** The single Dio HTTP client singleton for all REST API communication between the Flutter frontend and the Node.js backend.

---

## 1. 📌 File Purpose

`ApiService` is the **network gateway** of the entire Flutter frontend. Every HTTP request to the backend passes through this class. It:
- Maintains a single Dio client (HTTP library) instance
- Auto-attaches the JWT Bearer token to every request
- Maps every backend endpoint to a named Dart method
- Handles Dio configuration (base URL, timeouts)

> **Beginner Analogy:** `ApiService` is like a phone operator in a corporation. All external calls go through them. They know the exact extension number (endpoint) for every department (feature), and they automatically introduce you (attach your auth token) before connecting every call.

---

## 2. 🏗️ Singleton Pattern

```dart
class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal() {
    _setupDio();
  }
```

| Line | Purpose |
|---|---|
| `static final _instance` | Single shared instance stored as a class-level variable |
| `factory ApiService() => _instance` | Every `ApiService()` call returns the SAME instance |
| `ApiService._internal()` | Private constructor — can't be called from outside; runs `_setupDio()` once |

**Why singleton?** HTTP clients maintain connection pools. Creating one per request wastes connections. One shared instance reuses connections efficiently.

---

## 3. ⚙️ Dio Setup — `_setupDio()` Line-by-Line

```dart
void _setupDio() {
  _dio = Dio(BaseOptions(
    baseUrl: AppConfig.baseUrl,
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 30),
    headers: {'Content-Type': 'application/json'},
  ));
```

| Option | Value | Why |
|---|---|---|
| `baseUrl` | `http://localhost:5000` or Render URL | All relative paths are appended to this |
| `connectTimeout: 10s` | Max time to establish TCP connection | Prevents hanging forever on unreachable server |
| `receiveTimeout: 30s` | Max time to receive full response | Allows for slow DB queries up to 30s |
| `Content-Type: application/json` | Default header | Backend's `express.json()` parses this |

### Dio Interceptor — Auto Auth Token Injection

```dart
_dio.interceptors.add(
  InterceptorsWrapper(
    onRequest: (options, handler) async {
      final token = await StorageService().read('adtu_token');
      if (token != null) {
        options.headers['Authorization'] = 'Bearer $token';
      }
      handler.next(options);
    },
  ),
);
```

**Line-by-Line:**
- `interceptors.add(...)` — Registers a middleware that runs before every request.
- `onRequest: (options, handler) async {...}` — Called before each outgoing request.
- `StorageService().read('adtu_token')` — Reads the JWT from secure storage (FlutterSecureStorage on mobile, SharedPreferences on web).
- `options.headers['Authorization'] = 'Bearer $token'` — Injects the token as a Bearer header. The backend's `protect` middleware expects exactly this format.
- `handler.next(options)` — Passes the modified request to Dio for execution.

**Why interceptor instead of manual header?**
Without the interceptor, every API method would need:
```dart
final token = await StorageService().read('adtu_token');
final response = await _dio.get('/channels', options: Options(headers: {'Authorization': 'Bearer $token'}));
```
The interceptor does this automatically for every single request, keeping all method code clean.

---

## 4. 🗺️ Complete API Method Map

### Authentication
```dart
Future<Response> login(String identifier, String password) =>
    _dio.post('/auth/login', data: {'identifier': identifier, 'password': password});

Future<Response> signup(Map<String, dynamic> data) =>
    _dio.post('/auth/register', data: data);

Future<Response> getMe() => _dio.get('/auth/me');
```

### Channels (Subjects)
```dart
Future<Response> getChannels()           => _dio.get('/channels');
Future<Response> getChannelById(int id)  => _dio.get('/channels/$id');
Future<Response> getChannelMembers(int id) => _dio.get('/channels/$id/members');
```

### Messages
```dart
Future<Response> getMessages(int channelId, {int? cursor, int limit = 50}) {
  final params = <String, dynamic>{'limit': limit};
  if (cursor != null) params['cursor'] = cursor;
  return _dio.get('/channels/$channelId/messages', queryParameters: params);
}

Future<Response> sendFileMessage(int channelId, FormData formData) =>
    _dio.post('/channels/$channelId/messages', data: formData);

Future<Response> deleteMessage(int channelId, int msgId) =>
    _dio.delete('/channels/$channelId/messages/$msgId');
```

**`getMessages` with cursor pagination:**
- `cursor` is optional — omit for first load, provide oldest message ID for "load more"
- Query params are built dynamically — `cursor` is only added if provided

### Assignments & Submissions
```dart
Future<Response> getAssignments(int channelId) =>
    _dio.get('/channels/$channelId/assignments');

Future<Response> submitAssignment(int channelId, int assignId, FormData data) =>
    _dio.post('/channels/$channelId/assignments/$assignId/submit', data: data);

Future<Response> getSubmissions(int channelId, int assignId) =>
    _dio.get('/channels/$channelId/assignments/$assignId/submissions');

Future<Response> gradeSubmission(int channelId, int assignId, int subId, Map data) =>
    _dio.put('/channels/$channelId/assignments/$assignId/submissions/$subId/grade', data: data);
```

### Announcements
```dart
Future<Response> getAnnouncements(int channelId) =>
    _dio.get('/channels/$channelId/announcements');

Future<Response> createAnnouncement(int channelId, Map<String, dynamic> data) =>
    _dio.post('/channels/$channelId/announcements', data: data);
```

### Notifications
```dart
Future<Response> getNotifications() => _dio.get('/notifications');
Future<Response> markNotificationRead(int id) => _dio.put('/notifications/$id/read');
Future<Response> markAllNotificationsRead() => _dio.put('/notifications/read-all');
```

### Projects & Tasks
```dart
Future<Response> getProjects()                     => _dio.get('/projects');
Future<Response> getProject(int id)                => _dio.get('/projects/$id');
Future<Response> createProject(Map data)           => _dio.post('/projects', data: data);
Future<Response> deleteProject(int id)             => _dio.delete('/projects/$id');
Future<Response> createProjectTask(int pId, Map d) => _dio.post('/projects/$pId/tasks', data: d);
Future<Response> updateProjectTaskStatus(int pId, int tId, String status) =>
    _dio.patch('/projects/$pId/tasks/$tId/status', data: {'status': status});
```

### Teacher Dashboard
```dart
Future<Response> getTeacherStats()           => _dio.get('/teacher/stats');
Future<Response> getTeacherRecentActivity()  => _dio.get('/teacher/recent-activity');
Future<Response> getStudentRecentActivity()  => _dio.get('/teacher/student-activity');
```

### Academic Calendar
```dart
Future<Response> getAcademicEvents({int? year, int? month, String? type}) {
  final params = <String, dynamic>{};
  if (year != null)  params['year'] = year;
  if (month != null) params['month'] = month;
  if (type != null)  params['type'] = type;
  return _dio.get('/academic-events', queryParameters: params);
}
```

### File Download Proxy
```dart
Future<String?> getProxiedDownloadUrl(String fileUrl) async {
  final token = await StorageService().read('adtu_token');
  if (token == null) return null;
  final encoded = Uri.encodeComponent(fileUrl);
  return '${AppConfig.baseUrl}/api/file-proxy?url=$encoded&token=$token';
}
```

This method constructs a URL to the backend's file proxy endpoint. The JWT is passed as a query parameter (not a header) because `window.open()` can't set custom headers — the download is triggered by navigating the browser.

---

## 5. 📤 Exposed `dio` Getter

```dart
Dio get dio => _dio;
```

Exposes the raw Dio instance for advanced use cases (e.g., `authProvider` uses it for `PUT /auth/profile`). This is a slight leakage of internals but pragmatic.

---

## 6. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Token in URLs | Only for file proxy (short-lived token, no other option) |
| HTTPS in production | `AppConfig.baseUrl` points to HTTPS Render URL in production |
| Token storage | Uses `StorageService` which uses Keychain/Keystore on mobile |
| Request interceptor | Token added on every request automatically — no manual mistakes |

---

## 7. ⚡ Performance Considerations

| Feature | Benefit |
|---|---|
| Singleton Dio | Connection pool reuse — faster than creating new HTTP client per request |
| `connectTimeout: 10s` | User sees error instead of infinite loading on unreachable server |
| Interceptor token read | `StorageService().read()` is fast (in-memory cache in StorageService) |

---

## 8. 🐛 Possible Issues

1. **Token expiry during session** — No interceptor for 401 responses. When token expires, all API calls fail silently. Should add a `onError` interceptor that calls `AuthService.logout()` on 401.
2. **No retry logic** — Failed requests are not automatically retried (e.g., on network glitch).
3. **`dio` getter exposure** — Bypasses the interceptor if used incorrectly.

---

## 9. ✅ Final Summary

`ApiService` is the **most frequently used class in the entire Flutter codebase**. Every feature, every screen, every data load goes through it. Its singleton Dio client with an auth interceptor ensures token attachment is never forgotten, and the named method API provides a clean, self-documenting contract with the backend.
