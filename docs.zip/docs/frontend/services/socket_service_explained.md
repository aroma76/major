# 📄 `core/services/socket_service.dart` — Complete Explanation

**File Path:** `frontend/lib/core/services/socket_service.dart`
**Lines:** 114
**Role:** Flutter-side Socket.IO client — manages WebSocket connection, channel rooms, and real-time event listeners.

---

## 1. 📌 File Purpose

`SocketService` is the **Flutter real-time communication layer**. It:
- Creates and manages a single Socket.IO WebSocket connection
- Authenticates via JWT in the handshake
- Joins/leaves channel rooms for targeted message delivery
- Sends messages, typing indicators, and other events
- Listens for server-pushed events (new messages, notifications, announcements)

> **Beginner Analogy:** `SocketService` is like your smartphone's WhatsApp app. When you open WhatsApp (login), it connects to the server. When you open a group chat (joinChannel), you start receiving that group's messages. When you type, others see "typing..." (emitTypingStart). When someone sends a message, it appears instantly (onNewMessage callback).

---

## 2. 🏗️ Singleton Pattern

```dart
class SocketService {
  static final SocketService _instance = SocketService._internal();
  factory SocketService() => _instance;
  SocketService._internal();

  io.Socket? _socket;
  final _storage = StorageService();
```

- Single socket connection shared across the entire app.
- `_socket` is nullable — `null` when disconnected.
- `isConnected` getter: `_socket?.connected ?? false` — null-safe check.

---

## 3. 🔌 `connect()` — WebSocket Connection Setup

```dart
Future<void> connect() async {
  if (isConnected) return;
  final token = await _storage.read('adtu_token');

  _socket = io.io(
    AppConfig.baseUrl,
    io.OptionBuilder()
        .setTransports(['websocket'])
        .setAuth({'token': token ?? ''})
        .disableAutoConnect()
        .build(),
  );

  _socket!.connect();

  _socket!.onConnect((_) {
    debugPrint('✅ Socket connected: ${_socket!.id}');
  });

  _socket!.onDisconnect((_) {
    debugPrint('❌ Socket disconnected');
  });

  _socket!.onConnectError((data) {
    debugPrint('⚠️ Socket connect error: $data');
  });
}
```

### Line-by-Line:

**`if (isConnected) return;`**
- Guard clause: prevents double-connecting. Calling `connect()` multiple times (e.g., on widget rebuild) is safe.

**`final token = await _storage.read('adtu_token');`**
- Reads the stored JWT. This must happen before connecting because the token goes in the handshake.

**`io.io(AppConfig.baseUrl, io.OptionBuilder()...)`**
- Creates the socket client instance pointing to the backend server.
- `setTransports(['websocket'])` — Forces WebSocket transport. Disables long-polling fallback for efficiency.
- `setAuth({'token': token ?? ''})` — Sends the JWT in `socket.handshake.auth.token` — read by `socketHandler.js` on the server.
- `disableAutoConnect()` — Prevents the socket from connecting on creation; we manually call `.connect()` next.

**`_socket!.connect()`**
- Initiates the WebSocket handshake.

**Event handlers:**
- `onConnect` — Fires when connection is established. Logs the unique socket ID.
- `onDisconnect` — Fires when connection closes (network drop, server restart, logout).
- `onConnectError` — Fires when connection fails (wrong URL, server down, invalid token).

---

## 4. 🏠 Channel Room Management

```dart
void joinChannel(int channelId) {
  _socket?.emit('channel:join', channelId);
}

void leaveChannel(int channelId) {
  _socket?.emit('channel:leave', channelId);
}
```

- `_socket?.emit(...)` — The null-safe `?.` means nothing happens if socket is disconnected.
- Server's `socketHandler.js` receives `channel:join` and calls `socket.join('channel_42')`.
- After joining, the client receives all `message:new` events broadcast to `channel_42`.

---

## 5. 💬 `sendMessage()` — Text Message via WebSocket

```dart
void sendMessage({
  required int channelId,
  required String content,
  int? parentId,
}) {
  _socket?.emit('message:send', {
    'channelId': channelId,
    'content': content,
    if (parentId != null) 'parent_id': parentId,
  });
}
```

- Emits `message:send` to the server with the message payload.
- `if (parentId != null) 'parent_id': parentId` — Dart collection `if` syntax: only adds `parent_id` to the map if it's not null. Clean and readable.
- The server validates, saves to DB, and broadcasts back to the channel room.

---

## 6. ⌨️ Typing Indicators

```dart
void emitTypingStart(int channelId, String userName) {
  _socket?.emit('typing:start', {'channelId': channelId, 'userName': userName});
}

void emitTypingStop(int channelId) {
  _socket?.emit('typing:stop', {'channelId': channelId});
}
```

- Typing indicators are ephemeral — not saved to DB, just broadcast to current channel members.
- `userName` is sent so other users see "Rahul is typing..." by name.

---

## 7. 📥 Event Listeners — `onNewMessage()` Pattern

```dart
void onNewMessage(void Function(Map<String, dynamic>) callback) {
  _socket?.off('message:new');  // ← Remove previous listener first!
  _socket?.on('message:new', (data) => callback(Map<String, dynamic>.from(data)));
}
```

**The critical `off()` before `on()`:**
- Without `_socket?.off('message:new')` first, every time the `MessagesViewWidget` is rebuilt (e.g., screen rotation, state change), a **new listener is added** without removing the old one.
- After 5 rebuilds, you'd have 5 listeners, each firing on every message → 5 duplicate messages appear in the UI.
- The `off()` + `on()` pattern ensures exactly one active listener at all times.

**`Map<String, dynamic>.from(data)`:**
- Socket.IO's Dart client passes event data as a loosely-typed `dynamic`. 
- `Map<String, dynamic>.from(data)` creates a properly typed Dart Map from the dynamic object.

---

## 8. 📢 Other Event Listeners

```dart
void onNewNotification(void Function(Map<String, dynamic>) callback) {
  _socket?.off('notification:new');
  _socket?.on('notification:new',
      (data) => callback(Map<String, dynamic>.from(data)));
}

void onNewAnnouncement(void Function(Map<String, dynamic>) callback) {
  _socket?.off('announcement:new');
  _socket?.on('announcement:new',
      (data) => callback(Map<String, dynamic>.from(data)));
}
```

Same pattern as `onNewMessage`. Used in:
- `TopBarWidget` — Updates notification badge count on `notification:new`.
- `TodayOverviewWidget` / `AnnouncementsPanel` — Adds new announcements to the list on `announcement:new`.

---

## 9. 🔌 `disconnect()` — Full Cleanup

```dart
void disconnect() {
  _socket?.disconnect();
  _socket = null;
}
```

- Called by `AuthService.logout()`.
- `_socket = null` — Ensures subsequent `?.` calls do nothing.
- All listeners are implicitly removed when the socket is destroyed.

---

## 10. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Unauthenticated WebSocket | Token in handshake.auth — server verifies JWT before allowing any events |
| Message spoofing | Server uses `socket.user.id` (server-verified) — ignores any sender ID in payload |
| Duplicate listeners | `off()` before `on()` prevents listener stacking |
| Post-logout socket | `disconnect()` called in `AuthService.logout()` |

---

## 11. ⚡ Performance Considerations

- **Single WebSocket connection** for all features — much more efficient than one connection per feature.
- **No reconnection logic** — If the connection drops (mobile network switch), it doesn't automatically reconnect. Socket.IO has auto-reconnect configuration that could be enabled.
- **`setTransports(['websocket'])`** — Skips long-polling negotiation. Faster initial connection.

---

## 12. 🐛 Possible Issues

1. **No auto-reconnect** — Network interruption (e.g., going into a tunnel) causes permanent disconnect until the user manually refreshes.
2. **No room rejoin after reconnect** — Even if auto-reconnect were enabled, the server's room membership is lost on disconnect. Users would need to re-emit `channel:join`.
3. **`off()` removes ALL listeners for the event** — If two widgets both listen to `message:new`, one will silently kill the other's listener.

---

## 13. ✅ Final Summary

`SocketService` is a well-designed, focused class that wraps the complexity of WebSocket communication behind a clean, ergonomic API. The singleton pattern, JWT handshake, and `off()`-before-`on()` listener management show thoughtful architecture. The main production gap is the lack of auto-reconnection handling, which would be important for mobile users on spotty connections.
