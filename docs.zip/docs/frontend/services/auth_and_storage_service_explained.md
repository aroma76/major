# 📄 `core/services/auth_service.dart` — Complete Explanation

**File Path:** `frontend/lib/core/services/auth_service.dart`
**Lines:** 77
**Role:** The session management layer that coordinates login, signup, session restoration, and logout across the app.

---

## 1. 📌 File Purpose

`AuthService` is the **session orchestrator**. It sits between `AuthNotifier` (the Riverpod state) and the lower-level `ApiService` (HTTP) and `StorageService` (token persistence). It handles:
- Login → calls API → saves token → caches user object
- Signup → calls API → saves token → caches user object
- Session restoration → reads stored token → verifies with backend
- Logout → clears token → disconnects socket

> **Beginner Analogy:** `AuthService` is the hotel front desk. When you check in (login), they verify your identity, give you a key card (token), and note your room number (user object). When you check out (logout), they take back your key and disable it. If you come back the next day with your key card (restore session), they check it's still valid.

---

## 2. 🏗️ Singleton Pattern

```dart
class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final _storage = StorageService();
  final _api = ApiService();
```

- Single instance shared across the app.
- Holds singleton references to `StorageService` and `ApiService` — they're also singletons, so this is redundant but harmless.

---

## 3. 👤 In-Memory User Cache

```dart
Map<String, dynamic>? _currentUser;
Map<String, dynamic>? get currentUser => _currentUser;
```

- `_currentUser` — The most recently authenticated user's data (from backend response).
- Kept in memory for the lifetime of the app session.
- `AuthNotifier` reads this via `_auth.currentUser` after login.
- **Why not just use the JWT payload?** The JWT might not have all fields (e.g., `programme_id`, `roll_number`). The `/auth/me` response has complete user data.

---

## 4. 🔓 `login()` — Line-by-Line

```dart
Future<Map<String, dynamic>> login(String identifier, String password) async {
  final response = await _api.login(identifier, password);
  final data = response.data as Map<String, dynamic>;
  final token = data['token'] as String;
  _currentUser = data['user'] as Map<String, dynamic>;
  await _storage.write('adtu_token', token);
  return _currentUser!;
}
```

| Line | What It Does |
|---|---|
| `await _api.login(...)` | POST `/auth/login` → returns `{ token, user }` |
| `data['token'] as String` | Extracts the JWT string |
| `_currentUser = data['user']` | Caches the user object in memory |
| `await _storage.write('adtu_token', token)` | Persists JWT to secure storage for session restore |
| `return _currentUser!` | Returns user data to `AuthNotifier` |

**Why write to storage before returning?**
If `_storage.write()` fails (e.g., storage is full), the error propagates up before `_currentUser` is returned. This prevents the app from thinking login succeeded when the token wasn't actually saved.

---

## 5. 📝 `signup()` — Line-by-Line

```dart
Future<Map<String, dynamic>> signup({
  required String name,
  required String email,
  required String rollNumber,
  required String dob,
  required int programmeId,
  required int batchYear,
  required int currentSemester,
}) async {
  final response = await _api.signup({
    'name': name,
    'email': email,
    'roll_number': rollNumber,
    'dob': dob,
    'programme_id': programmeId,
    'batch_year': batchYear,
    'current_semester': currentSemester,
    'role': 'student',  // ← hardcoded, mirrors backend security
  });
```

- Named parameters make the call site readable: `signup(name: 'Rahul', email: '...')`.
- `'role': 'student'` — Even if the backend ignores this (it hardcodes to 'student'), sending it is explicit intent.
- The flow after the API call is identical to `login()` — saves token, caches user, returns user.

---

## 6. 🔄 `restoreSession()` — App Startup Logic

```dart
Future<bool> restoreSession() async {
  final token = await _storage.read('adtu_token');
  if (token == null) return false;
  try {
    final response = await _api.getMe();
    _currentUser = (response.data as Map<String, dynamic>)['user'];
    return true;
  } catch (_) {
    await logout();
    return false;
  }
}
```

**Line-by-Line:**
- `await _storage.read('adtu_token')` — Tries to find a saved JWT. Returns `null` if not logged in or token was deleted.
- `if (token == null) return false` — Fast path: no token = no session = go to login screen.
- `await _api.getMe()` — Calls GET `/auth/me`. Because the Dio interceptor auto-attaches the stored token, this call is authenticated. The backend verifies the JWT and returns the current user.
- `_currentUser = response.data['user']` — Refreshes the in-memory user data from the backend (catches role changes, profile updates, etc.).
- `catch (_) { await logout(); return false; }` — If `/auth/me` fails (expired token, user deleted, network error), calls `logout()` to clean up the stored token, then returns `false` (redirect to login).

**Why call `/auth/me` instead of just decoding the stored JWT?**
1. The token might have **expired** — JWT expiry is enforced server-side.
2. The user's **role might have changed** — Only fresh `/auth/me` data reflects that.
3. The user account might have been **deleted** — JWT would still be locally valid.

This is the **"verify on startup"** pattern — never trust stored credentials without re-verification.

---

## 7. 🚪 `logout()` — Full Cleanup

```dart
Future<void> logout() async {
  _currentUser = null;
  // Disconnect the socket so the old JWT connection is fully closed
  // before a new user logs in and creates a fresh authenticated connection.
  SocketService().disconnect();
  await _storage.delete('adtu_token');
}
```

**Three-step cleanup:**
1. `_currentUser = null` — Clears in-memory user data immediately.
2. `SocketService().disconnect()` — Closes the WebSocket connection. Without this, the old user's socket would remain connected. When a new user logs in, they'd get a fresh socket with the new JWT.
3. `await _storage.delete('adtu_token')` — Removes JWT from secure storage. Next `restoreSession()` call returns `false`.

**Why disconnect socket before deleting token?**
The comment in the code explains it: preventing the scenario where the old authenticated socket lingers after logout, which could receive messages intended for the previous user.

---

## 8. ✅ `isLoggedIn` Getter

```dart
bool get isLoggedIn => _currentUser != null;
```

A quick in-memory check — doesn't verify the token's validity, just whether a user object is cached.

---

## 9. 🔒 Security Considerations

| Risk | Mitigation |
|---|---|
| Token replay after logout | `_storage.delete()` removes token; `restoreSession()` returns false |
| Session stealing | Token stored in Keychain/Keystore (mobile) — OS-level security |
| Expired token usage | `restoreSession()` calls `/auth/me` — backend rejects expired tokens |
| Socket session leakage | `SocketService().disconnect()` called on logout |

---

## 10. ✅ Final Summary

`AuthService` is the **thin but crucial glue** between network auth (API), state management (AuthNotifier), and persistence (StorageService). Its three-way coordination — API call + token storage + socket lifecycle — is what makes the authentication feel seamless to the user. The `restoreSession()` pattern is particularly well-designed: it trusts the server, not the client-side token, for session validity.

---

# 📄 `core/services/storage_service.dart` — Complete Explanation

**File Path:** `frontend/lib/core/services/storage_service.dart`
**Lines:** 49
**Role:** Cross-platform token storage — FlutterSecureStorage on mobile, SharedPreferences on web.

---

## 1. 📌 File Purpose

Flutter apps run on multiple platforms. Token storage works differently per platform:
- **Android** — Android Keystore (hardware-backed encryption)
- **iOS** — Keychain Services (Apple's secure enclave)
- **Web** — `localStorage` (JavaScript, no hardware security)

`StorageService` abstracts all this behind three simple methods: `write`, `read`, `delete`.

---

## 2. 🔑 Platform Detection

```dart
Future<void> write(String key, String value) async {
  if (kIsWeb) {
    final prefs = await _getPrefs();
    await prefs.setString(key, value);
  } else {
    await _secure.write(key: key, value: value);
  }
}
```

- `kIsWeb` — Flutter's built-in compile-time constant. `true` on web, `false` on mobile.
- Web: `SharedPreferences` → stores in browser `localStorage`.
- Mobile: `FlutterSecureStorage` → stores in OS secure keystore.

**Why not use `FlutterSecureStorage` on web?**
`FlutterSecureStorage` doesn't support web. The web implementation would either fail or fall back to `localStorage` anyway.

---

## 3. 💾 SharedPreferences Caching

```dart
SharedPreferences? _prefs;

Future<SharedPreferences> _getPrefs() async {
  _prefs ??= await SharedPreferences.getInstance();
  return _prefs!;
}
```

- `_prefs ??= ...` — The null-aware assignment operator: only calls `getInstance()` on the first invocation; subsequent calls return the cached `_prefs`.
- `SharedPreferences.getInstance()` is an async call that loads from disk. Caching avoids repeated disk reads on every storage access.

---

## 4. 🔒 Security Note

| Platform | Storage | Security Level |
|---|---|---|
| Android | Android Keystore | Hardware encryption, survives root |
| iOS | Keychain | Hardware encryption (Secure Enclave on newer devices) |
| Web | localStorage | JavaScript-accessible, vulnerable to XSS |

The web token storage has lower security. A malicious script with XSS access could read the token from `localStorage`. For a university internal app, this is acceptable, but for a banking app it would require `httpOnly` cookies instead.
