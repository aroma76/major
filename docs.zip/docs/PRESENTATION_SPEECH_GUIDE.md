# EduSync — Viva Presentation Guide & Speech Script

> A structured guide for presenting the EduSync major project to faculty examiners.  
> Read through this fully before the viva. Use the scripts as a base — adapt them to sound natural.

---

## 📌 Quick Reference Card (Memorize These)

| Question | Answer |
|---|---|
| **Project Name** | EduSync — Academic Workspace & Collaboration Portal |
| **Frontend** | Flutter (Dart) — compiles to Web, Android, iOS, Desktop |
| **Backend** | Node.js + Express.js REST API |
| **Database** | PostgreSQL (hosted on Neon — serverless) |
| **Real-time** | Socket.IO WebSockets |
| **File Storage** | Supabase Storage (CDN) |
| **Frontend Hosting** | Vercel (global CDN) |
| **Backend Hosting** | Render.com |
| **Authentication** | JWT (JSON Web Tokens) + bcrypt password hashing |
| **Live URL** | https://major-three-tau.vercel.app |

---

## 🎤 Part 1 — Opening Introduction (2–3 minutes)

### What to Say:

> "Good morning/afternoon sir/ma'am. Our major project is **EduSync** — a real-time academic collaboration platform designed specifically for Assam down town University.
>
> The core problem we addressed is **fragmentation** — students and faculty currently use multiple disconnected tools: WhatsApp groups for communication, Google Classroom or email for assignments, separate portals for results, and no structured way to collaborate on projects. There's no single place where a student's entire academic life is organized.
>
> EduSync solves this by providing a **unified workspace** — organized by subjects, where every channel contains chat, assignments, notes, files, and announcements together in one place. Think of it as **Jira or Slack, but built specifically for university academics.**
>
> The application runs as a **web app** accessible from any browser, and because we used Flutter, the same codebase can also be compiled into a native Android or iOS app without rewriting a single line.

---

## 🎤 Part 2 — Technology Explanation (3–5 minutes)

### What to Say:

> "Our application follows a **three-tier architecture**: a Flutter frontend, a Node.js backend, and a PostgreSQL database.
>
> For the **frontend**, we used **Flutter** — a framework by Google that uses a language called Dart. Flutter is unique because it compiles your code into native machine instructions for every platform — Web, Android, iOS — from one single codebase. For state management, we used **Riverpod**, which is a compile-safe reactive state management solution. Every screen that needs live data — like the channel list or the chat — watches a Riverpod provider, and automatically rebuilds when the data changes.
>
> For the **backend**, we built a REST API using **Node.js** with the **Express.js** framework. Node.js is excellent for real-time applications because of its non-blocking, event-driven architecture — it can handle thousands of concurrent connections without performance degradation.
>
> For the **database**, we used **PostgreSQL** — a powerful relational database. We hosted it on **Neon**, which is a serverless PostgreSQL service that scales automatically. Our schema has 13 tables organized in a strict hierarchy: Faculty → Programme → Batch → Channel, which reflects how ADTU's academic structure actually works.
>
> For **real-time features**, we used **Socket.IO** — a WebSocket library. When a student sends a message, the server instantly broadcasts it to everyone in the same subject room. This is also how typing indicators and live notifications work.
>
> For **file storage**, we used **Supabase Storage** — a CDN-backed file storage service. When a student submits an assignment or a faculty uploads notes, the file goes directly to Supabase and a URL is stored in our database. The files are served via a global CDN, so downloads are fast regardless of location."

---

## 🎤 Part 3 — Features Walkthrough (3–4 minutes)

### What to Say:

> "Let me walk you through the key features.
>
> **First, Role-Based Access Control.** The system has four roles: Student, Class Representative, Faculty, and Admin. Every API endpoint checks the user's role before processing. For example, only Faculty can create assignments or upload notes. Students can only submit. The role is set server-side at registration — a student cannot escalate their own privileges even by modifying the request.
>
> **Second, Real-Time Class Chat.** Every subject channel has a live chat powered by Socket.IO. Messages appear instantly across all users. Faculty can pin important messages. Students can reply to specific messages in threads. Files — PDFs, images, Word documents — can be attached directly in chat.
>
> **Third, Assignments and Grading.** Faculty creates assignments with deadlines and maximum marks. Students submit files. Faculty can view all submissions, grade them with marks and feedback. Students get an instant push notification when graded.
>
> **Fourth, Kanban Project Boards.** Students and faculty can create collaborative projects with a Jira-style task board. Tasks move between To Do, In Progress, and Done columns. The project creator can add team members from their class using a member picker. The project's progress percentage is automatically recalculated every time a task is completed or deleted.
>
> **Fifth, Academic Calendar.** The admin can create university-wide events — exams, holidays, seminars. Students see these on an interactive monthly calendar, color-coded by event type."

---

## 🎤 Part 4 — Security Explanation (2 minutes)

### What to Say:

> "Security was a priority in this project. Let me highlight the key measures:
>
> For **authentication**, we used **JWT — JSON Web Tokens**. When a user logs in, the server signs a token containing their user ID and role. Every subsequent API request must include this token in the `Authorization` header. The server verifies it using a secret key. The token expires after 7 days.
>
> For **password storage**, we used **bcrypt**, which hashes passwords with a salt. Even if the database is compromised, the actual passwords cannot be recovered — bcrypt is computationally expensive to reverse.
>
> For **SQL injection prevention**, every database query uses parameterized statements — the `$1`, `$2` placeholder syntax in PostgreSQL. User input never touches the SQL string directly.
>
> For **file upload security**, we used a library called `file-type` that reads the actual bytes of the uploaded file to verify its MIME type — not just the file extension. This prevents someone from renaming a malicious `.exe` file to `.pdf` and uploading it.
>
> For **HTTP security**, we used the **Helmet** middleware, which adds headers like Content-Security-Policy, X-Frame-Options, and X-Content-Type-Options to every response.
>
> And we have **rate limiting** — 200 requests per IP address per 15 minutes — which protects against brute-force and DDoS attacks."

---

## 🎤 Part 5 — Database Design Explanation (2 minutes)

### What to Say:

> "Our database has 13 tables. The core structure follows the university's actual academic hierarchy: **Faculty → Programme → Batch → Channel**.
>
> A Faculty, for example, is 'Faculty of Computing and Technology'. A Programme under it is 'B.Tech CSE'. A Batch is the year of enrollment — like 2024. A Channel is one subject — like 'Data Structures for B.Tech CSE 2024 Batch, Semester 3'.
>
> Every piece of content — messages, notes, assignments — is stored with a `channel_id` foreign key. This ensures data is always scoped to the correct subject and never leaks across channels.
>
> We also added **B-Tree indexes** on the most frequently queried columns — like `channel_id` on the messages table. This means when a student opens a channel with thousands of messages, PostgreSQL can jump directly to the right rows using the index instead of scanning the full table. This gives us sub-millisecond query performance."

---

## 🎤 Part 6 — Deployment Explanation (1–2 minutes)

### What to Say:

> "The application is fully deployed and live. Here's how the deployment works:
>
> The **Flutter Web frontend** is hosted on **Vercel** — a global CDN that serves our static files from edge servers around the world. We pre-build the Flutter web output and commit it to the repository. Vercel detects the push and deploys automatically.
>
> The **Node.js backend** is hosted on **Render.com**. It auto-deploys every time we push to the `main` branch on GitHub.
>
> We also set up a **GitHub Actions CI/CD pipeline**. Every time code is pushed, GitHub automatically runs Flutter static analysis — if there are any compilation errors or type errors, the pipeline fails and we're notified before it ever reaches production.
>
> The database is always on **Neon's serverless PostgreSQL**. Files are served from **Supabase Storage's CDN**."

---

## ❓ Common Examiner Questions & Answers

### Q1: "Why did you choose Flutter over React or Angular for the frontend?"
> "Flutter was chosen for two main reasons. First, it gives us a truly cross-platform app — the same Dart codebase compiles to Web, Android, and iOS without any changes. Second, Flutter renders to a canvas using its own graphics engine — it doesn't depend on the browser's DOM or CSS. This means pixel-perfect consistent UI across all platforms and very smooth animations. React and Angular both require platform-specific adaptations for mobile."

---

### Q2: "Why use Node.js instead of Python or Java for the backend?"
> "Node.js is event-driven and non-blocking by design — this makes it excellent for handling many concurrent WebSocket connections simultaneously, which is critical for our real-time chat feature. Socket.IO — the WebSocket library we use — is a native Node.js library with deep integration. Python would work but its synchronous nature (without async frameworks) doesn't match our real-time requirements. Java/Spring is more suited for enterprise microservices, which is over-engineering for a university-scale application."

---

### Q3: "What is JWT and how does it work?"
> "JWT stands for JSON Web Token. When a user logs in successfully, the server creates a small JSON object containing the user's ID, role, and expiry time — this is the **payload**. The server then signs this payload using a secret key and a cryptographic algorithm (HMAC SHA-256). The result — a compact string — is the JWT. The client stores this token and sends it in every subsequent request. The server doesn't need to query the database to verify identity — it simply verifies the signature using the same secret key. If the signature is valid, the payload is trusted. This is called **stateless authentication** because no session is stored on the server."

---

### Q4: "What is Socket.IO and how is it different from normal HTTP?"
> "Normal HTTP is request-response: the client asks, the server answers, connection closes. For real-time features like chat, this doesn't work — you'd need to poll every few seconds asking 'any new messages?' This wastes resources. Socket.IO uses **WebSockets** — a persistent bi-directional connection. Once connected, either the client or server can push data at any time. When a student sends a message, Socket.IO broadcasts it to everyone in the same subject 'room' instantly — no polling needed."

---

### Q5: "What is bcrypt and why is it used instead of MD5 or SHA?"
> "MD5 and SHA are **fast** hash functions designed for integrity checks, not password security. Because they're fast, an attacker with a GPU can try billions of combinations per second. Bcrypt is **intentionally slow** — it runs the hashing function many times (the 'cost factor'). We use cost factor 10, which means ~100ms per hash. This makes brute-force attacks impractical — 1 billion guesses at 100ms each would take over 3 years. Bcrypt also automatically generates a unique salt for each password, so two users with the same password will have different hash values."

---

### Q6: "How did you handle file uploads?"
> "We used **Multer** — an Express middleware that parses `multipart/form-data` requests (the format browsers use for file uploads). Instead of saving files to the server's disk (which would be lost on Render's free tier), we created a custom Multer storage engine that streams files directly to **Supabase Storage** — a cloud file bucket. The file never touches our server's filesystem. Supabase returns a public URL which we store in our PostgreSQL database. When students download files, they download directly from Supabase's CDN — fast and reliable."

---

### Q7: "What is Riverpod and how does it manage state?"
> "Riverpod is a state management library for Flutter. It uses **providers** — objects that hold and expose state. When a provider's value changes (for example, a new message arrives), all widgets 'watching' that provider automatically rebuild. For async data, we use `AsyncNotifierProvider` which handles loading, error, and data states automatically. This is much cleaner than manually managing `setState` calls and `bool isLoading` flags across the UI. Riverpod also provides compile-time safety — unlike older solutions, if you reference a non-existent provider, it's a compilation error, not a runtime crash."

---

### Q8: "How does your application scale?"
> "Our current architecture handles university-scale (~5,000 users) comfortably. For larger scale, the key bottlenecks are: (1) Socket.IO — currently single-server. For multiple server instances, we'd add a **Redis Pub/Sub adapter** so all instances share the same event bus. (2) PostgreSQL connections — we'd add **PgBouncer** as a connection proxy. (3) Render's free tier cold starts — solved by upgrading to a paid tier or using a cron ping to keep it warm. The database on Neon and files on Supabase CDN already scale independently."

---

### Q9: "What would you improve if given more time?"
> "Several things: (1) Add a proper **admin dashboard** — currently admin setup is done directly via SQL. (2) **Push notifications** — currently real-time only when the app is open. We'd add FCM (Firebase Cloud Messaging) for background notifications. (3) **Automated testing** — unit tests for all controllers, widget tests for Flutter UI. (4) **Video calling** — WebRTC integration for live classes. (5) **Offline support** — using Flutter's Hive database to cache content so the app works without internet."

---

### Q10: "Explain the request lifecycle from login to viewing messages."
> "1. The Flutter app sends `POST /api/auth/login` with roll number and date of birth. 2. The backend's `authController` fetches the user from PostgreSQL by roll number. 3. `bcrypt.compare()` verifies the password against the stored hash. 4. `jwt.sign()` creates a token with the user's ID and role, signed with our `JWT_SECRET`. 5. The Flutter app stores this token using `FlutterSecureStorage`. 6. When opening a channel, Flutter's `ApiService.dio` sends `GET /api/channels/:id/messages` with the token in the `Authorization: Bearer <token>` header. 7. The `protect` middleware calls `jwt.verify()` — if valid, sets `req.user`. 8. The `messageController` runs a parameterized SQL query with the channel ID. 9. PostgreSQL uses the B-Tree index on `channel_id` for instant lookup. 10. The messages JSON is returned. 11. Riverpod's provider updates, and the chat screen rebuilds with the new messages."

---

## 🗓 Suggested Presentation Timeline

| Segment | Time | Content |
|---|---|---|
| Introduction & Problem Statement | 2 min | What EduSync is, what problem it solves |
| Live Demo | 5 min | Login → open a channel → send message → show assignment, kanban board |
| Technology Deep Dive | 5 min | Flutter, Node.js, PostgreSQL, Socket.IO, Supabase |
| Security Features | 2 min | JWT, bcrypt, rate limiting, parameterized queries |
| Architecture & Deployment | 2 min | Architecture diagram, Vercel, Render, Neon, CI/CD |
| Q&A | Remaining | Use the Q&A section above |

**Total: ~16 minutes + Q&A**

---

## 💡 Tips for the Viva

1. **Open the live demo first** — show `https://major-three-tau.vercel.app` before explaining anything. Examiners are immediately impressed by a working deployed application.

2. **Know the data flow** — be able to trace any action (send message, submit assignment) from UI click → API call → database → response → UI update.

3. **Explain WHY, not just WHAT** — don't just say "we used JWT." Say "we used JWT because it's stateless — the server doesn't need to store sessions, which makes it horizontally scalable."

4. **Own your stack** — if asked about any library in `package.json` or `pubspec.yaml`, you should know what it does. Study the complete tables in the TECH_STACK_AND_SETUP.md doc.

5. **Have the architecture diagram ready** — draw it on the board if asked. The boxes are: Flutter → Express API + Socket.IO → PostgreSQL + Supabase.

6. **Don't panic about what's not built** — if asked about missing features (like admin UI), confidently say "That's a planned improvement" and describe how you'd build it.

7. **Database schema matters** — examiners love asking about database design. Know all 13 tables and why the hierarchy (Faculty → Programme → Batch → Channel) makes sense.
