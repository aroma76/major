# EduSync — Tech Stack & OOP Concepts (External Presentation)

---

## 1. TECH STACK

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend** | Flutter (Dart) | Cross-platform UI (Android, iOS, Web) |
| **State Management** | Flutter Riverpod | Reactive state & dependency injection |
| **HTTP Client** | Dio | REST API calls, JWT interceptors |
| **Real-time** | Socket.IO (client) | Live chat, announcements, notifications |
| **Secure Storage** | flutter_secure_storage / SharedPreferences | JWT token persistence |
| **Fonts** | Google Fonts (Outfit) | Custom typography |
| **Backend** | Node.js + Express.js | REST API server |
| **Real-time Server** | Socket.IO (server) | WebSocket event handling |
| **Database** | PostgreSQL (via `pg` pool) | Relational data storage |
| **File Storage** | Supabase Storage | File/attachment upload & download |
| **Authentication** | JWT (jsonwebtoken) + bcryptjs | Stateless auth, password hashing |
| **Security** | Helmet.js, express-rate-limit | HTTP headers, DDoS protection |
| **Compression** | compression (gzip) | ~80% response size reduction |
| **Deployment** | Render (backend), Vercel (frontend web) | Cloud hosting |

---

## 2. OOP CONCEPTS IN DART / FLUTTER (FRONTEND)

> Dart is a **fully object-oriented language**. Every value is an object.  
> Here is where each core OOP concept appears in the EduSync codebase.

---

### A. ENCAPSULATION
> **Bundling data + methods together inside a class, hiding internal details.**

**Example 1 — `StorageService` (`frontend/lib/core/services/storage_service.dart`)**

```dart
class StorageService {
  static final StorageService _instance = StorageService._internal(); // private
  factory StorageService() => _instance;
  StorageService._internal(); // private constructor — hides how instance is made

  final _secure = const FlutterSecureStorage(); // private field
  SharedPreferences? _prefs;                    // private field

  // Public methods — callers never know WHICH storage backend is used
  Future<void> write(String key, String value) async { ... }
  Future<String?> read(String key) async { ... }
  Future<void> delete(String key) async { ... }
}
```
**What to say:** "The class hides `_secure` and `_prefs` as private fields. The outside world only calls `read`, `write`, `delete`. Whether it uses Keychain on iOS or localStorage on Web is an internal detail — fully encapsulated."

---

**Example 2 — `AuthService` (`frontend/lib/core/services/auth_service.dart`)**

```dart
class AuthService {
  Map<String, dynamic>? _currentUser; // private — can't be set from outside
  Map<String, dynamic>? get currentUser => _currentUser; // read-only getter
}
```
**What to say:** "The `_currentUser` field is private. External code can only read it via the getter, not overwrite it directly. This is classic encapsulation."

---

### B. ABSTRACTION
> **Showing only the necessary interface; hiding complexity behind a clean API.**

**Example 1 — `ApiService` (`frontend/lib/core/services/api_service.dart`)**

```dart
class ApiService {
  // Users call this simple method ↓
  Future<Response> getAnnouncements(int channelId) =>
      dio.get('/channels/$channelId/announcements');

  // Users call this simple method ↓
  Future<Response> login(String rollNumber, String dob) =>
      dio.post('/auth/login', data: {'identifier': rollNumber, 'password': dob});
}
```
**What to say:** "The `ApiService` abstracts all HTTP complexity. The `AnnouncementRepository` just calls `_api.getAnnouncements(channelId)` — it never deals with Dio, URLs, headers, or JWT injection. The complex Dio setup (interceptors, timeouts, base URL) is completely hidden."

---

**Example 2 — `SocketService` (`frontend/lib/core/services/socket_service.dart`)**

```dart
class SocketService {
  io.Socket? _socket; // internal socket — hidden

  // Abstract, clean interface:
  void joinChannel(int channelId) => _socket?.emit('channel:join', channelId);
  void sendMessage({required int channelId, required String content}) { ... }
  void onNewMessage(void Function(Map<String, dynamic>) callback) { ... }
  void disconnect() { ... }
}
```
**What to say:** "Widgets that use chat never touch `socket.io` directly. They call `SocketService().joinChannel(id)` or `SocketService().onNewMessage(callback)`. The internal `_socket` object, WebSocket transport setup, and auth token injection are all abstracted away."

---

**Example 3 — Repository Pattern (`AnnouncementRepository`)**

```dart
class AnnouncementRepository {
  final _api = ApiService(); // uses abstraction internally

  Future<List<Map<String, dynamic>>> getAnnouncements(int channelId) async {
    final response = await _api.getAnnouncements(channelId);
    // Parses response, returns clean List — caller has no idea about HTTP
    return list.cast<Map<String, dynamic>>();
  }
}
```
**What to say:** "The Repository layer abstracts the data source. The UI provider calls `_announcementRepo.getAnnouncements(id)` and gets a simple Dart List — it never sees HTTP responses, JSON parsing, or `Dio.Response` objects."

---

### C. CLASSES & OBJECTS
> **Blueprints that define data structure and behaviour.**

All data models are classes that create strongly-typed objects from JSON:

**`AssignmentModel` (`data/models/assignment_model.dart`)**
```dart
class AssignmentModel {
  final int id, channelId, maxMarks;
  final String title;
  final DateTime dueDate;
  final String? submissionStatus;

  bool get isSubmitted => submissionStatus != null;  // computed property
  bool get isOverdue => !isSubmitted && dueDate.isBefore(DateTime.now()); // logic in class

  factory AssignmentModel.fromJson(Map<String, dynamic> json) { ... }
}
```

**`ApiMessageModel` (`data/models/api_message_model.dart`)**  
- Has both `fromJson()` (deserialise) and `toJson()` (serialise for caching) — full object lifecycle.

**`TaskModel` (`data/models/task_model.dart`)**  
- Has a `copyWith()` method — immutable-style update pattern used in Riverpod state.

---

### D. SINGLETON PATTERN (Special OOP Pattern)
> **Ensures only ONE instance of a service class exists across the whole app.**

Three core services all use the Dart singleton pattern:

```dart
// ApiService, AuthService, SocketService all follow this exact pattern:
class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance; // same object returned every time
  ApiService._internal();            // private constructor
}
```
**What to say:** "Instead of creating a new HTTP client or socket connection every time, we use the Singleton pattern. `ApiService()`, `AuthService()`, and `SocketService()` — calling the constructor anywhere in the app always returns the **same** shared instance. This prevents multiple open socket connections or Dio clients."

---

### E. ENUMS (Type-safe OOP constants)

```dart
// task_model.dart
enum TaskStatus { todo, inProgress, done }
enum TaskPriority { low, medium, high }

// auth_provider.dart
enum AuthStatus { loading, authenticated, unauthenticated }

// task_provider.dart
enum AssignmentViewType { list, kanban }
enum DashboardNoteType { note, question }
```
**What to say:** "Enums define a fixed set of allowed values for a type. Instead of error-prone magic strings, we use `TaskStatus.done`, `AuthStatus.authenticated` etc. — making the code type-safe and readable."

---

### F. INHERITANCE / EXTENDING BASE CLASSES

```dart
// Notifiers extend Riverpod base classes:
class AuthNotifier extends AsyncNotifier<AuthState> { ... }
class MessagesNotifier extends Notifier<MessagesState> { ... }
class TaskNotifier extends Notifier<List<TaskModel>> { ... }
class NavigationNotifier extends Notifier<int> { ... }

// Widgets extend Flutter base widgets:
class MyApp extends ConsumerWidget { ... }
class _AuthGate extends ConsumerWidget { ... }
```
**What to say:** "We extend `Notifier` and `AsyncNotifier` base classes from Riverpod. Our `AuthNotifier` **inherits** the `state`, `ref`, `build()` contract from `AsyncNotifier<AuthState>`, and we override `build()` to initialise authentication. This is OOP inheritance in practice."

---

### G. FACTORY CONSTRUCTORS (Named Constructors / OOP Creational Pattern)

```dart
// ChannelModel
factory ChannelModel.fromJson(Map<String, dynamic> json) {
  return ChannelModel(id: json['id'], subjectName: json['subject_name'], ...);
}

// AssignmentModel — same pattern
factory AssignmentModel.fromJson(Map<String, dynamic> json) { ... }

// ApiMessageModel — fromJson + toJson pair
factory ApiMessageModel.fromJson(Map<String, dynamic> json) { ... }
Map<String, dynamic> toJson() => { ... };
```
**What to say:** "The `factory` keyword is Dart's way of implementing the Factory Pattern. `ChannelModel.fromJson(json)` is a named constructor that handles the creation logic. Callers just pass raw JSON and receive a fully constructed object — the parsing logic is encapsulated inside the class itself."

---

### H. IMMUTABILITY + copyWith() PATTERN

```dart
// MessagesState
MessagesState copyWith({
  List<ApiMessageModel>? messages,
  bool? isLoading,
  ...
}) => MessagesState(
  messages: messages ?? this.messages, // keep old values if not provided
  ...
);

// TaskModel, DashboardNote — same pattern
TaskModel copyWith({ String? title, TaskStatus? status, ... }) { ... }
DashboardNote copyWith({ String? content, bool? isResolved }) { ... }
```
**What to say:** "`copyWith()` is an OOP pattern for creating modified copies of immutable objects without mutating the original. Riverpod requires state to be replaced, never mutated. So we use `state = state.copyWith(isLoading: false)` — clean, predictable state updates."

---

## 3. OOP CONCEPTS IN JAVASCRIPT / NODE.JS (BACKEND)

> While Node.js is not strictly OOP, EduSync's backend uses **OOP principles** through module architecture and design patterns.

---

### A. ABSTRACTION via Controller Pattern

Each file in `backend/controllers/` is a module that **abstracts** its domain:

| Controller | Abstraction |
|---|---|
| `authController.js` | Hides bcrypt hashing, JWT signing, DB queries |
| `announcementController.js` | Hides SQL joins, socket broadcast, notification fan-out |
| `projectController.js` | Hides complex JOIN queries, progress auto-calculation |
| `messageController.js` | Hides socket broadcasting, file handling |

**Example — `authController.js`:**
```javascript
// generateToken() ABSTRACTS away JWT details from all controllers
const generateToken = (user) =>
  jwt.sign(
    { id: user.id, role: user.role, name: user.name, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );

// Route handler just calls: generateToken(user) — doesn't know JWT internals
res.json({ success: true, token: generateToken(user), user });
```

---

### B. ENCAPSULATION via Middleware

`backend/middleware/auth.js` — Encapsulates authentication logic:
```javascript
const protect = async (req, res, next) => {
  // All token validation, DB fallback, error handling is inside here
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  req.user = decoded; // exposes only what routes need
  next();
};

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) return res.status(403).json(...);
  next();
};
```
**What to say:** "Routes don't contain any JWT or authentication logic. They simply call `protect` middleware. The **how** of authentication is encapsulated in `auth.js`. Routes only see `req.user` — the output, not the process."

---

### C. SEPARATION OF CONCERNS (OOP Design Principle)

```
backend/
├── controllers/  ← Business Logic  (WHAT to do)
├── routes/       ← URL Routing     (WHICH endpoint calls WHAT)
├── middleware/   ← Cross-cutting   (auth, error, upload)
├── config/       ← Configuration   (DB pool, Supabase)
└── socket/       ← Real-time       (WebSocket handlers)
```
**What to say:** "Each layer has a single responsibility — a core OOP design principle. Routes don't query the database. Controllers don't define URLs. Middleware doesn't contain business logic. This separation makes the code maintainable and testable."

---

### D. Real-time Observer Pattern (Socket.IO)

`announcementController.js`:
```javascript
// Server emits an event → all subscribed clients receive it
io.to(`channel_${req.params.id}`).emit('announcement:new', { ...announcement });
```

`SocketService.dart` (client):
```dart
// Client registers a callback — Observer Pattern
void onNewAnnouncement(void Function(Map<String, dynamic>) callback) {
  _socket?.off('announcement:new'); // prevent duplicate listeners
  _socket?.on('announcement:new', (data) => callback(data));
}
```
**What to say:** "This is the **Observer Pattern** — a classic OOP behavioural pattern. When a teacher posts an announcement, the server **emits** an event. All connected students who **subscribed** (registered a callback via `onNewAnnouncement`) are notified instantly without polling."

---

## 4. QUICK ANSWER CHEATSHEET FOR VIVA

| Question | Answer |
|---|---|
| **What is abstraction in your code?** | `ApiService` abstracts all HTTP/Dio complexity. Repositories abstract JSON parsing. `SocketService` abstracts WebSocket details. |
| **Where is encapsulation?** | Private fields `_socket`, `_currentUser`, `_prefs` in service classes. Private constructors (`ApiService._internal()`). |
| **Where is inheritance?** | `AuthNotifier extends AsyncNotifier`, `MessagesNotifier extends Notifier`, all widgets `extend ConsumerWidget`. |
| **What is a Singleton?** | `ApiService()`, `AuthService()`, `SocketService()` — same instance returned every call via `factory` + `static final`. |
| **What is a Factory pattern?** | `ChannelModel.fromJson()`, `AssignmentModel.fromJson()` — factory constructors that control object creation. |
| **What design pattern is Socket?** | Observer Pattern — server emits events, clients register callbacks. |
| **What is the tech stack?** | Flutter (Dart) frontend, Node.js + Express backend, PostgreSQL database, Supabase file storage, Socket.IO real-time, JWT auth, deployed on Render + Vercel. |
| **Why Riverpod?** | It provides reactive state management with dependency injection. Providers are lazy, cached, and auto-disposed when not needed. |
| **Why PostgreSQL?** | Relational data — students, courses, enrollments, assignments all have foreign key relationships that SQL handles naturally. |
| **What is the Repository pattern?** | `AnnouncementRepository`, `ChannelRepository` etc. sit between providers and `ApiService`. They convert raw HTTP responses into clean Dart objects. |

---

*Generated for EduSync Major Project Presentation — June 2026*
