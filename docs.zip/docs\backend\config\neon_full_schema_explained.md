# 📄 `backend/config/neon_full_schema.sql` — Complete Explanation

> This file contains the **complete PostgreSQL schema** for EduSync, designed to run on **Neon PostgreSQL** (serverless). Run this once in the Neon SQL Editor to create all 16 tables, constraints, and indexes.

---

## Before Reading — What is a Database Schema?

A **schema** is the blueprint of a database — it defines:
- Which **tables** exist
- What **columns** each table has (name, data type, constraints)
- How tables **relate** to each other (foreign keys)
- **Indexes** for fast lookup

This file is written in **SQL DDL** (Data Definition Language) — the subset of SQL that creates/modifies structure rather than querying data.

---

## File Header — DROP TABLE Safety

```sql
DROP TABLE IF EXISTS notifications CASCADE;
DROP TABLE IF EXISTS announcements CASCADE;
...
DROP TABLE IF EXISTS faculties CASCADE;
```

**`DROP TABLE IF EXISTS`** — Removes the table if it exists. The `IF EXISTS` prevents an error if the table doesn't exist yet.

**`CASCADE`** — Also drops all tables that reference this table via foreign keys. Because tables reference each other (e.g., `messages` references `channels`), you must drop them in reverse dependency order, or use `CASCADE` to let PostgreSQL handle the order.

> ⚠️ This block is for **fresh setup only**. Running this on a database with existing data will **delete all data**. Only use this on a new Neon project or when resetting.

---

## Table Hierarchy Overview

```
faculties
  └── programmes (faculty_id → faculties)
        └── batches (programme_id → programmes)
              ├── channels (batch_id → batches)
              │     ├── messages (channel_id → channels)
              │     ├── notes (channel_id → channels)
              │     ├── assignments (channel_id → channels)
              │     │     └── assignment_submissions (assignment_id → assignments)
              │     └── announcements (channel_id → channels)
              └── enrollments (channel_id → channels, user_id → users)

users (standalone, referenced by almost everything)
notifications (user_id → users)
projects (created_by → users)
  ├── project_members (project_id → projects, user_id → users)
  └── project_tasks (project_id → projects, assigned_to → users)

academic_events (standalone, created_by → users)
```

This hierarchy reflects ADTU's actual academic structure:
- A **Faculty** (e.g., Faculty of Computing & Technology) contains many Programmes
- A **Programme** (e.g., B.Tech CSE) has multiple Batches (one per year)
- A **Batch** has many Channels (one per subject per semester)
- **Users** enroll in Channels via the Enrollments table

---

## Table-by-Table Breakdown

### `faculties`

```sql
CREATE TABLE faculties (
  id         SERIAL PRIMARY KEY,
  name       VARCHAR(255) UNIQUE NOT NULL,
  color_code VARCHAR(50) DEFAULT '#3b82f6',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

| Column | Type | Notes |
|---|---|---|
| `id` | `SERIAL PRIMARY KEY` | Auto-incrementing integer ID |
| `name` | `VARCHAR(255) UNIQUE NOT NULL` | Faculty name, must be unique |
| `color_code` | `VARCHAR(50)` | Hex color for UI display |
| `created_at` | `TIMESTAMPTZ` | Timestamp with timezone, auto-set |

**`SERIAL`** — Shorthand for `INTEGER NOT NULL DEFAULT nextval('sequence')`. PostgreSQL auto-assigns 1, 2, 3...  
**`PRIMARY KEY`** — Implies `UNIQUE` and `NOT NULL`. Enables O(1) lookup by ID.  
**`TIMESTAMPTZ`** — Timestamp with timezone (recommended over `TIMESTAMP` which is naive/local).

---

### `programmes`

```sql
CREATE TABLE programmes (
  id                 SERIAL PRIMARY KEY,
  faculty_id         INT NOT NULL REFERENCES faculties(id) ON DELETE CASCADE,
  name               VARCHAR(255) NOT NULL,
  code               VARCHAR(50) NOT NULL,
  duration_semesters INT NOT NULL,
  created_at         TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (faculty_id, code)
);
```

**`REFERENCES faculties(id) ON DELETE CASCADE`** — Foreign key constraint. If a faculty row is deleted, all its programmes are automatically deleted too. This maintains referential integrity without orphaned rows.

**`UNIQUE (faculty_id, code)`** — Composite unique constraint. The programme code must be unique within a faculty, but the same code (e.g., "CSE") can appear in different faculties.

---

### `batches`

```sql
CREATE TABLE batches (
  id           SERIAL PRIMARY KEY,
  programme_id INT NOT NULL REFERENCES programmes(id) ON DELETE CASCADE,
  year         INT NOT NULL,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (programme_id, year)
);
```

A batch represents a specific intake year of a programme (e.g., B.Tech CSE 2024 batch). **`UNIQUE (programme_id, year)`** ensures only one batch per programme per year.

---

### `users`

```sql
CREATE TABLE users (
  id               SERIAL PRIMARY KEY,
  name             VARCHAR(255) NOT NULL,
  email            VARCHAR(255) UNIQUE NOT NULL,
  roll_number      VARCHAR(100) UNIQUE,
  dob              DATE,
  password         VARCHAR(255) NOT NULL,
  role             VARCHAR(50) NOT NULL DEFAULT 'student'
    CHECK (role IN ('student', 'class_representative', 'faculty', 'admin')),
  programme_id     INT REFERENCES programmes(id) ON DELETE SET NULL,
  batch_year       INT,
  current_semester INT DEFAULT 1,
  avatar_initials  VARCHAR(10),
  avatar_url       VARCHAR(500),
  created_at       TIMESTAMPTZ DEFAULT NOW()
);
```

**`CHECK (role IN (...))`** — A constraint that validates the `role` column. Any INSERT or UPDATE with an invalid role will be rejected by PostgreSQL at the database level — a second line of defense after application-level validation.

**`ON DELETE SET NULL`** — If the referenced programme is deleted, `programme_id` becomes `NULL` (user is preserved but unlinked). This is different from `CASCADE` (which would delete the user).

**`password`** — Stores the **bcrypt hash**, never the plain-text password. The actual password is hashed in `authController.js` before being stored.

---

### `channels`

```sql
CREATE TABLE channels (
  id             SERIAL PRIMARY KEY,
  batch_id       INT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
  semester_number INT NOT NULL,
  subject_name   VARCHAR(255) NOT NULL,
  subject_slug   VARCHAR(255) NOT NULL,
  channel_name   VARCHAR(255) UNIQUE NOT NULL,
  teacher_id     INT REFERENCES users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);
```

A channel represents a **subject workspace** for a specific batch in a specific semester. `subject_slug` is a URL-friendly version of the name (e.g., `data-structures`). `teacher_id` links to the faculty member who owns this subject.

---

### `enrollments`

```sql
CREATE TABLE enrollments (
  id         SERIAL PRIMARY KEY,
  user_id    INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_id INT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, channel_id)
);
```

A **junction table** (also called a bridge or associative table) representing a many-to-many relationship between users and channels. **`UNIQUE (user_id, channel_id)`** ensures no duplicate enrollments.

---

### `messages`

```sql
CREATE TABLE messages (
  id         SERIAL PRIMARY KEY,
  channel_id INT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  sender_id  INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content    TEXT,
  file_url   VARCHAR(500),
  file_name  VARCHAR(255),
  parent_id  INT REFERENCES messages(id) ON DELETE SET NULL,
  is_pinned  BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

**`content TEXT`** — No length limit (unlike `VARCHAR`). Suitable for long messages.

**`parent_id INT REFERENCES messages(id)`** — **Self-referential foreign key** — a message can reference another message in the same table. This enables **threaded replies** (a message can have a parent).

**`is_pinned BOOLEAN`** — Enables the "pin message" feature. Teachers or CRs can pin important messages in a channel.

---

### `notes`

```sql
CREATE TABLE notes (
  id         SERIAL PRIMARY KEY,
  channel_id INT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  created_by INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      VARCHAR(255) NOT NULL,
  content    TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

Stores text-based notes created by faculty for a subject channel. File-based notes (PDFs) are stored as file messages in the `messages` table.

---

### `assignments`

```sql
CREATE TABLE assignments (
  id          SERIAL PRIMARY KEY,
  channel_id  INT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  created_by  INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title       VARCHAR(255) NOT NULL,
  description TEXT,
  due_date    TIMESTAMPTZ NOT NULL,
  max_marks   INT DEFAULT 100,
  status      VARCHAR(20) DEFAULT 'todo'
    CHECK (status IN ('todo','in_progress','done')),
  priority    VARCHAR(20) DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high')),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
```

`status` and `priority` use `CHECK` constraints to enforce valid enum values. `due_date` is `TIMESTAMPTZ` (not just `DATE`) to support time-specific deadlines.

---

### `assignment_submissions`

```sql
CREATE TABLE assignment_submissions (
  id            SERIAL PRIMARY KEY,
  assignment_id INT NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  student_id    INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  file_url      VARCHAR(500),
  file_name     VARCHAR(255),
  status        VARCHAR(50) DEFAULT 'submitted'
    CHECK (status IN ('pending', 'submitted', 'late', 'graded')),
  marks         INT,
  feedback      TEXT,
  submitted_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (assignment_id, student_id)
);
```

**`UNIQUE (assignment_id, student_id)`** — Each student can only submit once per assignment. Re-submission would require an UPDATE.

**`marks INT`** and **`feedback TEXT`** — Populated when a faculty member grades the submission via the grading endpoint.

---

### `announcements`

```sql
CREATE TABLE announcements (
  id           SERIAL PRIMARY KEY,
  channel_id   INT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id      INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title        VARCHAR(255),
  content      TEXT NOT NULL,
  is_important BOOLEAN DEFAULT FALSE,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);
```

Channel-scoped announcements posted by faculty or CRs. `is_important` flags high-priority announcements for visual highlighting in the UI.

---

### `notifications`

```sql
CREATE TABLE notifications (
  id         SERIAL PRIMARY KEY,
  user_id    INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type       VARCHAR(100) NOT NULL,
  title      VARCHAR(255) NOT NULL,
  message    TEXT,
  is_read    BOOLEAN DEFAULT FALSE,
  ref_id     INT,
  ref_type   VARCHAR(50),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

**`ref_id` and `ref_type`** — A polymorphic reference. `ref_id` is the ID of a related entity (e.g., assignment ID), and `ref_type` describes which table it's from (e.g., `'assignment'`). Used to navigate to the relevant item when the notification is tapped.

---

### `projects`

```sql
CREATE TABLE projects (
  id          SERIAL PRIMARY KEY,
  title       VARCHAR(255) NOT NULL,
  description TEXT,
  deadline    TIMESTAMPTZ,
  progress    INT DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  created_by  INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
```

`progress` is a `CHECK` constraint ensuring values between 0–100. This is a database-enforced range constraint.

---

### `project_members`

```sql
CREATE TABLE project_members (
  id         SERIAL PRIMARY KEY,
  project_id INT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id    INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (project_id, user_id)
);
```

Junction table for the many-to-many relationship between projects and users (members).

---

### `project_tasks`

```sql
CREATE TABLE project_tasks (
  id          SERIAL PRIMARY KEY,
  project_id  INT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title       VARCHAR(255) NOT NULL,
  description TEXT,
  assigned_to INT REFERENCES users(id) ON DELETE SET NULL,
  created_by  INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  due_date    TIMESTAMPTZ,
  priority    VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
  status      VARCHAR(20) DEFAULT 'todo' CHECK (status IN ('todo','in_progress','done')),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
```

Tasks within a project, implementing the **Kanban board** feature. `status` maps to Kanban columns: `todo`, `in_progress`, `done`.

---

### `academic_events`

```sql
CREATE TABLE academic_events (
  id           SERIAL PRIMARY KEY,
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  event_type   VARCHAR(50) NOT NULL DEFAULT 'other'
    CHECK (event_type IN ('holiday', 'exam', 'semester', 'fest', 'workshop', 'deadline', 'other')),
  start_date   DATE NOT NULL,
  end_date     DATE NOT NULL,
  colour       VARCHAR(20) DEFAULT '#3b82f6',
  is_important BOOLEAN DEFAULT FALSE,
  created_by   INT REFERENCES users(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);
```

Academic calendar events spanning date ranges. `event_type` has 7 valid values enforced by `CHECK`. Note: `end_date >= start_date` is NOT enforced at DB level — that validation happens in the application layer.

---

## Performance Indexes

```sql
CREATE INDEX IF NOT EXISTS idx_messages_channel       ON messages(channel_id);
CREATE INDEX IF NOT EXISTS idx_notes_channel          ON notes(channel_id);
CREATE INDEX IF NOT EXISTS idx_assignments_channel    ON assignments(channel_id);
-- ... (14 indexes total)
```

**What is an index?** An index is a separate data structure (usually a B-tree) that allows PostgreSQL to find rows matching a condition in O(log n) time instead of O(n) (full table scan).

**Why these columns?** Every query that filters by `channel_id`, `user_id`, or `project_id` benefits from an index. Without indexes, a query for "all messages in channel 42" would scan every row in the `messages` table.

**`IF NOT EXISTS`** — Safe to run multiple times; won't error if the index already exists.

---

## Summary — All 16 Tables

| Table | Purpose | Key Relationships |
|---|---|---|
| `faculties` | Top-level academic unit | Parent of programmes |
| `programmes` | Degree programme (B.Tech CSE) | Child of faculties |
| `batches` | Intake year group | Child of programmes |
| `users` | All app users (student/faculty/admin) | References programmes |
| `channels` | Subject workspace | Child of batches, references users |
| `enrollments` | User ↔ Channel membership | Junction: users × channels |
| `messages` | Chat messages (text + files) | Self-ref (parent_id for replies) |
| `notes` | Faculty notes for a subject | Child of channels |
| `assignments` | Assignment definition | Child of channels |
| `assignment_submissions` | Student submission + grade | Child of assignments |
| `announcements` | Channel announcements | Child of channels |
| `notifications` | Per-user notifications | Child of users |
| `projects` | Kanban project boards | Child of users |
| `project_members` | Project ↔ User membership | Junction: projects × users |
| `project_tasks` | Kanban tasks | Child of projects |
| `academic_events` | Academic calendar events | References users (created_by) |
